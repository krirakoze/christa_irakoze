select first_trx_date, 
service, subs_number, subs_name from
(
select trunc(first_trx_date) first_trx_date, 
'VIVA MALT' service, subs_msisdn subs_number,p.user_name||' '||p.last_name subs_name
from SUBS_FIRST_TRX_DETAIL det,ecokash.mtx_party p
where det.subs_msisdn=p.msisdn and det.service_type = 'MPSUBREQ'
and p.status = 'Y'
and det.SECOND_PARTY_ACCOUNT = (select user_id from ecokash.users where msisdn = '72129874')
and det.subs_msisdn not in (select msisdn from request_info)
) where first_trx_date between '01-SEP-20' and '24-SEP-20'
order by first_trx_date, service;