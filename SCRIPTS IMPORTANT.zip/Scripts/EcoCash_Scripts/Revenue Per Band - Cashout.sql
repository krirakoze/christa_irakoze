SELECT sst.service_name description,to_char(mti.transfer_date,'MON-YYYY') "MONTH", count(distinct mti.TRANSFER_ID) volume,
SUM (DECODE (mti.entry_type,'DR', mti.transfer_value / 100,-mti.transfer_value / 100)) value,
SUM (mti2.transfer_value / 100) revenue
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2,
ecokash.mtx_transaction_header mth WHERE mti.transfer_status = 'TS' AND mti.transfer_id=mti2.transfer_id
AND mti.service_type = sst.service_type and mth.transfer_id=mti.transfer_id and mti2.wallet_number = '101IND03'
and mth.service_type = 'CASHOUT' and mti.user_type='PAYER' and mti.category_code='SUBS' and mti.transaction_type = 'MP'
AND mti.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and mti.transfer_date < last_day(to_date('01/11/2021','dd/mm/yyyy')) + 1
AND mti.transfer_value / 100 between 500000 and 1000000
GROUP BY sst.service_name , to_char(mti.transfer_date,'MON-YYYY') order by to_char(mti.transfer_date,'MON-YYYY');