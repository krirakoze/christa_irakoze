select sum(amount) from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'MER')
and TRUNC (closing_date) = to_date('30/09/2018','dd/mm/yyyy');