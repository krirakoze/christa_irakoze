--The Approval Code is the SERIAL_NUMBER

/*select h.TRANSFER_DATE, d.TRANSFER_STATUS, d.PARTY_ACCESS_ID, h.ATTR_3_VALUE,  h.SERIAL_NUMBER 
from ecokash.MTX_TRANSACTION_HEADER h, ecokash.MTX_TRANSACTION_ITEMS d
where h.TRANSFER_ID = d.TRANSFER_ID 
and d.TRANSFER_STATUS = 'TS'
and d.SERVICE_TYPE = 'P2PNONREG'
--and (d.PARTY_ID = (select p.USER_ID from ecokash.MTX_PARTY p where p.MSISDN = 'xxxxx' and p.STATUS = 'Y')
--or h.ATTR_3_VALUE = 'xxxxxx')
and d.PAYMENT_TYPE_ID = 12
and d.TRANSACTION_TYPE = 'MP'
and h.transfer_id = 'xxxxx'
order by h.TRANSFER_DATE desc;*/

select serial_number approval_code from ecokash.mtx_transaction_header where transfer_id = 'PN210323.1759.D00117';
