select to_char(trx_date,'MON-YYYY') "MONTH",user_name biller_name,
count(distinct transfer_id) volume,sum(amount) value,sum(revenue) revenue,count(distinct subs) unik_subs from(
SELECT mti.transfer_date trx_date,mti.transfer_id,u.agent_code,u.msisdn,
u.user_name user_name,mti.transfer_value/100 amount,mti2.transfer_value/100 revenue,
mti.second_party_account_id subs
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2,
ecokash.mtx_transaction_header mth,ecokash.users u
WHERE mti.transfer_status = 'TS' AND  mti.party_id =u.user_id
AND u.status != 'N' AND mti.service_type = sst.service_type
and mth.transfer_id=mti.transfer_id 
AND mti.transfer_id=mti2.transfer_id
AND mti2.wallet_number = '101IND03'
and mti.party_id  = (select user_id from ecokash.users where msisdn='79100312')
and u.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT')
AND mti.transfer_date  >= to_date('06/10/2021','dd/mm/yyyy')
and mti.transfer_date < ( to_date('11/10/2021','dd/mm/yyyy') + 1 )
 order by mti.transfer_date
 ) group by to_char(trx_date,'MON-YYYY'), user_name;