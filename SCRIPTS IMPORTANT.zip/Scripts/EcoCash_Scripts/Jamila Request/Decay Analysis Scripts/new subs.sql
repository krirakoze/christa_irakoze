--truncate table new_subs;
--commit;
insert into new_subs
select u.MSISDN from ecokash.MTX_PARTY_ACCESS p,
        ecokash.MTX_PARTY u
        where u.USER_ID = p.USER_ID
        and length(p.MSISDN) <= 8
        and p.STATUS != 'N'
        and u.STATUS != 'N'
        and (
        (trunc(p.CREATED_ON) between to_date('01/07/2021','dd/mm/yyyy') and last_day(to_date('01/07/2021','dd/mm/yyyy')) and u.LEVEL1_APPROVED_ON is null)
        or
        (trunc(p.MODIFIED_ON) between to_date('01/07/2021','dd/mm/yyyy') and last_day(to_date('01/07/2021','dd/mm/yyyy')) and u.LEVEL1_APPROVED_ON is not null)
) order by 1;
commit;