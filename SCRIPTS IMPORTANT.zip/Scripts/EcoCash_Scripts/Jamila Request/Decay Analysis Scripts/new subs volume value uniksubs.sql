select to_char(md.transfer_date,'MON-YYYY') mois,
sum(md.transfer_value/100) val,count(distinct md.transfer_id) vol,
count(distinct md.party_id) uniq_subs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from new_subs) --and p.STATUS != 'N'
and s.service_type in('CASHIN')
and md.transaction_type in ('MR')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy')
and md.transfer_date < to_date('31/08/2021','dd/mm/yyyy')+1
group by to_char(md.transfer_date,'MON-YYYY');