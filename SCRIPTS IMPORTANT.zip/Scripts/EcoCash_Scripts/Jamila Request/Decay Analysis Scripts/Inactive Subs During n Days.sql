--select count(*) from inactive_subs;
--truncate table inactive_subs;
--commit;

insert into inactive_subs
select distinct u.MSISDN from ecokash.MTX_PARTY_ACCESS p,
ecokash.MTX_PARTY u
where u.USER_ID = p.USER_ID
and length(p.MSISDN) <= 8
and p.STATUS != 'N'
and u.msisdn not in(
select distinct md.ACCOUNT_ID
from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
where md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS'
AND md.transfer_date >= (to_date('31/10/2021','dd/mm/yyyy')-90)+1
and md.transfer_date < to_date('31/10/2021','dd/mm/yyyy') + 1
);