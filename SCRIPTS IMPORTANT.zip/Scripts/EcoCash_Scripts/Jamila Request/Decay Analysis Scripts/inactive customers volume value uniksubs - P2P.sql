select to_char(md.transfer_date,'MON-YYYY') "MONTH",
sum(md.transfer_value/100) val,
count(distinct md.transfer_id) vol,
count(distinct md.account_id) unik_subs
from ecokash.MTX_TRANSACTION_HEADER mh,
ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from inactive_subs)
and md.category_code='SUBS'
and md.service_type in ('P2P')
and md.payment_type_id=12
and md.transaction_type = 'MR'
and md.transfer_date >= to_date('01/11/2021','dd/mm/yyyy')
and md.transfer_date < last_day(to_date('01/11/2021','dd/mm/yyyy'))+1
group by to_char(md.transfer_date,'MON-YYYY');