select distinct p.MSISDN
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(
	select u.MSISDN from ecokash.MTX_PARTY_ACCESS p,
        ecokash.MTX_PARTY u
        where u.USER_ID = p.USER_ID
        and length(p.MSISDN) <= 8
        and p.STATUS != 'N'
        and (
        (trunc(p.CREATED_ON) between to_date('01/11/2021','dd/mm/yyyy') and to_date('30/11/2021','dd/mm/yyyy') and u.LEVEL1_APPROVED_ON is null)
        or
        (trunc(p.MODIFIED_ON) between to_date('01/11/2021','dd/mm/yyyy') and to_date('30/11/2021','dd/mm/yyyy') and u.LEVEL1_APPROVED_ON is not null)
    ) order by 1
) and p.STATUS != 'N'
and md.transfer_date >= to_date('01/12/2021','dd/mm/yyyy')
and md.transfer_date < to_date('27/12/2021','dd/mm/yyyy')+1;