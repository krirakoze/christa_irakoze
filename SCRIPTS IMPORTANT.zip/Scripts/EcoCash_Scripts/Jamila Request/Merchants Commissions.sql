SELECT mti.transfer_date, mti.TRANSFER_ID,  (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) amount,second_party_account_id customer_number,
           (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) merchant_number,
           (select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) merchant_name,
           sst.SERVICE_NAME
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     --and mti.transfer_id like 'MP%'
     and mti.transaction_type='CR'
     and sst.service_type='MERCHPAY'
     and mti.party_id in (select user_id from ecokash.users where category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER'))
and mti.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and mti.transfer_date < to_date('31/08/2021','dd/mm/yyyy')+1
order by mti.transfer_date;
