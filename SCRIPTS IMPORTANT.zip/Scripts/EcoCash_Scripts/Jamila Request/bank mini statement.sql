select to_char(transfer_on,'MON-YYYY') "MONTH",bank_name,count(distinct Transfer_Id) volume,
sum(transfer_value) value,sum(transfer_value) revenue,count(distinct Issuer_MSISDN) unik_subs from(
select trunc(mti.transfer_date)Transfer_On,
(select bd.bank_name from ecokash.mbk_bank_details bd where bd.bank_id=mth.bank_id) Bank_Name,
mti.transfer_id Transfer_Id,mth.reference_number Reference_Number,
sst.service_name Service_Name,mti.entry_type Entry_Type,mti.transfer_Value/100 Transfer_Value,
mti.second_party_account_id Issuer_MSISDN
FROM ecokash.mtx_transaction_items mti 
inner join ecokash.mtx_transaction_header mth 
on mth.transfer_id = mti.transfer_id 
inner join  ecokash.sys_service_types sst 
ON mti.SERVICE_TYPE = sst.SERVICE_TYPE
WHERE mth.bank_id in(select bank_id from ecokash.mbk_bank_details)
AND mti.wallet_number = '101IND03'
and mti.transfer_status='TS'
AND ( 
    mth.SERVICE_TYPE IN  ('CMINIREQ') 
    OR ( 
            mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT') 
            and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d
            where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN  ('CMINIREQ')) 
     ) 
) 
AND mti.transfer_date >= to_date('06/10/2021','dd/mm/yyyy')
and mti.transfer_date < to_date('11/10/2021','dd/mm/yyyy')+1 
order by mti.transfer_date, mti.TXN_SEQUENCE_NUMBER) group by to_char(transfer_on,'MON-YYYY'),bank_name;