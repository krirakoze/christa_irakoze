select to_char(trx_date,'MON-YYYY') "MONTH",user_name agent_name,
count(distinct transfer_id) volume,sum(amount) value,count(distinct subs) unik_subs from(
SELECT mti.transfer_date trx_date,mti.transfer_id,u.agent_code,u.msisdn,
u.user_name||' - '||u.last_name user_name,mti.transfer_value/100 amount,
mti.second_party_account_id subs
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,ecokash.users u
WHERE mti.transfer_status = 'TS'
AND mti.account_type <> 'BANK'
AND mti.service_type = sst.service_type
AND mti.transfer_date >= to_date('06/10/2021','dd/mm/yyyy') 
and mti.transfer_date < to_date('11/10/2021','dd/mm/yyyy')  + 1
AND mti.transfer_id = mth.transfer_id
AND mti.party_id=u.user_id
AND sst.service_type='CASHIN'
AND mti.party_id = 'PT210702.1728.114916' order by 1
) group by to_char(trx_date,'MON-YYYY'),user_name;