select p.created_on created_date,p.MSISDN,p.user_name || ' ' || p.LAST_NAME "SUBSCRIBER_NAME",u.MSISDN agent_number,u.AGENT_CODE
from ecokash.users u,ecokash.mtx_party p
where u.user_id=p.created_by
and u.user_id in (select user_id from ecokash.users u where u.msisdn in ('72286568',
'72444321',
'72444214',
'72444313',
'72444311',
'72444307',
'72444312',
'72444309',
'72444316',
'72444317',
'72444322',
'72444319',
'72444366'
))
and trunc(p.created_on) between to_date('01/02/2017','dd/mm/yyyy')  and to_date('31/07/2017','dd/mm/yyyy')
order by 1;