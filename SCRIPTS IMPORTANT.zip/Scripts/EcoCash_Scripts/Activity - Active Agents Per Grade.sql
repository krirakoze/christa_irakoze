select agent_msisdn actives_agents from mmukila.AGENT_DAILY_ACTIVITY a,ecokash.channel_grades cg,ecokash.mtx_wallet mw
where a.agent_msisdn = mw.msisdn
and mw.user_grade = cg.grade_code
and mw.status='Y' and Mw.Payment_Type_Id=12
and cg.GRADE_CODE in ('ZRT','BRAM')
and TXN_DATE >= ( to_date('21/09/2020','dd/mm/yyyy') - 90)+1 AND TXN_DATE <  to_date('21/09/2020','dd/mm/yyyy') + 1;