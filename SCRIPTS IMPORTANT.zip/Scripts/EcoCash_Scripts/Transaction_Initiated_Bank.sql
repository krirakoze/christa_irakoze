select b.BANK_NAME from ecokash.mtx_transaction_header mti,ecokash.mtx_transaction_header mth,ECOKASH.MBK_BANK_DETAILS b
where mth.TRANSFER_ID=mti.TRANSFER_ID
and mth.BANK_ID=b.BANK_ID
and mth.transfer_id='OW190206.1624.A00016';