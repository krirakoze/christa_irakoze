select post_balance/100 balance
from ecokash.mtx_transaction_items
where account_id='72287153'
and transfer_date=(select max(transfer_date) from ecokash.mtx_transaction_items where account_id='72287153')
and payment_type_id=12;