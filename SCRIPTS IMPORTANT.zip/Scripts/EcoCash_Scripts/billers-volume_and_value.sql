select count(trx_id),sum(trx_amount)from (SELECT sst.service_type,mti.transfer_date trx_date,  mti.transfer_id trx_id, 
(select u.agent_code from ecokash.users u where u.user_id = mti.party_id  and u.status = 'Y') user_code, 
(select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') user_number, 
 (select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.party_id) biller_name, (DECODE (mti.entry_type,
                      'DR', -mti.transfer_value/100,
                      mti.transfer_value/100
                     )
             ) trx_amount ,
             (select mtp.msisdn from ecokash.mtx_party mtp where mtp.user_id = mti.second_party and mtp.status = 'Y') customer_number,
             (select mtp.user_name||' - '||mtp.last_name from ecokash.mtx_party mtp where mtp.user_id = mti.second_party) customer_name,sst.service_name, mth.REMARKS
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND trunc(mti.transfer_date) between to_date('01/09/2018','dd/mm/yyyy') and to_date('27/09/2019','dd/mm/yyyy')  
     AND mti.transfer_id = mth.transfer_id
     --AND mti.entry_type='DR'
     AND sst.service_type not in('OPTW','BILLERREF','ROLLBACK','TXNCORRECT')
     AND mti.party_id in (select user_id from ecokash.users where msisdn in 
     (
     '76290714',
'72097120',
'72370831',
'72368881',
'71358821',
'72097419',
'71937469',
'79775303',
'79775279',
'71634243',
'71360961',
'72010842',
'71687393',
'79396872',
'79802982',
'76455215',
'76531480',
'76529063',
'76529054',
'76529247',
'76529075',
'76504975'
     )
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT'))
order by 1);
