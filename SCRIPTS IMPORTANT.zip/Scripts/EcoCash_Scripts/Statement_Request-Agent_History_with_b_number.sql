SELECT mti.transfer_date trx_date,  mti.transfer_id trx_id,  (select u.agent_code from ecokash.users u where u.user_id = mti.party_id  and u.status = 'Y') user_code, 
(select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') user_number, 
(select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.party_id) user_name,
(DECODE (mti.entry_type,
        'DR', -mti.transfer_value/100,
        mti.transfer_value/100
         )
 )trx_amount ,mti.post_balance/100 balance, sst.service_name,
 decode(mti.first_pty_payment_method_desc, 12, 'Main Account', 'Commission Account') trx_account,
 (select u.msisdn from ecokash.mtx_party u where u.user_id = mti.second_party and u.status = 'Y') b_number, 
 (select u.user_name||' - '||u.last_name from ecokash.mtx_party u where u.user_id = mti.second_party) b_name,
 (select u.msisdn from ecokash.users u where u.user_id = mti.second_party and u.status = 'Y') b_agent_number, 
 (select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.second_party) b_agent_name
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
--AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('01/03/2019','dd/mm/yyyy') and mti.transfer_date < to_date('27/08/2020','dd/mm/yyyy')+1
     AND mti.transfer_id = mth.transfer_id
     AND mti.payment_type_id in (12,11,13)
     --AND mti.account_type<>'BANK'
     AND mti.party_id in (select user_id from ecokash.users where msisdn in ('76163079')
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
order by 1;
