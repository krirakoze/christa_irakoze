select count(user_id) from ecokash.users where Category_Code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and status!='N'
and created_on<to_date('31/08/2019','dd/mm/yyyy')+1;