--First, run Stored Procedures SP_CVBS_UMUKOPO_DEB and SP_MNO_UMUKOPO_REC respectively in MMUKILA schema

select running_time, cvbs_trx_date, sum(cvbs_tot_amount) cvbs_tot_amount, sum(ecocash_cashin) ecocash_tot_cashin,
sum(cvbs_not_cashed_in) cvbs_tot_not_cashed_in, sum(ecocash_umkopo_recovery) umukopo_tot_recovery,
sum(cashin_not_recovered) cashin_tot_not_recovered, sum(current_subs_wallet_balance) tot_subs_wallet_balance
from
(
select sysdate running_time, trx.cvbs_trx_date, trx.msisdn, trx.cvbs_tot_amount, trx.ecocash_cashin, 
trx.cvbs_tot_amount - trx.ecocash_cashin cvbs_not_cashed_in, trx.ecocash_umkopo_recovery,
trx.ecocash_cashin - trx.ecocash_umkopo_recovery cashin_not_recovered,
coalesce(wb.balance/100,0) current_subs_wallet_balance from
(select trunc(cvbs.trx_date) cvbs_trx_date,
cvbs.msisdn, sum(cvbs.amount) cvbs_tot_amount,
(
select coalesce(sum(mti.transfer_value/100),0)
from ecokash.mtx_transaction_items mti
where mti.party_id in (select user_id from ecokash.mtx_party 
where msisdn = cvbs.msisdn)
and mti.transfer_status = 'TS'
and mti.transfer_date >= trunc(cvbs.trx_date)
and mti.transfer_date < trunc(cvbs.trx_date) + 1
and mti.service_type = 'CASHIN'
and mti.transaction_type = 'MR'
and mti.second_party_account_id = '76816636'
) ecocash_cashin,
(
select coalesce(sum(mti.transfer_value/100),0)
from ecokash.mtx_transaction_items mti
where mti.party_id in (select user_id from ecokash.mtx_party 
where msisdn = cvbs.msisdn)
and mti.transfer_status = 'TS'
and mti.transfer_date >= trunc(cvbs.trx_date)
and mti.transfer_date < (trunc(cvbs.trx_date) + 1 + interval '14' minute)
and mti.service_type = 'SUBMPREQ'
and mti.transaction_type = 'MP'
and mti.second_party_account_id in ('76006659','76501791')
) ecocash_umkopo_recovery from CVBS_UMUKOPO_DEB cvbs
group by trunc(cvbs.trx_date), cvbs.msisdn
) trx 
left outer join ecokash.mtx_wallet w
on trx.msisdn = w.msisdn
and w.status <> 'N'
and w.payment_type_id = 12
left outer join ecokash.mtx_wallet_balances wb
on w.wallet_number = wb.wallet_number
where trx.cvbs_trx_date = trunc(sysdate-99)
) tt group by running_time, cvbs_trx_date
order by 2;