select trunc(u.CREATED_ON) created_on, u.MSISDN customer,
ag.msisdn reg_agent_msisdn,
ag.agent_code reg_agent_code,
ag.user_name||' '||ag.last_name reg_agent_name
from ecokash.MTX_PARTY_ACCESS p,
ecokash.MTX_PARTY u,
ecokash.users ag
where u.USER_ID = p.USER_ID
and u.created_by=ag.user_id
and length(p.MSISDN) <= 8
and p.STATUS != 'N'
and ag.STATUS != 'N'
and (
(trunc(p.CREATED_ON) between to_date('16/12/2020','dd/mm/yyyy') and to_date('22/12/2020','dd/mm/yyyy') and u.LEVEL1_APPROVED_ON is null)
or
(trunc(p.MODIFIED_ON) between to_date('16/12/2020','dd/mm/yyyy') and to_date('22/12/2020','dd/mm/yyyy') and u.LEVEL1_APPROVED_ON is not null)
)order by 1;