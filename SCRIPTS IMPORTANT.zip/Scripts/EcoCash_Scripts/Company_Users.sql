select u.LOGIN_ID user_id,u.USER_NAME||'  '||u.LAST_NAME user_name,u.MSISDN,u.CREATED_ON,u.LAST_LOGIN_ON,u.status,c.CATEGORY_NAME,
u.ATTR1_NAME,r.GROUP_ROLE_CODE,r.GROUP_ROLE_NAME
from ecokash.users u,ecokash.MTX_CATEGORIES c,ECOKASH.SYS_GROUP_ROLES r
where u.STATUS='Y' and u.CATEGORY_CODE=c.CATEGORY_CODE and u.CATEGORY_CODE=r.CATEGORY_CODE and u.BATCH_ID=r.GROUP_ROLE_CODE and u.login_id='jcuwimana'
and u.msisdn not in(select account_Number from ECOKASH. mtx_party_black_list) and trunc(LAST_LOGIN_ON) < to_date('18/01/2022','dd/mm/yyyy')+1;

select u.LOGIN_ID user_id,u.USER_NAME||'  '||u.LAST_NAME user_name,u.MSISDN,u.CREATED_ON,u.LAST_LOGIN_ON,u.status,c.CATEGORY_NAME,
u.ATTR1_NAME,r.GROUP_ROLE_CODE,r.GROUP_ROLE_NAME
from ecokash.users u,ecokash.MTX_CATEGORIES c,ECOKASH.SYS_GROUP_ROLES r
where u.STATUS='Y' and u.CATEGORY_CODE=c.CATEGORY_CODE and u.CATEGORY_CODE=r.CATEGORY_CODE and u.BATCH_ID=r.GROUP_ROLE_CODE /*and c.CATEGORY_NAME='Bank Admin'
and ATTR1_NAME='IBB'*/ and u.msisdn not in(select account_Number from ECOKASH. mtx_party_black_list) and trunc(LAST_LOGIN_ON) < to_date('01/03/2019','dd/mm/yyyy')+1;