SELECT  TO_CHAR (c.TIME, 'dd-mm-YYYY hh24:mi') , AVG (c.COUNT), MAX (c.COUNT)
    FROM (SELECT a.time1 TIME, (a.count1) COUNT
            FROM (SELECT   transfer_date time1, 
                           COUNT(*) count1
                      FROM ecokash.mtx_transaction_header
                     WHERE trunc(transfer_date) between '01/09/2018' AND '30/09/2018'
                       AND TO_NUMBER (TO_CHAR (transfer_date, 'hh24')) >= 00
                       AND TO_NUMBER (TO_CHAR (transfer_date, 'hh24')) <= 23
                       AND service_type not in ('STLMENT','OPTSTKDIS','RCOMRIMB')
                  GROUP BY transfer_date) a
           ) c
GROUP BY TO_CHAR (c.TIME, 'dd-mm-YYYY hh24:mi');