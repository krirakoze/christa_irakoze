select ag_code,agent_msisdn, agent_name,agent_last_name,count(customers) customers
from(select first_cashin_date activation_date, agent_msisdn, u.AGENT_CODE ag_code, u.user_name agent_name,
u.last_name agent_last_name, u.CITY city, u.STATE state, u.ADDRESS1 adresse1, u.ADDRESS2 adresse2,
customer_msisdn customers, u.contact_no,
(select sup.user_name || ' ' || sup.last_name from ecokash.users sup where u.PARENT_ID = sup.user_id) sup_agent_name
from gsingaya.AGENTS_INCENTIVES,
ecokash.USERS u, 
ecokash.mtx_wallet mw, 
ecokash.channel_grades cg 
where AGENT_MSISDN = u.MSISDN
and u.USER_ID = mw.USER_ID
and mw.PAYMENT_TYPE_ID = 11
and mw.status = 'Y'
and mw.user_grade = cg.grade_code
and cg.GRADE_CODE in ('ZRT','BRAM')
and first_cashin_date >= to_date('01/06/2020','dd/mm/yyyy') and first_cashin_date < to_date('30/06/2020','dd/mm/yyyy')+1) temp 
group by ag_code,agent_msisdn,agent_name,agent_last_name
order by agent_msisdn;