select md.TRANSFER_ID, md.TRANSFER_DATE,s.SERVICE_NAME,md.TRANSACTION_TYPE,md.ENTRY_TYPE,PARTY_ID customer_id, p.MSISDN subs_msisdn,
DECODE(md.ENTRY_TYPE,'DR', - md.TRANSFER_VALUE / 100, 
md.TRANSFER_VALUE / 100) TRX_AMOUNT,p.user_name,p.last_name,p.address1 COLLINE,p.address2 COMMUNE,p.city PROVINCE
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and md.SECOND_PARTY_ACCOUNT_ID in ('76007007')
and md.transfer_date >= to_date('30/05/2022','dd/mm/yyyy') and md.transfer_date < to_date('02/06/2022','dd/mm/yyyy')+1
order by md.TRANSFER_DATE;