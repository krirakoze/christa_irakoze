select to_char(transfer_on,'MON-YYYY') MONTH,service_name,transactor payroll_number,transactor_name payroll_name,count(transfer_id) volume,sum(trx_value) amount from(
SELECT mti.transfer_id transfer_id ,mti.transfer_date transfer_on, sst.service_name service_name,mti.transaction_type,mti.entry_type "CR/DR"
,(DECODE(mti.second_party_account_id,
                        'IND01',
                        'Mirror Trust Account',
                        'IND03',
                        'Fee Income Account',
                        mti.second_party_account_id
                        )
            ) mobile_number
,(DECODE (mti.entry_type,
                      'DR', -mti.transfer_value/100,
                      mti.transfer_value/100
                     )
             ) trx_value,mti.post_balance/100 post_balance ,
             (select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') transactor,
             (select u.user_name||' '||u.last_name from ecokash.users u where u.user_id = mti.party_id) transactor_name
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND sst.service_type='O2C'
     AND mti.transfer_date >= to_date('01/03/2020','dd/mm/yyyy') AND mti.transfer_date < to_date('11/09/2020','dd/mm/yyyy')
     AND mti.transfer_id = mth.transfer_id
     AND mti.party_id in (select user_id from ecokash.users where category_code in (select category_code from ecokash.mtx_categories where domain_code = 'EMPLOYER'))
order by 1
) group by to_char(transfer_on,'MON-YYYY'),service_name,transactor,transactor_name;
