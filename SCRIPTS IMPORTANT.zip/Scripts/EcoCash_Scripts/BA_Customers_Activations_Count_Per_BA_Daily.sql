select trunc(activation_date) activation_date,agent_msisdn,ag_code, agent_name,agent_last_name,count(customers) customers,city,state,adresse1,adresse2
from(select first_cashin_date activation_date, agent_msisdn, u.AGENT_CODE ag_code, u.user_name agent_name,
u.last_name agent_last_name, u.CITY city, u.STATE state, u.ADDRESS1 adresse1, u.ADDRESS2 adresse2,
customer_msisdn customers, u.contact_no,
(select sup.user_name || ' ' || sup.last_name from ecokash.users sup where u.PARENT_ID = sup.user_id) sup_agent_name
from ihakizimana.AGENTS_INCENTIVES,
ecokash.USERS u, 
ecokash.mtx_wallet mw, 
ecokash.channel_grades cg 
where AGENT_MSISDN = u.MSISDN
and u.USER_ID = mw.USER_ID
and mw.PAYMENT_TYPE_ID = 11
and mw.status = 'Y'
and mw.user_grade = cg.grade_code
and cg.GRADE_CODE in ('ZRT','BRAM')
and agent_msisdn in(
'76104870',
'76716720',
'72370547',
'76503247',
'71360739',
'76508931',
'76105264',
'79342198',
'72370303',
'76014667',
'76104709',
'71028641',
'71031469',
'71028522',
'76701699'
)
and trunc(first_cashin_date) between to_date('01/12/2018','dd/mm/yyyy') and to_date('31/12/2018','dd/mm/yyyy')) temp 
group by trunc(activation_date),agent_msisdn,ag_code, agent_name,agent_last_name,city,state,adresse1,adresse2
order by trunc(activation_date),agent_msisdn;