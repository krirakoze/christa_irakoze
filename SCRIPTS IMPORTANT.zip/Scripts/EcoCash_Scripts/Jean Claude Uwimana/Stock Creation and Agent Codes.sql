select transfer_date,reference_number,transfer_id,attr_3_name value_type,attr_3_value agent_code from ecokash.mtx_transaction_header
where transfer_id in(select transfer_id from ecokash.mtx_transaction_header
where reference_number in('MC210108.1846.A01555','MC210111.1443.A01650','MC210129.1218.A00364','MC210225.0909.A00300'));