SELECT sst.service_name description,to_char(mti.transfer_date,'MM-YYYY') Month,
count(distinct mti.transfer_id) volume,SUM (mti.transfer_value/100) value,
count(distinct mti.second_party_account_id) unique_subs
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2, ecokash.mtx_transaction_header mth
WHERE mti.transfer_id=mti2.transfer_id
and mti.transfer_status = 'TS'
   AND mth.transfer_status = 'TS'
   AND mti.transfer_id LIKE 'RC%'
   AND mti.service_type = sst.service_type
   AND mti.wallet_number = '100000000000001'
   and mti.transfer_id = mth.transfer_id
   and mti2.entry_type='DR'
   and mti2.category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
    AND mti.transfer_date >= to_date('01/05/2020','dd/mm/yyyy') and mti.transfer_date < to_date('31/05/2020','dd/mm/yyyy') + 1
    GROUP BY sst.service_name , to_char(mti.transfer_date,'MM-YYYY')
 order by to_char(mti.transfer_date,'MM-YYYY');