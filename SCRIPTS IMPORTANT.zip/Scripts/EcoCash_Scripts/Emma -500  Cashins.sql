select distinct md.ACCOUNT_ID customer_number,p.user_name||' '||p.last_name as customer_name,
md.second_party_account_id Agent_Number,
(select user_name||' '||last_name from ecokash.users where msisdn=md.second_party_account_id and status='Y') Agent_Name
from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
where md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS'
and MD.TRANSFER_VALUE/100=500
and MD.SERVICE_TYPE='CASHIN'
and MD.second_party_account_id in(select msisdn from ecokash.users where status='Y'
AND category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
--and p.created_on >= to_date('10/08/2020','dd/mm/yyyy')  and p.created_on < to_date('14/08/2020','dd/mm/yyyy') + 1
AND ( 
(md.second_party_account_id,md.second_party_category_code) not in (select msisdn,category_code from mmukila.excl_agent)
)
AND md.transfer_date >= to_date('10/08/2020','dd/mm/yyyy')  and md.transfer_date < to_date('14/08/2020','dd/mm/yyyy') + 1;