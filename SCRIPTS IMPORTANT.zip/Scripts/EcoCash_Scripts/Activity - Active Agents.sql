select distinct /*to_char( to_date(md.transfer_date,'DD/MM/YYYY') ,'MON-YY') "MONTH",*/
p.AGENT_CODE, p.MSISDN, p.USER_NAME||''||p.LAST_NAME "NAME",
p.COUNTRY, p.CITY, p.ADDRESS1, p.ADDRESS2,
cat.CATEGORY_NAME, sa.USER_NAME || ' ' || sa.LAST_NAME "SUPER AGENT NAME", p.DESIGNATION "CONTACT STAFF" 
from ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.USERS p, ecokash.mtx_categories cat,
ecokash.USERS sa
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and md.PARTY_ID = p.USER_ID
and md.TRANSFER_STATUS = 'TS'
and cat.domain_code in ('DISTWS')
and p.PARENT_ID = sa.USER_ID
--and md.service_type in('CASHIN','CASHOUT')
--and p.PARENT_ID='PT160907.1552.753082'
and (md.TRANSFER_DATE >= to_date('01/02/2022','dd/mm/yyyy') and md.TRANSFER_DATE <  to_date('14/05/2022','dd/mm/yyyy')+1)
--and md.PAYMENT_TYPE_ID = 11
order by 2;