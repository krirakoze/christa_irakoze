select count(u.msisdn) from ecokash.users u,ecokash.mtx_wallet mw,ecokash.channel_grades cg
where u.msisdn=mw.msisdn
and mw.user_grade = cg.grade_code
and mw.payment_type_id = 12
and u.created_on < to_date('31/12/2019','dd/mm/yyyy')+1
and u.status<>'N'
and mw.status<>'N'
and u.category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and cg.GRADE_CODE in ('ZRT','BRAM');