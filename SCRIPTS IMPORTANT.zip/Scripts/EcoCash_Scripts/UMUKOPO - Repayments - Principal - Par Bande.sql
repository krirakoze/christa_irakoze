select date_format(b2.pay_date,'%M-%Y') pay_month,b1.bande bande,count(distinct customer) customers,sum(b1.request_amount) requested_amount,
sum(b1.interest) interest_amount,sum(b2.paid_amount) paid_amount,b1.num num
from 
(select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'300 - 10000' bande,'1' num
from credit_request_archive
where request_amount >=300 and request_amount <= 10000
union all
select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'10001 - 20000' bande,'2' num
from credit_request_archive
where request_amount >=10001 and request_amount <= 20000
union all
select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'20001 - 30000' bande,'3' num
from credit_request_archive
where request_amount >=20001 and request_amount <= 30000

union all

select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'300 - 10000' bande,'1' num
from credit_request
where request_amount >=300 and request_amount <= 10000
union all
select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'10001 - 20000' bande,'2' num
from credit_request
where request_amount >=10001 and request_amount <= 20000
union all
select  id,convert(date_created,date) request_date,interest,request_amount,subscriber_id customer,'20001 - 30000' bande,'3' num
from credit_request
where request_amount >=20001 and request_amount <= 30000
) b1

inner join

(select convert(recharge_date,date) pay_date,credit_request_id,sum(amount) paid_amount from recharge_log_archive
where convert(recharge_date,date) between '2019-11-01' and '2019-11-30' and recharge_type='PRINCIPAL' group by credit_request_id
union all
select convert(recharge_date,date) pay_date,credit_request_id,sum(amount) paid_amount from recharge_log
where convert(recharge_date,date) between '2019-11-01' and '2019-11-30' and recharge_type='PRINCIPAL' group by credit_request_id) b2

on b1.id=b2.credit_request_id
group by date_format(b2.pay_date,'%M-%Y'),bande
order by b1.num