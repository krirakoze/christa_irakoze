select sum(amount) from(
select LAST_DAY( to_date('01/07/2019','dd/mm/yyyy') ) "Date", to_char( to_date('01/07/2019','dd/mm/yyyy') ,'YYYYMM') "Periode", u.AGENT_CODE, (u.USER_NAME || ' ' || u.LAST_NAME) "CHANNEL_NAME",
coalesce(SUM(DECODE(d.ENTRY_TYPE,'CR', 
d.TRANSFER_VALUE/100, 
- d.TRANSFER_VALUE/100)),0) "AMOUNT",
sa.AGENT_CODE "SA AGENT CODE",
sa.msisdn sa_number,
sa.USER_NAME || ' ' || sa.LAST_NAME SA_NAME
from ecokash.MTX_TRANSACTION_ITEMS d,ecokash.users u,ecokash.USERS sa
where d.PARTY_ID = u.USER_ID
and u.PARENT_ID = sa.USER_ID
and sa.STATUS != 'N'
and u.STATUS != 'N' 
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE not in ('RCOMRIMB','OPTSTKDIS')
and d.category_code in(select category_code from ecokash.mtx_categories where domain_code='DISTWS')
and d.TRANSFER_DATE >= to_date('01/07/2019','dd/mm/yyyy') and d.TRANSFER_DATE < (LAST_DAY( to_date('01/07/2019','dd/mm/yyyy') )+1)
group by u.AGENT_CODE, u.USER_NAME, u.LAST_NAME, sa.AGENT_CODE, sa.USER_NAME, sa.LAST_NAME,sa.msisdn
order by 3);