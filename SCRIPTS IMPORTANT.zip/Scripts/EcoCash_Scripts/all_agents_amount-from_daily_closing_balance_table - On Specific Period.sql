select to_date(closing_date,'dd/mm/yyyy') "DAY",sum(amount) agents_balance from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'EMPLOYER')
and closing_date> = to_date('31/03/2022','dd/mm/yyyy') and closing_date < to_date('31/03/2022','dd/mm/yyyy')+1
group by to_date(closing_date,'dd/mm/yyyy') order by to_date(closing_date,'dd/mm/yyyy');