select mti.second_party_account_id msisdn,
SUM (DECODE(mti.entry_type,
                      'DR', mti.transfer_value / 100,
                      -mti.transfer_value / 100
                     )
             ) AMOUNT 
    FROM ecokash.mtx_transaction_items mti 
    inner join ecokash.mtx_transaction_header mth
    on mth.transfer_id = mti.transfer_id
    inner join  ecokash.sys_service_types sst
    ON mti.SERVICE_TYPE = sst.SERVICE_TYPE
    WHERE mti.transfer_status = 'TS'
     AND mti.wallet_number = '101COMMISSION'
     and mti.entry_type='DR'
     and mti.transaction_type='CP'
     and mti.SECOND_PARTY_CATEGORY_CODE in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
     and mti.second_party_account_id in(select msisdn from temp_nbrs)
    AND mti.transfer_date >= to_date('01/01/2022','dd/mm/yyyy')
    and mti.transfer_date < last_day( to_date('31/01/2022','dd/mm/yyyy') )+1
     group by mti.second_party_account_id order by mti.second_party_account_id;