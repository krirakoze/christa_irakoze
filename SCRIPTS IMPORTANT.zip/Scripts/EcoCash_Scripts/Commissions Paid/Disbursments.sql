select transfer_date,transfer_id,account_id msisdn,transfer_value/100 amount,post_balance/100 balance
from ecokash.mtx_transaction_items where service_type='OPTSTKDIS'
--and payment_type_id=11
and account_id='COMMISSION'
AND transfer_date >= to_date('01/11/2021','dd/mm/yyyy')
AND transfer_date < to_date('02/02/2022','dd/mm/yyyy')+1;