select to_char(transfer_date,'MON-YYYY') "MONTH",SUM(amount) Commission from(
SELECT mti.TRANSFER_ID,mti.transfer_date,
mti.transfer_value / 100 amount,
mti.account_id Transactor
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth WHERE mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
AND mth.transfer_id=mti.transfer_id
AND sst.service_type='RCOMRIMB'
AND mti.PAYMENT_TYPE_ID='11'
AND mti.party_id in (select user_id from ecokash.users where
category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
AND mti.transfer_date >= to_date('01/02/2022','dd/mm/yyyy')
AND mti.transfer_date < to_date('02/02/2022','dd/mm/yyyy')+1
ORDER BY mti.transfer_on
) group by to_char(transfer_date,'MON-YYYY');