select a.msisdn,to_date(a.closing_date,'dd/mm/yyyy') "DAY",sum(a.amount) closing_balance
from mmukila.DAILY_CHANNEL_CLOSING_BALANCE a,ecokash.users u
where a.msisdn=u.msisdn and a.payment_type_id=12 and a.category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and a.closing_date> = to_date('29/02/2020','dd/mm/yyyy') and a.closing_date < to_date('19/05/2021','dd/mm/yyyy')+1
group by a.msisdn,to_date(a.closing_date,'dd/mm/yyyy') order by to_date(a.closing_date,'dd/mm/yyyy');