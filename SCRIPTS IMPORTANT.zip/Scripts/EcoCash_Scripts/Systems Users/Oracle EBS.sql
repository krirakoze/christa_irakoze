SELECT sysdate as "date", fu.user_name, fu.creation_date, case when fu.end_date < sysdate
then 'INACTIVE' 
else
'ACTIVE'
end USER_STATUS , 
fu.LAST_LOGON_DATE, NVL (fu.email_address,
                            per.email_address) email_address,
         frt.responsibility_name, fa.application_name, per.full_name,
         fu.user_id, fu.employee_id, furg.responsibility_id,
         furg.responsibility_application_id
    FROM applsys.fnd_user@PROD_link fu
    left outer join  hr.per_all_people_f@PROD_link per
    on fu.employee_id = per.person_id 
    AND SYSDATE BETWEEN per.effective_start_date AND per.effective_end_date
    left outer join apps.fnd_user_resp_groups@PROD_link furg
    on furg.user_id = fu.user_id
    left outer join applsys.fnd_responsibility_tl@PROD_link frt
    on frt.responsibility_id = furg.responsibility_id
    AND frt.application_id = furg.responsibility_application_id
    AND frt.LANGUAGE = 'US'
    left outer join applsys.fnd_application_tl@PROD_link fa
    on furg.responsibility_application_id = fa.application_id
     AND fa.LANGUAGE = 'US'
     where  per.business_group_id = 83 
     order by 1,  full_name, frt.responsibility_name;