select getdate() as [date], c.userid, b.NAME "SHOP NAME", c.ID "USER_NAME", c.FULLNAME, 
first_login = (select min(a.DATECREATED) from [receipt].[dbo].ACTIVITYLOG a
where a.CASHIER_ID =c.ID and a.SECURITYACTIVITY_ID = '1'),
last_login = (select max(a.DATECREATED) from [receipt].[dbo].ACTIVITYLOG a
where a.CASHIER_ID =c.ID and a.SECURITYACTIVITY_ID = '1') ,
s.ACTIVITYNAME, 
case cc.CANDO
when 0 then 'No'
else 'Yes' end [can do]
from [receipt].[dbo].CASHIER c
left outer join [receipt].[dbo].BRANCH b
on c.BRANCH_ID = b.ID
left outer join [receipt].[dbo].CASHIERSECURITYACTIVITY cc
on c.ID = cc.CASHIER_ID
--and cc.SECURITYACTIVITY_ID = '1'
left outer join [receipt].[dbo].SECURITYACTIVITY s
on s.ID = cc.SECURITYACTIVITY_ID
where b.ID <> 'ADM' --//exclude Administration branch
--and cc.CANDO = 1
order by c.FULLNAME, s.ACTIVITYNAME