select 'cashin local' service_name, sum(decode(mti.entry_type,'DR',1,'CR',-1,0)) cnt,
sum(decode(mti.entry_type,'DR',mti.transfer_value,-mti.transfer_value)/100) amount
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s,
ecokash.mtx_wallet w
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 12
and mti.service_type = s.service_type
and mti.transfer_status = 'TS'
and mti.wallet_number = w.wallet_number
and w.user_grade <> 'REMAGENT'

AND (
mth.SERVICE_TYPE IN ('CASHIN')
AND mti.TRANSACTION_TYPE = 'MP'
OR (
mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('CASHIN')
AND mti.TRANSACTION_TYPE = 'MR')
)) 
and trunc(mti.transfer_date) between to_date('01/02/2019','dd/mm/yyyy') and trunc(last_day(to_date('01/02/2019','dd/mm/yyyy')));