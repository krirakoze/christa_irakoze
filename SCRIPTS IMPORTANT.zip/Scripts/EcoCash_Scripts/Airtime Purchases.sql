select mti.transfer_date, mti.second_party_account_id subs_msisdn,
mti.account_id airtime_account, s.service_name, mti.entry_type,
decode(mti.entry_type,'CR',mti.transfer_value,-mti.transfer_value)/100 amount_transfered
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 12
and mti.service_type = s.service_type
and mti.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT')
and mti.transfer_status = 'TS'

AND (
mth.SERVICE_TYPE IN ('RC')
AND mti.TRANSACTION_TYPE = 'MR'
OR (
mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d
where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('RC')
AND mti.TRANSACTION_TYPE = 'MP')
))
and mti.transfer_date >= to_date('01/12/2019','dd/mm/yyyy')
and mti.transfer_date < to_date('29/02/2020','dd/mm/yyyy') + 1
order by mti.transfer_date;