select first_trx_date, 
service, cnt from
(
select trunc(first_trx_date) first_trx_date, 
'FS Activations' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det,
ecokash.mtx_wallet w
where w.user_id = det.SECOND_PARTY_ACCOUNT
and w.user_grade in ('ZRT','BRAM')
and det.service_type = 'CASHIN'
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'FS Activations'
union all
select trunc(first_trx_date) first_trx_date, 
'Bulk Disbursement(Payroll)' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type in ('PAYROLL','MTREQ')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Bulk Disbursement(Payroll)'
union all
select trunc(first_trx_date) first_trx_date, 
'Banking services' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type in  ('CBWREQ','CWBREQ')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Banking services'
union all
select trunc(first_trx_date) first_trx_date, 
'Merchants and Billers' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type in  ('MERCHPAY','SUBMPREQ','BILLPAY')
and det.SECOND_PARTY_ACCOUNT <> (select user_id from ecokash.users where msisdn = '72129874')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Merchants and Billers'
union all
select trunc(first_trx_date) first_trx_date, 
'Remittances' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det,
ecokash.mtx_wallet w
where w.user_id = det.SECOND_PARTY_ACCOUNT
and w.user_grade in ('REMAGENT0','REMAGENT1','REMAGENT','REMAGENT2')
and det.service_type = 'CASHIN'
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Remittances'
union all
select trunc(first_trx_date) first_trx_date, 
'Airtime' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type in  ('RC')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Airtime'
union all
select trunc(first_trx_date) first_trx_date, 
'Saving Club' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type in  ('DEPOCLUB','WITHCLUB')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Saving Club'
union all
select trunc(first_trx_date) first_trx_date, 
'VIVA MALT' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.service_type = 'MPSUBREQ'
and det.SECOND_PARTY_ACCOUNT = (select user_id from ecokash.users where msisdn = '72129874')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'VIVA MALT'
union all
select trunc(first_trx_date) first_trx_date, 
'Agent Channel' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det,
ecokash.mtx_wallet w
where w.user_id = det.SECOND_PARTY_ACCOUNT
and w.user_grade not in ('ZRT','BRAM')
and det.service_type = 'CASHIN'
and det.second_party_category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Agent Channel'
union all
select trunc(first_trx_date) first_trx_date, 
'Innactive MNO' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
where det.subs_msisdn in (select msisdn from request_info)
group by trunc(first_trx_date),'Innactive MNO'
union all
select trunc(first_trx_date) first_trx_date, 
'Airtime 2 Money' service, count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det,
ecokash.mtx_wallet w
where w.user_id = det.SECOND_PARTY_ACCOUNT
and w.user_grade in ('Airt2money')
and det.service_type = 'CASHIN'
and det.SECOND_PARTY_ACCOUNT = (select user_id from ecokash.users where msisdn = '76071273')
and det.subs_msisdn not in (select msisdn from request_info)
group by trunc(first_trx_date),'Airtime 2 Money'
) where first_trx_date between '09-JUL-21' and '22-JUL-21'
order by first_trx_date, service;