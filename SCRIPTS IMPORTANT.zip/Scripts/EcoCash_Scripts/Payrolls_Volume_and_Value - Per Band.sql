SELECT count(distinct mti.transfer_id) cnt, SUM(mti.transfer_value/100) amount   
  FROM ecokash.mtx_transaction_items mti,
       ecokash.mtx_transaction_header mth
 WHERE mti.transaction_type = 'MR'
   AND mti.service_type in ('PAYROLL','MTREQ')
   AND mti.transfer_status = 'TS'
   AND mth.transfer_status = 'TS'
   AND mti.transfer_id = mth.transfer_id
   AND mti.transfer_value/100 between 400001 AND 500000
    AND mti.transfer_date >= to_date('01/06/2020','dd/mm/yyyy') and mti.transfer_date < to_date('30/06/2020','dd/mm/yyyy') + 1;