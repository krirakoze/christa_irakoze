select mti.account_id, to_char(mti.TRANSFER_DATE,'MM-YYYY') date_x, sum(decode(mti.entry_type,'CR',mti.transfer_value,-mti.transfer_value)/100) amount
from ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth, ecokash.SYS_SERVICE_TYPES s, ecokash.mtx_wallet w
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 12
and mti.service_type = s.service_type
and mti.transfer_status = 'TS' 
and mti.wallet_number = w.wallet_number
AND mti.party_id in(select user_id from ecokash.users where msisdn='71031251')
AND ( mth.SERVICE_TYPE IN ('O2C') AND mti.TRANSACTION_TYPE = 'MR'  OR (
     mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
     and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
     where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN  ('O2C')
     AND mti.TRANSACTION_TYPE = 'MP') )  )   
and  mti.TRANSFER_DATE>='01-JAN-2015' and mti.TRANSFER_DATE<'18-APR-2019'
group by mti.account_id,to_char(mti.TRANSFER_DATE,'MM-YYYY') order by to_char(mti.TRANSFER_DATE,'MM-YYYY');
