--Accounts for IBB and FinBank
select b.bank_name, mti.transfer_id, mti.TRANSFER_ON, s.service_name service,
mti.TRANSACTION_TYPE, mti.entry_type, mti.transfer_Value/100 "transfer value", 
mti.POST_BALANCE/100 "post balance", (select agent_code from ecokash.users u
where mto.PARTY_ID = u.user_id) "agent code"
from ecokash.mtx_transaction_items mti
inner join ECOKASH.mtx_transaction_header mth
on mti.transfer_id = mth.transfer_id
inner join ecokash.SYS_SERVICE_TYPES s
on mti.service_type = s.service_type
inner join ECOKASH.MBK_BANK_DETAILS b
on mti.wallet_number = b.bank_id
left outer join ecokash.mtx_transaction_items mto
on mth.ATTR_3_NAME = mto.transfer_id
and mto.category_code <> 'OPT'
where mti.transfer_status = 'TS'
and mti.transfer_date >= to_date('01/07/2019','dd/mm/yyyy') and mti.transfer_date < to_date('01/08/2019','dd/mm/yyyy')
and b.bank_id in('IND0410150','IND0410151','IND0410183','IND0410182')
order by b.bank_name, mti.transfer_date, mti.TXN_SEQUENCE_NUMBER;