insert into gsingaya.YTD_2019(MSISDN,MIN_TRX_DATE)
select subscriber, min(trx_date) from
(
    select md.ACCOUNT_ID subscriber,md.transfer_date trx_date
    from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
    where md.PARTY_ID = p.USER_ID
    and length(md.ACCOUNT_ID) <= 8
    and md.TRANSFER_STATUS = 'TS' 
    and md.SECOND_PARTY_ACCOUNT_ID not in (select msisdn from EXCL_AGENT) --excluding channels created by the Business for internal promotions
    and md.TRANSFER_DATE >= to_date('02/07/2019','dd/mm/yyyy') and md.TRANSFER_DATE < to_date('03/07/2019','dd/mm/yyyy')
    and md.ACCOUNT_ID not in(
        select distinct subscriber from
        (
            select md.transfer_date "date", md.ACCOUNT_ID subscriber
            from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
            where md.PARTY_ID = p.USER_ID
            and length(md.ACCOUNT_ID) <= 8
            and md.TRANSFER_STATUS = 'TS' 
            and md.SECOND_PARTY_ACCOUNT_ID not in (select msisdn from EXCL_AGENT) --excluding channels created by the Business for internal promotions
            and md.TRANSFER_DATE >= to_date('01/03/2019','dd/mm/yyyy') and md.TRANSFER_DATE < to_date('02/07/2019','dd/mm/yyyy')
        )
    )
)
group by subscriber;
commit;