select c.user_name || ' ' || c.last_name customer_name,
c.msisdn customer_phone_number, cg.grade_name, 
decode(c.status,'Y','ACTIVE','N','INACTIVE','S','SUSPENDED',c.status) status,
sst.service_name type_of_transaction,
coalesce(md.transfer_value/100,0) amount, 
coalesce(wb.balance/100,0) balance, last_date
from ecokash.users c
left outer join 
(
select max(d.TRANSFER_ON) "LAST_DATE", d.ACCOUNT_ID from ecokash.MTX_TRANSACTION_ITEMS d
where d.TRANSFER_STATUS = 'TS'
  and d.CATEGORY_CODE in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
  and d.service_type not in ('ROLLBACK','TXNCORRECT','RCOMRIMB','OPTSTKDIS')
--and not exists (select h.TRANSFER_ID from ecokash.MTX_TRANSACTION_HEADER h where h.SERVICE_TYPE in ('ROLLBACK','TXNCORRECT') and h.ATTR_3_VALUE = d.TRANSFER_ID and h.TRANSFER_STATUS = 'TS')
and d.transaction_type in ('MP','MR')
and d.PAYMENT_TYPE_ID = 12
AND ((d.account_id,d.category_code) not in (select msisdn,category_code from mmukila.excl_agent))
group by d.ACCOUNT_ID
) F on F.ACCOUNT_ID = c.msisdn
left outer join ecokash.MTX_TRANSACTION_ITEMS md
on F.LAST_DATE = md.TRANSFER_ON
and md.PARTY_ID = c.USER_ID
and md.payment_type_id = 12
left outer join  ECOKASH.SYS_SERVICE_TYPES sst
on md.service_type = sst.service_type
left outer join ecokash.mtx_wallet w
on w.user_id = c.user_id
and w.payment_type_id =12
left outer join ecokash.channel_grades cg
on w.user_grade = cg.grade_code
left outer join ECOKASH.MTX_WALLET_BALANCES wb
on w.wallet_number = wb.wallet_number
where c.parent_id = 'PT160503.1505.769320'
order by 2;