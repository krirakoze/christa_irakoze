select b.account_number msisdn,h.user_barred_on Barred_On,
case when b.reason ='PIN_INVL' then 'Invalid PIN/Password Attempt' else b.reason end Reason
from ecokash.MTX_PARTY_BLACK_LIST b,ecokash.MTX_PARTY_BARRED_HIST h
where b.account_number=h.msisdn
and b.account_number in
(
'76082628','76082026','72286434'
)
and h.unbarred_on is null and h.unbarred_by is null and h.unbarring_type is null
and h.user_barred_on=(select max(ht.user_barred_on) from ecokash.MTX_PARTY_BARRED_HIST ht where ht.msisdn=b.account_number)
order by b.created_on
;