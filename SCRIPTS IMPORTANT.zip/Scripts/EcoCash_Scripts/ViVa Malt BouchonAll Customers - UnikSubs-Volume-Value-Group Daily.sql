select trunc(transfer_date) day,count(distinct customer_number) unique_subs,count(TRANSFER_ID) volume,sum(amount) value from(
SELECT mti.transfer_date, mti.TRANSFER_ID,  (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) amount, second_party_account_id customer_number,(select m.user_name||'-'||m.last_name from ecokash.mtx_party m where m.user_id = mti.second_party) customer_name,  (select u.agent_code from ecokash.users u where u.user_id = mti.party_id) merchant_code, 
           (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) merchant_number, 
           (select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) channel_name,sst.SERVICE_NAME, mth.REMARKS,
 mti.POST_BALANCE/100 post_balance, mti.ENTRY_TYPE
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     --and mti.transfer_id like 'MP%'
     and mti.party_id = (select user_id from ecokash.users where msisdn = '72129874'
     and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER'))
AND mti.transfer_date >= to_date('08/09/2020','dd/mm/yyyy') and mti.transfer_date < ( to_date('10/09/2020','dd/mm/yyyy') + 1 )
 order by mti.transfer_date
 )
 group by trunc(transfer_date) order by trunc(transfer_date);