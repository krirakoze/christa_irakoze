SELECT 'P2P Revenue' description,to_char(mti.transfer_date,'MON-YYYY') "MONTH",
count(distinct mti.TRANSFER_ID) volume ,
SUM (mti.transfer_value / 100) value,count(distinct mti.party_id) uniq_subs,
SUM (mti2.transfer_value / 100) revenue
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2,
ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS' AND mti.transfer_id=mti2.transfer_id AND mti.service_type = sst.service_type
and mth.transfer_id=mti.transfer_id  and mti2.wallet_number = '101COMMISSION'
and mti.category_code in('SUBS')
and mti.transaction_type = 'MP'
AND mth.service_type in('P2P')
and mti.service_type not in('ROLLBACK','TXNCORRECT')
AND mti.transfer_date >= to_date('26/10/2021','dd/mm/yyyy') and mti.transfer_date < to_date('14/12/2021','dd/mm/yyyy') + 1
AND mti.transfer_value / 100 between 500 and 1070
GROUP BY 'P2P Revenue', to_char(mti.transfer_date,'MON-YYYY');