select 'Subscribers' category, count(distinct md.account_id) "CNT",
SUM(decode(md.entry_type, 'CR', md.transfer_value/100, -md.transfer_value/100)) "amount"
from ECOKASH.MTX_TRANSACTION_ITEMS md,
ecokash.mtx_party u
where md.transfer_status = 'TS'
and md.PAYMENT_TYPE_ID = 12
and md.PARTY_ID = u.USER_ID
and trunc(md.transfer_date) <= to_date('28-02-2017','dd-mm-yyyy');