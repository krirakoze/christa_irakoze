SELECT mti.transfer_date trx_date,  mti.transfer_id trx_id,
(select u.agent_code from ecokash.users u where u.user_id = mti.party_id  and u.status = 'Y') agent_code, 
(select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') agent_number, 
(select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.party_id) agent_name,
(DECODE (mti.entry_type,'DR', -mti.transfer_value/100,mti.transfer_value/100)) trx_amount ,mti.post_balance/100 post_balance,
mti.second_party_account_id receiver_Sender_Number,
(select mtp.user_name||' - '||mtp.last_name from ecokash.users mtp where mtp.user_id = mti.second_party) Receiver_Sender_Name,
             sst.service_type
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') AND mti.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
     AND mti.transfer_id = mth.transfer_id
     AND mti.party_id in (select user_id from ecokash.users where msisdn in (select msisdn from temp_nbrs)
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
    and mti.second_party not in(select user_id from ecokash.users where msisdn in (select msisdn from temp_nbrs)
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
    and mti.payment_type_id=12 and mti.entry_type='CR' and sst.service_type='P2P' order by 1;