select mh.CREATED_ON INITIATED_ON, ui.user_name || ' ' || ui.last_name INITIATED_BY,
decode(md.second_party_account_id,'IND0110182','IBB','') WITHDRAWAL_FROM,
md.transfer_date, md.transfer_id, u.AGENT_CODE CHANNEL_CODE,
md.account_id CHANNEL_MSISDN, cat.CATEGORY_NAME CHANNNEL_CATEGORY,
md.transfer_value/100 amount,
op.user_name || ' ' || op.last_name APPROVED_BY,
(select bank_name from ecokash.MBK_BANK_DETAILS where op.ATTR1_VALUE = bank_id) APPROVER_BANK,
mh.MODIFIED_ON APPROVED_ON,
mhst.transfer_id mirror_transfer_id, mhst.transfer_status mirror_transfer_status, 
mdst.transfer_value/100 mirror_transfer_value,
(select bank_name from ecokash.MBK_BANK_DETAILS where mdst.party_id = bank_id) MIRROR_BANK
from ecokash.mtx_transaction_items md
left outer join ecokash.mtx_transaction_header mh
on md.transfer_id = mh.transfer_id
left outer join ecokash.mtx_transaction_header mhst
on md.transfer_id = mhst.reference_number
left outer join ecokash.mtx_transaction_items mdst
on mhst.transfer_id = mdst.transfer_id
and mdst.TRANSACTION_TYPE = 'MR'
left outer join ecokash.users u
on md.PARTY_ID = u.USER_ID
left outer join ecokash.MTX_CATEGORIES cat
on md.CATEGORY_CODE = cat.CATEGORY_CODE
left outer join ecokash.users op
on mh.MODIFIED_BY = op.USER_ID
left outer join ecokash.users ui
on mh.CREATED_BY = ui.USER_ID
where md.service_type = 'OPTW'
and md.transfer_status = 'TS'
and md.CATEGORY_CODE <> 'OPT'
and md.transfer_id in
(
'OW190909.0919.A00022'
)
order by 1
;