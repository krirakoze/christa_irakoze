SELECT  'Fee Incomes' description,'01/07/2022' FROM_DATE,'31/07/2022' TO_DATE,
mti.second_party_account_id SUB_ACCOUNT,
SUM (DECODE (mti.entry_type,
                      'DR', -mti.transfer_value / 100,
                      mti.transfer_value / 100
                     )
             ) REVENUE
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_header mth
   WHERE mti.transfer_id = mth.transfer_id
    AND mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.wallet_number = '101IND03'
     AND mti.service_type != 'REQOPTPW'
     and not exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d
    where d.TRANSFER_ID = mth.reconciliation_by and d.SERVICE_TYPE IN  ('ROLLBACK','TXNCORRECT'))
    AND mti.transfer_date >= to_date('01/07/2022','dd/mm/yyyy') and mti.transfer_date < to_date('31/07/2022','dd/mm/yyyy') + 1
     GROUP BY mti.second_party_account_id;