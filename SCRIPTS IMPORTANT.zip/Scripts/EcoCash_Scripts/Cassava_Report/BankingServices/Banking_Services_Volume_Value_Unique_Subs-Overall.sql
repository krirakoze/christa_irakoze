select to_char(transfer_date,'MON-YYYY') month,bank_name,count(distinct transfer_id) volume,
sum(TRANSFER_VALUE) value,count(distinct mobile_number) unique_subs,count(distinct bank_id) unik_active_partners from(
select b.bank_id,b.bank_name, mti.transfer_id, mti.TRANSFER_ON,mti.TRANSFER_DATE, s.service_name service,
mti.TRANSACTION_TYPE, mti.entry_type, mti.transfer_Value/100 "TRANSFER_VALUE", 
mti.POST_BALANCE/100 "POST_BALANCE", (select agent_code from ecokash.users u
where mto.PARTY_ID = u.user_id) "AGENT_CODE",
mti.second_party_account_id mobile_number
from ecokash.mtx_transaction_items mti
inner join ECOKASH.mtx_transaction_header mth
on mti.transfer_id = mth.transfer_id
inner join ecokash.SYS_SERVICE_TYPES s
on mti.service_type = s.service_type
inner join ECOKASH.MBK_BANK_DETAILS b
on mti.wallet_number = b.bank_id
left outer join ecokash.mtx_transaction_items mto
on mth.ATTR_3_NAME = mto.transfer_id
and mto.category_code <> 'OPT'
where mti.transfer_status = 'TS'
and mti.category_code='SUBS'
and s.service_type in('CBWREQ','RBWREQ','CWBREQ','RWBREQ')
and mti.transfer_date >= to_date('01/07/2020','dd/mm/yyyy')
and mti.transfer_date < to_date('30/09/2020','dd/mm/yyyy')+1
--and b.bank_id in('IND0410150','IND0410151')
--and b.bank_id in('IND0410182','IND0410183')
order by b.bank_name, mti.transfer_date, mti.TXN_SEQUENCE_NUMBER
) group by bank_name,to_char(transfer_date,'MON-YYYY') 
;