select count(distinct Res.transfer_id) VOLUME,sum(Res.amount) VALUE ,
count(distinct Res.second_party) unique_subs from
(
select trunc(mti.transfer_date) transf_date,mti.transfer_id ,mti.party_id, mti.second_party, service_name,
decode(mti.entry_type,'DR',-mti.transfer_value,mti.transfer_value)/100 amount
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s 
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 13
and mti.service_type = s.service_type
and mti.transfer_status = 'TS'

AND (
mth.SERVICE_TYPE IN ('WITHCLUB')
AND mti.TRANSACTION_TYPE = 'MP'
OR (
mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('WITHCLUB')
AND mti.TRANSACTION_TYPE = 'MR')
)) 
and mti.transfer_date >= to_date('01/01/2020','dd/mm/yyyy') and mti.transfer_date < to_date('31/01/2020','dd/mm/yyyy')+1
) Res, ecokash.mtx_party subs
Where Res.second_party = subs.user_id
order by 1;