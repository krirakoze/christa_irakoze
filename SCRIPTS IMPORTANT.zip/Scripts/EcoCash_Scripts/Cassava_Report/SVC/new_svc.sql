select count(club_id) new_svc from ecokash.svc_saving_club
where created_on>=to_date('01/03/2018','dd/mm/yyyy') and created_on<to_date('31/01/2019','dd/mm/yyyy')+1
and status in('Y','A');