select count(club_id) all_svc from ecokash.svc_saving_club
where created_on < to_date('23/10/2020','dd/mm/yyyy')+1
and status in('Y','A');