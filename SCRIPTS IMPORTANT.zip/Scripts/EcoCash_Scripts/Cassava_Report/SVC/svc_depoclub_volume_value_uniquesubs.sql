select count(distinct Res.transfer_id) VOLUME,sum(Res.amount) VALUE ,
count(distinct Res.second_party) unique_subs
from
(
select trunc(mti.transfer_date) transf_date, mti.transfer_id,mti.party_id, mti.second_party, s.SERVICE_NAME,
mti.transfer_value/100 amount,c.club_name,c.club_id
	from ecokash.mtx_transaction_items mti,
	ecokash.mtx_transaction_header mth,
	ecokash.SYS_SERVICE_TYPES s,
    ecokash.SVC_SAVING_CLUB c
	where mti.transfer_id = mth.transfer_id
	and mti.payment_type_id = 13
    and mti.party_id=c.ADMIN_ID
	and mti.service_type = s.service_type
	and mti.transfer_status = 'TS'
	and mti.TRANSACTION_TYPE = 'MR'
	AND (
	mth.SERVICE_TYPE IN ('DEPOCLUB')
	AND mti.TRANSACTION_TYPE = 'MR'
	OR (
	mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
	and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
	where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('DEPOCLUB')
	AND mti.TRANSACTION_TYPE = 'MP')
	))
    and c.club_id in(
    '8818865',
'8819418',
'8822015',
'8823099',
'8820605',
'8815610',
'8816045',
'8817663',
'8822313',
'8820019',
'8822039',
'8821598',
'8820863',
'8821190',
'8820650',
'8818870',
'8818254',
'8822337',
'8820643',
'8822480',
'8814019',
'8818279',
'8820573',
'8822941',
'8821127',
'8821602',
'8814555',
'8818586'
    )
    and mti.transfer_date >= to_date('01/09/2021','dd/mm/yyyy')  and mti.transfer_date < to_date('18/03/2022','dd/mm/yyyy')+1
)Res,ecokash.mtx_party subs
Where Res.second_party = subs.user_id;