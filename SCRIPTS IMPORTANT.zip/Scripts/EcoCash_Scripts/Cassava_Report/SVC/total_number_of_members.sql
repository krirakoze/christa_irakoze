select count(member_id) svc_members from ecokash.svc_members
where created_on<to_date('31/01/2020','dd/mm/yyyy') and status in('Y','AI');