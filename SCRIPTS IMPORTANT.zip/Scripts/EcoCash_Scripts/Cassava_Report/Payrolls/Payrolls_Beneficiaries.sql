select count(distinct employee_id) payroll_employees from(
select trunc(pe.created_on) created_on,pe.employee_id,p.msisdn Employee_Number,p.user_name||' '||p.last_name Employee_Name,pe.status_id pe_status,
u.agent_code Payroll_Code,u.msisdn Payroll_Number,u.user_name||' '||u.last_name Payroll_Name
from ecokash.mtx_party p,ecokash.users u,ecokash.mtx_payroll_employees pe
where p.user_id=pe.user_id
and pe.payroll_company_id=u.user_id
and p.status='Y'
and u.status='Y'
and pe.status_id='Y'
and pe.created_on < to_date('19/05/2021','dd/mm/yyyy')+1
);