select count(distinct a.msisdn) billers_closing_base
from ecokash.users a, ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where a.status != 'N'
and  a.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.status != 'N'
and w.USER_GRADE = g.GRADE_CODE
and a.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code in ('MERCHANT')) 
and a.created_on < to_date('31/01/2020','dd/mm/yyyy') + 1
and a.AGENT_CODE is not null
order by a.AGENT_CODE;