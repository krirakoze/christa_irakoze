select count(distinct p.MSISDN) active_billers
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s,
ecokash.users p
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 12
and mti.service_type = s.service_type
and mti.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT')
AND (mti.second_party_account_id) NOT IN (select u.BILLER_CODE from mmukila.REMITT_BILLERS_CODE u)
and mti.transfer_status = 'TS'
and mti.second_party_category_code = 'SUBS'
and mti.party_id != 'TOPUP4ECONET'
and mti.party_id = p.user_id

AND (
     mth.SERVICE_TYPE IN  ('BILLPAY')
     AND mti.TRANSACTION_TYPE = 'MR'
     OR (
     mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
     and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
     where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN  ('BILLPAY')
     AND mti.TRANSACTION_TYPE = 'MP')
     )) 
and  mti.TRANSFER_DATE < ( to_date('31/01/2020','dd/mm/yyyy') + 1 ) ;