SELECT a.PHONE_NUMBER FS_NUMBER,s.ACC_NBR SUBS_NBR,a.CUST_NAME SUBS_NAME,
		DECODE (l.VERIFY_RESULT,'Y','APPROVED','N','REJECTED') VERIFY_STATUS, TO_CHAR(l.VERIFY_DATE,'DD/MM/YYYY HH24:MI:SS') VERIFY_DATE
		FROM cc.cust@link_cc a, cc.subs@link_cc s, cc.econetleo_cust_verify@link_cc l, cc.bfm_staff@link_cc m, cc.prod@link_cc p
		WHERE l.cust_id = a.cust_id
		AND a.cust_id = s.cust_id
		AND l.party_code = m.staff_id
		AND p.prod_id = s.subs_id
		AND trunc(l.verify_date) >= to_date('08/02/2022','dd/mm/yyyy') and trunc(l.verify_date) < to_date('28/02/2022','dd/mm/yyyy') + 1
		and create_party_type = 'T'  and length(PHONE_NUMBER)=8 and PHONE_NUMBER IN (
        '71213202',
'71256799',
'71258961',
'71260927',
'71260981',
'71273419',
'71396427',
'71489007',
'71704236',
'71846661',
'71999822',
'72417802',
'76710636',
'76738691',
'76946886',
'79104761',
'79299803',
'79777455',
'79985603',
'71481077'
)
and l.VERIFY_RESULT='Y';