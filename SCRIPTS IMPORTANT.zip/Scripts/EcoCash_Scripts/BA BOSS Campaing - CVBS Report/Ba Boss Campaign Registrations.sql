SELECT CUST_NBR,FS_NUMBER,STAFF_AUDITOR,CUST_NAME,VERIFY_STATUS,VERIFY_DATE,COMMENTS,STATUS
from
	(
		SELECT   s.ACC_NBR CUST_NBR,a.PHONE_NUMBER FS_NUMBER,m.STAFF_NAME STAFF_AUDITOR, a.CUST_NAME,
		DECODE (l.VERIFY_RESULT,'Y','APPROVED','N','REJECTED') VERIFY_STATUS, TO_CHAR(l.VERIFY_DATE,'DD/MM/YYYY HH24:MI:SS') VERIFY_DATE,l.COMMENTS, 
		DECODE (p.prod_state,'A', 'ACTIVE','D', '1WAY BLOCK','E', '2WAY BLOCK','G', 'INACTIVE','B', 'TERMINATED') STATUS
		FROM cust@link_cc a, subs@link_cc s, econetleo_cust_verify@link_cc l, bfm_staff@link_cc m, prod@link_cc p
		WHERE l.cust_id = a.cust_id
		AND a.cust_id = s.cust_id
		AND l.party_code = m.staff_id
		AND p.prod_id = s.subs_id
		AND trunc(l.verify_date) >= to_date('01/06/2021','dd/mm/yyyy') and trunc(l.verify_date) < to_date('06/06/2021','dd/mm/yyyy') + 1
		and create_party_type = 'T'  and length(PHONE_NUMBER)=8 and PHONE_NUMBER IN (
        '79508230',
'76037998',
'72452495',
'76574025',
'71599762',
'76168687',
'76363170',
'79528815',
'72019063',
'71502282'
                )
                and l.VERIFY_RESULT='Y'
	)
order by VERIFY_DATE;