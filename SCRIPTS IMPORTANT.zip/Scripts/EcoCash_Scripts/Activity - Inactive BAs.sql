select p.AGENT_CODE,p.MSISDN,p.USER_NAME||''||p.LAST_NAME "NAME",
p.COUNTRY,p.CITY,p.ADDRESS1,p.ADDRESS2,cat.CATEGORY_NAME,
sa.USER_NAME || ' ' || sa.LAST_NAME "SUPER AGENT NAME",
p.DESIGNATION "CONTACT STAFF" 
from ecokash.USERS p,
ecokash.USERS sa,
ecokash.mtx_wallet w,
ecokash.mtx_categories cat,
ecokash.channel_grades g
where p.msisdn=w.msisdn
and p.CATEGORY_CODE = cat.CATEGORY_CODE
and p.STATUS = 'Y'
and cat.domain_code in ('DISTWS')
and g.grade_code in('ZRT','BRAM') --grades for BAs
and p.PARENT_ID = sa.USER_ID
and w.user_grade=g.grade_code
and p.USER_ID NOT IN
(
select distinct p.USER_ID
from
ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.USERS p,
ecokash.USERS sa,
ecokash.mtx_wallet w,
ecokash.mtx_categories cat,
ecokash.channel_grades g
where
md.PARTY_ID = p.USER_ID
and p.msisdn=w.msisdn
and p.CATEGORY_CODE = cat.CATEGORY_CODE
and md.TRANSFER_STATUS = 'TS'
and cat.domain_code in ('DISTWS')
and g.grade_code in('ZRT','BRAM') --grades for BAs
and p.PARENT_ID = sa.USER_ID
and w.user_grade=g.grade_code
and (md.TRANSFER_DATE >= to_date('01/02/2022','dd/mm/yyyy')
and md.TRANSFER_DATE <  to_date('03/05/2022','dd/mm/yyyy')+1)
)
order by 2;