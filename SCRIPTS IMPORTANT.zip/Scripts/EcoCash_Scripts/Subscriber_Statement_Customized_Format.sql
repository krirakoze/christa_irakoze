select md.TRANSFER_ID "Transfer Id", md.TRANSFER_DATE "Transfer On",s.service_name "Service Name",
md.transaction_type "Transaction Type",md.entry_type "CR/DR",
(DECODE(md.second_party_account_id,'IND03',
                        'Fee Income Account',
                        md.second_party_account_id
                        )
            ) "Mobile Number",
(DECODE (md.entry_type,
         'DR', -md.transfer_value/100,
          md.transfer_value/100
    )
 ) "Transaction Value",md.post_balance/100 "Post Balance" ,
  p.msisdn "Transactor"
 from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN = '79510802' and p.STATUS != 'N'
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and md.transfer_date >= to_date('03/09/2019','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
order by md.TRANSFER_DATE;