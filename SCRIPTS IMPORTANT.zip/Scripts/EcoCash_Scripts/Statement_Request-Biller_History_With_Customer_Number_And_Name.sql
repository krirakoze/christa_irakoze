SELECT mti.transfer_date trx_date,  mti.transfer_id trx_id,  (select u.agent_code from ecokash.users u where u.user_id = mti.party_id  and u.status = 'Y') user_code, 
(select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') user_number, 
 (select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.party_id) biller_name, (DECODE (mti.entry_type,
                      'DR', -mti.transfer_value/100,
                      mti.transfer_value/100
                     )
             ) trx_amount ,
             mti.second_party_account_id sender_receiver_number,
             (select mtp.user_name||' - '||mtp.last_name from ecokash.mtx_party mtp where mtp.user_id = mti.second_party) customer_name,sst.service_name, mth.ATTR_1_VALUE "COMMENT"
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('01/02/2020','dd/mm/yyyy') and mti.transfer_date < to_date('13/07/2020','dd/mm/yyyy')+1
     AND mti.transfer_id = mth.transfer_id
     --AND mti.entry_type='DR'
     --AND sst.service_type='OPTW'
     AND mti.party_id in (select user_id from ecokash.users where msisdn in ('76241110')
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT'))
order by 1;
