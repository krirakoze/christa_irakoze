SELECT sst.service_name description,to_char(mti.transfer_date,'MON-YYYY') "MONTH",
count(distinct mth.attr_3_value) "UNIQUE_SUBS",
count(distinct mti.transfer_id) "VOLUME" , SUM (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) amount
  FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
 WHERE mti.transfer_status = 'TS'
   AND mth.transfer_status = 'TS'
   AND mti.transfer_id LIKE 'RC%'
   AND mti.service_type = sst.service_type
   AND mti.wallet_number = '100000000000001'
   AND MTI.SECOND_PARTY_CATEGORY_CODE ='SUBS'
   and mti.transfer_id = mth.transfer_id
    AND mti.transfer_date >= to_date('01/04/2021','dd/mm/yyyy') and mti.transfer_date < to_date('30/04/2021','dd/mm/yyyy') + 1
    GROUP BY sst.service_name , to_char(mti.transfer_date,'MON-YYYY');