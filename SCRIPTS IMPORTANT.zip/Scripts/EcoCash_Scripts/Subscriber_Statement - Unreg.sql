select h.transfer_date,h.transfer_id,h.transfer_value amount,h.serial_number approval_code,h.attr_3_value msisdn
from ecokash.mtx_transaction_header h where h.transfer_status = 'TS'
and trunc(h.transfer_date) >= to_date('01/01/2022','dd/mm/yyyy') and trunc(h.transfer_date) < to_date('14/06/2022','dd/mm/yyyy')+1
and (
    (h.service_type= 'P2PNONREG'
    and not exists (select mh.reference_number from ecokash.mtx_transaction_header mh where mh.REFERENCE_NUMBER = h.TRANSFER_ID
    and mh.transfer_status = 'TS' and mh.SERVICE_TYPE = 'COUTBYCODE')
    )
or
    (
        (h.service_type = 'SALUNREG'
        and not exists (select mh.transfer_id from ecokash.mtx_transaction_header mh where mh.transfer_id = h.ext_txn_number
        and mh.transfer_status = 'TS' and mh.SERVICE_TYPE = 'COFORUNREG')
        )
    )
)
and h.attr_3_value='79444666'
and not exists (select mh.TRANSFER_ID from ecokash.MTX_TRANSACTION_HEADER mh
where h.TRANSFER_ID = mh.ATTR_2_VALUE and mh.service_type IN ('ROLLBACK','TXNCORRECT') and mh.transfer_status = 'TS')
order by h.transfer_date;