select p.AGENT_CODE, p.MSISDN, p.USER_NAME||''||p.LAST_NAME "NAME",
p.COUNTRY, p.CITY, p.ADDRESS1, p.ADDRESS2,
cat.CATEGORY_NAME, sa.USER_NAME || ' ' || sa.LAST_NAME "SUPER AGENT NAME", p.DESIGNATION "CONTACT STAFF" 
from ecokash.USERS p, ecokash.mtx_categories cat,
ecokash.USERS sa
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and p.STATUS = 'Y'
and cat.domain_code in ('DISTWS')
and p.PARENT_ID = sa.USER_ID
--and p.PARENT_ID='PT160907.1552.753082'

--and (
--lower(p.CITY) like '%bujumbura%rural%' or lower(p.CITY) like '%muram%' or lower(p.CITY) like '%mwar%' or
--     lower(p.ADDRESS1) like '%bujumbura%rural%' or lower(p.ADDRESS1) like '%muramvy%' or lower(p.ADDRESS1) like '%mwar%' or
--     lower(p.ADDRESS2) like '%bujumbura%rural%' or lower(p.ADDRESS2) like '%muramvy%' or lower(p.ADDRESS2) like '%mwar%'
--     )
--and md.PAYMENT_TYPE_ID = 11
and p.USER_ID NOT IN
(
select distinct p.USER_ID from ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.USERS p, ecokash.mtx_categories cat
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and md.PARTY_ID = p.USER_ID
and md.TRANSFER_STATUS = 'TS'
and cat.domain_code in ('DISTWS')
--and (
--lower(p.CITY) like '%bujumbura%rural%' or lower(p.CITY) like '%muram%' or lower(p.CITY) like '%mwar%' or
--     lower(p.ADDRESS1) like '%bujumbura%rural%' or lower(p.ADDRESS1) like '%muramvy%' or lower(p.ADDRESS1) like '%mwar%' or
--     lower(p.ADDRESS2) like '%bujumbura%rural%' or lower(p.ADDRESS2) like '%muramvy%' or lower(p.ADDRESS2) like '%mwar%'
--     )
and (md.TRANSFER_DATE >= to_date('01/02/2022','dd/mm/yyyy') and md.TRANSFER_DATE < to_date('14/05/2022','dd/mm/yyyy')+1 )
)
order by 2;