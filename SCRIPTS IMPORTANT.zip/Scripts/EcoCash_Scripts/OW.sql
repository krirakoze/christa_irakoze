SELECT mti.transfer_date, mti.TRANSFER_ID,  (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) amount,mti.post_balance/100 balance, second_party_account_id customer_number,(select m.user_name||'-'||m.last_name from ecokash.mtx_party m where m.user_id = mti.second_party) customer_name,  (select u.agent_code from ecokash.users u where u.user_id = mti.party_id) merchant_code, 
           (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) merchant_number, 
           (select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) channel_name,sst.SERVICE_NAME, mth.REMARKS
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status in('TS')
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     --and mti.transfer_id like 'MP%'
     and sst.Service_Type='OPTW'
     and mti.party_id in (select user_id from ecokash.users where msisdn in('72263001'))
AND mti.transfer_date >= to_date('01/01/2020','dd/mm/yyyy') and mti.transfer_date < to_date('25/02/2020','dd/mm/yyyy')+1
order by mti.transfer_date;
