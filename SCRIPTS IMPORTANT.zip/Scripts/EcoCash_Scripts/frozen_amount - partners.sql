select u.msisdn,u.user_name||' '||u.last_name partner_name,wb.frozen_amount/100 frozen_amount
from ecokash.mtx_wallet_balances wb,ecokash.mtx_wallet w,ecokash.users u
where wb.wallet_number=w.wallet_number and w.msisdn=u.msisdn and wb.frozen_amount/100>0
and u.status='Y' and w.status='Y' and u.msisdn in
(
    select msisdn from ecokash.users where category_code in
    (select category_code from ecokash.mtx_categories where domain_code in('MER','MERCHANT','EMPLOYER'))
    union
    select msisdn from ecokash.users where category_code = 'WHS'
);