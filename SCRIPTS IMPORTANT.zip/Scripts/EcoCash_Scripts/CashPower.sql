SELECT 'Cash Power' description,TRUNC (mti.transfer_date) "DATE", count(distinct mti.TRANSFER_ID) cnt , SUM (DECODE (mti.entry_type,
'DR', mti.requested_value / 100,
-mti.requested_value / 100
)
) amount,
sum(mti2.transfer_value/100) revenue
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, 
ecokash.mtx_transaction_items mti2,ecokash.mtx_transaction_header mth,
ecokash.users u
WHERE mti.transfer_status = 'TS'
and mti.transfer_id=mti2.transfer_id
and mti2.wallet_number='101IND03'
AND mti.service_type = sst.service_type
and mth.transfer_id=mti.transfer_id 
and mti.second_party_category_code = 'WBILLMER'
and mti.category_code = 'SUBS'
and mti.second_party = u.user_id
and u.agent_code = '00555'
and mti.service_type = 'BILLPAY'
and mti.service_type not in ('TXNCORRECT')
AND TRUNC (mti.transfer_date) between to_date('18/04/2019','dd/mm/yyyy') and to_date('18/04/2019','dd/mm/yyyy') 
GROUP BY TRUNC (mti.transfer_date) 
order by TRUNC (mti.transfer_date);