select SERVICE_NAME,to_char(TRANSFER_DATE,'MON-YYYY') PERIOD,count(distinct transfer_id) volume,
sum(AMOUNT_TRANSFERED) value,count(distinct msisdn) unik_subs,sum(revenue) revenue from(
select md.TRANSFER_ID, md.TRANSFER_DATE, p.MSISDN, 
s.SERVICE_NAME, DECODE(md.PAYMENT_TYPE_ID,12,'Principal','Commission') "ACCOUNT",md.ENTRY_TYPE,
md.TRANSFER_VALUE / 100 AMOUNT_TRANSFERED,
s.service_type,s.SERVICE_NAME || ' ' || DECODE(md.SECOND_PARTY_ACCOUNT_ID, 'IND03', 'Commission', md.SECOND_PARTY_ACCOUNT_ID) "DESCRIPTION",md2.transfer_value/100 revenue,
md.SECOND_PARTY_ACCOUNT_ID from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_TRANSACTION_ITEMS md2,
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_ID=md2.TRANSFER_ID
and md2.wallet_number='101IND03'
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID = 12
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and Md.Transaction_Type='MP'
--and md.service_type not in('ROLLBACK','TXNCORRECT')
and md.transfer_date >= to_date('26/10/2021','dd/mm/yyyy') and md.transfer_date < to_date('14/12/2021','dd/mm/yyyy')+1
order by md.TRANSFER_DATE
) group by SERVICE_NAME,to_char(TRANSFER_DATE,'MON-YYYY');