select to_char( to_date('01/12/2019','dd/mm/yyyy') ,'MON-YYYY') "MONTH", p.AGENT_CODE, p.MSISDN, p.USER_NAME||''||p.LAST_NAME "NAME",
p.COUNTRY, p.CITY, p.ADDRESS1, p.ADDRESS2,
cat.CATEGORY_NAME, sa.USER_NAME || ' ' || sa.LAST_NAME "SUPER AGENT NAME", p.DESIGNATION "CONTACT STAFF" 
from ecokash.USERS p, ecokash.mtx_categories cat,
ecokash.USERS sa
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and p.STATUS = 'Y'
and cat.domain_code in ('DISTWS')
and p.PARENT_ID = sa.USER_ID
and sa.USER_ID='PT160907.1552.753082'
and p.USER_ID NOT IN
(
select distinct p.USER_ID from ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.USERS p, ecokash.mtx_categories cat
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and md.PARTY_ID = p.USER_ID
and md.TRANSFER_STATUS = 'TS'
and cat.domain_code in ('DISTWS')
and (md.TRANSFER_DATE >= to_date('01/12/2019','dd/mm/yyyy') and md.TRANSFER_DATE < to_date('16/12/2019','dd/mm/yyyy') +1)
)
order by 2;