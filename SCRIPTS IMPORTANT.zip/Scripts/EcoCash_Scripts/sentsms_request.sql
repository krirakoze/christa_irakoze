select to_char(deliveredon,'dd/mm/yyyy hh24:mi:ss') dateheure,msisdn,message from ecokash.sentsms
where deliveredon >= to_date('27/05/2022','dd/mm/yyyy') and deliveredon < to_date('27/05/2022','dd/mm/yyyy')+1
and msisdn in('76224211') order by Deliveredon desc;