select closing_date,msisdn channel_number,sum(amount) closing_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(
'72413538',
'72413711',
'72413366',
'72413374',
'72413370'
)
and closing_date >= to_date('30/06/2021','dd/mm/yyyy')
and closing_date < to_date('30/06/2021','dd/mm/yyyy')+1
group by closing_date,msisdn;