--Agents 0
select a.msisdn,a.user_name,a.last_name,a.category_code,g.grade_code from ecokash.users a,ecokash.mtx_wallet w,ecokash.channel_grades g
where a.msisdn=w.msisdn and w.user_grade=g.grade_code and a.status != 'N' and w.status != 'N' and w.payment_type_id=12
and a.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and g.grade_code in('Ag0');

