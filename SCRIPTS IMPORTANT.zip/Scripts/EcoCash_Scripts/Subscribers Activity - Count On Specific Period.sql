select count(distinct subscriber) "Active Subs" from
(
select md.transfer_date "date", md.ACCOUNT_ID subscriber
from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
where md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS' 
and md.SECOND_PARTY_ACCOUNT_ID not in (select msisdn from EXCL_AGENT) --excluding channels created by the Business for internal promotions
and trunc(md.TRANSFER_DATE) between to_date('01/03/2019','dd/mm/yyyy') and to_date('12/06/2019','dd/mm/yyyy')
);