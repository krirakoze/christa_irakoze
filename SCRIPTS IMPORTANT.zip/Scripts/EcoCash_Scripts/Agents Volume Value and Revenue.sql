select to_char(Transfer_On,'MON-YYYY') month,count(distinct Mobile_Number) unique_subs,count(distinct Transfer_Id) Volume,sum(Transaction_Value) value,
sum(revenue) revenue from(
SELECT mti.TRANSFER_ID Transfer_Id, mti.transfer_date Transfer_On,sst.service_type Service_Type,sst.service_name Service_Name,
    mti.transaction_type Transaction_Type,mti.entry_type "CR/DR",mti.second_party_account_id Mobile_Number,
                mti.transfer_value / 100 Transaction_Value,mti2.transfer_value/100 revenue,
    mti.post_balance/100 "Post Balance",
    (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) "Transactor"
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_items mti2, ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
AND mti.transfer_id=mti2.transfer_id
AND mti2.wallet_number='101IND03'
AND mti.service_type = sst.service_type
AND mth.transfer_id=mti.transfer_id 
AND mti.transaction_type = 'MP'
and sst.service_type<>'O2C'
AND mti.party_id = (select user_id from ecokash.users where msisdn = '72119178' and status='Y'
AND category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
AND mti.transfer_date >= to_date('01/08/2017','dd/mm/yyyy') AND mti.transfer_date < to_date('31/03/2020','dd/mm/yyyy')+1
ORDER BY mti.transfer_date)
group by to_char(Transfer_On,'MON-YYYY');
