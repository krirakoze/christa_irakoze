SELECT account_id msisdn,sum(DECODE (mti.entry_type,
'DR', -mti.transfer_value / 100,
mti.transfer_value / 100
)
) amount
FROM ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
and mth.transfer_id=mti.transfer_id 
and mti.payment_type_id = 12
and mti.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'SUBS')
AND mti.transfer_date < to_date('28/07/2020','dd/mm/yyyy')+1
group by account_id;