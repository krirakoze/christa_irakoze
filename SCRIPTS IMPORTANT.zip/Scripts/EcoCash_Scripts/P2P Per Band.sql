SELECT to_char(mti.transfer_date,'MON-YYYY') month,
count(distinct mti.TRANSFER_ID) volume,SUM(mti.transfer_value/100) value,SUM(mti2.transfer_value/100) revenue
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_items mti2,
    ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
      AND mti.transfer_id=mti2.transfer_id
and mti.category_code='SUBS'
and mti.transaction_type = 'MR'
AND mti.service_type = 'P2P'
AND mti2.wallet_number='101IND03'
AND mti.transfer_value/100 between 500001 and 1000000
AND mti.transfer_date >= to_date('01/01/2020','dd/mm/yyyy') and mti.transfer_date < to_date('30/06/2020','dd/mm/yyyy') + 1
GROUP BY to_char(mti.transfer_date,'MON-YYYY');