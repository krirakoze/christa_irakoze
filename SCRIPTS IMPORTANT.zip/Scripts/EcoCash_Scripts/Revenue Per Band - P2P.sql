SELECT 'P2P Revenue' description,to_char(mti.transfer_date,'MON-YYYY') "MONTH",count(distinct mti.TRANSFER_ID) volume ,
SUM (DECODE (mti.entry_type,'DR', -mti.transfer_value / 100,mti.transfer_value / 100)) value,SUM (mti2.transfer_value / 100) revenue
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2,
ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS' AND mti.transfer_id=mti2.transfer_id AND mti.service_type = sst.service_type
and mth.transfer_id=mti.transfer_id  and mti2.wallet_number = '101IND03'
--and mti.category_code in('SUBS','RT')
and mti.transaction_type = 'MR'
AND mth.service_type in('P2P')
AND mti.transfer_date >= to_date('01/10/2021','dd/mm/yyyy') and mti.transfer_date < last_day(to_date('01/11/2021','dd/mm/yyyy')) + 1
AND mti.transfer_value / 100 between 500 and 1070
GROUP BY 'P2P Revenue', to_char(mti.transfer_date,'MON-YYYY');