select to_char(trx_date,'dd-mm-yyyy') DX,biller_number,biller_name,count(distinct trx_id) volume,sum(trx_amount) value from(
SELECT mti.transfer_date trx_date,  mti.transfer_id trx_id, 
(select u.agent_code from ecokash.users u where u.user_id = mti.party_id  and u.status = 'Y') biller_code, 
(select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') biller_number, 
 (select u.user_name||' - '||u.last_name from ecokash.users u where u.user_id = mti.party_id) biller_name, (DECODE (mti.entry_type,
                      'DR', -mti.transfer_value/100,
                      mti.transfer_value/100
                     )
             ) trx_amount ,
             mti.second_party_account_id Customer_Number,
             (select mtp.user_name||' - '||mtp.last_name from ecokash.mtx_party mtp where mtp.user_id = mti.second_party) customer_name,sst.service_type,sst.service_name, mth.REMARKS
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('01/12/2019','dd/mm/yyyy') and mti.transfer_date < to_date('31/12/2019','dd/mm/yyyy')+1
     AND mti.transfer_id = mth.transfer_id
     --AND mti.entry_type='CR'
     AND sst.service_type='BILLPAY'
     AND mti.party_id in (select user_id from ecokash.users where category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT')))
group by to_char(trx_date,'dd-mm-yyyy'),biller_number,biller_name order by 1;
