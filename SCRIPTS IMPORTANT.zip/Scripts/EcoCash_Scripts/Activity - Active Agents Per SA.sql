select to_char( to_date(md.transfer_date,'DD/MM/YYYY') ,'MON-YYY') "MONTH", sa.msisdn "SA NUMBER", sa.USER_NAME || ' ' || sa.LAST_NAME "SUPER AGENT NAME"
, count(distinct p.AGENT_CODE) "ACTIVE AGENTS" from ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.USERS p, ecokash.mtx_categories cat,
ecokash.USERS sa
where p.CATEGORY_CODE = cat.CATEGORY_CODE
and md.PARTY_ID = p.USER_ID
and md.TRANSFER_STATUS = 'TS'
and cat.domain_code in ('DISTWS')
and p.PARENT_ID = sa.USER_ID
and p.PARENT_ID IN('PT160307.1517.275120',
'PT160122.1241.437865',
'PT160517.1028.928972',
'PT160503.1505.769320',
'PT160803.1148.576284',
'PT160623.1115.760237',
'PT160607.1026.435517',
'PT160829.1433.320206',
'PT170330.1013.081873',
'PT191002.0903.270399',
'PT150907.1743.198139',
'PT190222.1054.577466')
---and (
--lower(p.CITY) like '%bujumbura%rural%' or lower(p.CITY) like '%muram%' or lower(p.CITY) like '%mwar%' or
--     lower(p.ADDRESS1) like '%bujumbura%rural%' or lower(p.ADDRESS1) like '%muramvy%' or lower(p.ADDRESS1) like '%mwar%' or
--     lower(p.ADDRESS2) like '%bujumbura%rural%' or lower(p.ADDRESS2) like '%muramvy%' or lower(p.ADDRESS2) like '%mwar%'
--     )
and (md.TRANSFER_DATE >= to_date('02/05/2020','dd/mm/yyyy') and md.TRANSFER_DATE < to_date('31/05/2020','dd/mm/yyyy') +1)
--and md.PAYMENT_TYPE_ID = 11
group by to_char( to_date(md.transfer_date,'DD/MM/YYYY') ,'MON-YYY'),sa.msisdn,sa.USER_NAME || ' ' || sa.LAST_NAME;