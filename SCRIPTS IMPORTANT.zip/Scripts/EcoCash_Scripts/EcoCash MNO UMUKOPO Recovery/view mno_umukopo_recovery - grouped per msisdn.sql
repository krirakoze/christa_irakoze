select '18SEP TO 8DEC' "PERIOD",mno_eco.MSISDN,sum(mno_eco.MNO_DED) mno_ded, sum(mno_eco.MNO_CASHIN) mno_cashin, sum(mno_eco.OTHER_CASHIN) other_cashin,
sum(mno_eco.SEND_MONEY) send_money, sum(mno_eco.PAYROLL) payroll, sum(mno_eco.MUKOPO_PAID) mukopo_paid
FROM MNO_UMUKOPO_RECOV mno_eco
left outer join UMUKOPO_91_DEFAULTERS defl
on mno_eco.MSISDN = defl.MSISDN
and mno_eco.TRX_DATE = defl.TRX_DATE + 1
where mno_eco.TRX_DATE >= to_date('18/09/2020','dd/mm/yyyy') and mno_eco.TRX_DATE < to_date('08/12/2020','dd/mm/yyyy')+1
group by '18SEP TO 8DEC',mno_eco.MSISDN;