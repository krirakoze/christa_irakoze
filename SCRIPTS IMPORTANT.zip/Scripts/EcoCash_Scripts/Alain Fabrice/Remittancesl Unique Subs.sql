SELECT count(distinct mobile_number) unik_subs from(
SELECT mti.TRANSFER_ID "Transfer Id", to_char(mti.transfer_on,'YYYY-MM-DD HH24:MI:SS') "Transfer On",
sst.service_name "Service Name",mti.transaction_type "Transaction Type",mti.entry_type "CR/DR",
    (DECODE(mti.second_party_account_id,
                        'IND03',
                        'Fee Income Account',
                        mti.second_party_account_id
                        )
            ) Mobile_Number,
            mti.transfer_value / 100 "Transaction Value",
    mti.post_balance/100 "Post Balance",
    (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) "Transactor"
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
AND mth.transfer_id=mti.transfer_id
AND mti.second_party_category_code='SUBS'
AND mti.party_id in (select a.user_id 
                                 from ecokash.users a, ecokash.mtx_categories cat, ecokash.mtx_wallet w
                                 where cat.domain_code = 'DISTWS'
                                 and a.msisdn = w.msisdn
                                 --and a.status='Y'
                                 and cat.category_code = a.category_code
                                 and w.user_grade in ('REMAGENT0','REMAGENT1','REMAGENT','REMAGENT2')
                                 and w.payment_type_id = 12)
AND category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and mti.transfer_date >= ( to_date('25/05/2021','dd/mm/yyyy') - 30) +1 and mti.transfer_date < to_date('25/05/2021','dd/mm/yyyy')+1
ORDER BY mti.transfer_date,mti.post_balance/100 desc
);