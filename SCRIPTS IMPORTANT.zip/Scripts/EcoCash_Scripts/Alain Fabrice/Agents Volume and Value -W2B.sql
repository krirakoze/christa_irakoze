select tmp.msisdn,
case when b2w.trxs is null then 0 else b2w.trxs end as volume,
case when b2w.val is null then 0 else b2w.val end as value
from temp_nbrs tmp left outer join
(select u.MSISDN,count(distinct md.TRANSFER_ID) trxs,sum(md.TRANSFER_VALUE/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.users u
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID != 0
and u.MSISDN in(select msisdn from temp_nbrs) --and u.STATUS != 'N'
and s.service_type in('CWBREQ','RWBREQ')
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and md.transfer_date < to_date('31/07/2021','dd/mm/yyyy')+1
group by u.MSISDN) b2w
on tmp.msisdn=b2w.msisdn;