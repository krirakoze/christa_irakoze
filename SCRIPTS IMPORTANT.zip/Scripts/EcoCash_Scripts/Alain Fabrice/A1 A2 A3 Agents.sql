SELECT count( distinct mti.account_id) msisdn
          FROM ecokash.mtx_transaction_items mti,
               ecokash.mtx_transaction_header mth,
               ecokash.users c,
               ecokash.mtx_wallet m
         WHERE mti.transfer_status = 'TS'
           AND mth.transfer_status = 'TS'
           AND mti.transfer_id = mth.transfer_id
           AND  mti.party_id = c.user_id
           and c.user_id = m.user_id
           AND substr(mti.account_id,1,1) = '7'
           and length(mti.account_id) = 8
           AND c.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
           and c.category_code<>'WHS'
and (c.msisdn, c.category_code) not in (select msisdn, category_code from mmukila.excl_agent)
           AND mti.transfer_date >= (last_day( to_date('01/03/2021','dd/mm/yyyy')) - 60)+1 AND mti.transfer_date <  last_day(to_date('01/03/2021','dd/mm/yyyy')) + 1;