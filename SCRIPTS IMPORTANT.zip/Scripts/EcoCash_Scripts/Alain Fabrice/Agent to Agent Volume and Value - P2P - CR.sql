select tmp.msisdn,
case when p2p.trxs is null then 0 else p2p.trxs end as volume,
case when p2p.val is null then 0 else p2p.val end as value
from temp_nbrs tmp left outer join
(select u.MSISDN,count(distinct md.TRANSFER_ID) trxs,sum(md.TRANSFER_VALUE/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.users u
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID != 0
and u.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and md.second_party_category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and s.service_type in('P2P')
and md.transaction_type in ('MR')
and md.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and md.transfer_date < to_date('31/07/2021','dd/mm/yyyy')+1
group by u.MSISDN) p2p
on tmp.msisdn=p2p.msisdn;