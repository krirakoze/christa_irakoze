select tmp.msisdn,
case when cashout.vol is null then 0 else cashout.vol end as cashout_volume,
case when cashout.val is null then 0 else cashout.val end as cashout_value,
case when paybill.vol is null then 0 else paybill.vol end as paybill_volume,
case when paybill.val is null then 0 else paybill.val end as paybill_value,
case when paymerch.vol is null then 0 else paymerch.vol end as paymerch_volume,
case when paymerch.val is null then 0 else paymerch.val end as paymerch_value,
case when p2p.vol is null then 0 else p2p.vol end as p2p_volume,
case when p2p.val is null then 0 else p2p.val end as p2p_value,
case when cashin.vol is null then 0 else cashin.vol end as cashin_volume,
case when cashin.val is null then 0 else cashin.val end as cashin_value,
case when recharge.vol is null then 0 else recharge.vol end as buyairtime_volume,
case when recharge.val is null then 0 else recharge.val end as buyairtime_value,
case when w2b.vol is null then 0 else w2b.vol end as w2b_volume,
case when w2b.val is null then 0 else w2b.val end as w2b_value,
case when b2w.vol is null then 0 else b2w.vol end as b2w_volume,
case when b2w.val is null then 0 else b2w.val end as b2w_value
from temp_nbrs tmp left outer join
(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type='CASHOUT'
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) cashout
on tmp.msisdn=cashout.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type='BILLPAY'
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) paybill
on tmp.msisdn=paybill.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('MERCHPAY','SUBMPREQ')
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) paymerch
on tmp.msisdn=paymerch.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('P2P')
and md.transaction_type in ('MR')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) p2p
on tmp.msisdn=p2p.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CASHIN')
and md.transaction_type in ('MR')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) cashin
on tmp.msisdn=cashin.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('RC')
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) recharge
on tmp.msisdn=recharge.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CWBREQ','RWBREQ')
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy') and md.transfer_date < to_date('29/08/2021','dd/mm/yyyy')+1
group by p.MSISDN) w2b
on tmp.msisdn=w2b.msisdn

left outer join

(select p.MSISDN,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CBWREQ','RBWREQ')
and md.transaction_type in ('MR')
and md.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and md.transfer_date < to_date('31/07/2021','dd/mm/yyyy')+1
group by p.MSISDN) b2w
on tmp.msisdn=b2w.msisdn;