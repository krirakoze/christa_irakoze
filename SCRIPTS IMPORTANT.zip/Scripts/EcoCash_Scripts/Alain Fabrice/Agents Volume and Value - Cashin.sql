select tmp.agent_code,tmp.msisdn,
case when cashin.trxs is null then 0 else cashin.trxs end as volume,
case when cashin.val is null then 0 else cashin.val end as value
from temp_nbrs tmp left outer join
(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs,sum(md.TRANSFER_VALUE/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.users p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type='CASHIN'
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('30/07/2021','dd/mm/yyyy') and md.transfer_date < to_date('22/12/2021','dd/mm/yyyy')+1
group by p.MSISDN) cashin
on tmp.msisdn=cashin.msisdn;