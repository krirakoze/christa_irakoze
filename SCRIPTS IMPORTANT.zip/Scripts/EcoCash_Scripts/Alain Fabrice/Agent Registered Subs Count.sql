select trunc(subs.created_on) reg_day,tmp.msisdn "AGENT",count(subs.msisdn) "REGISTERED SUBS"
from (
    select a.msisdn from ecokash.users a,ecokash.mtx_wallet w,ecokash.channel_grades g
    where a.msisdn=w.msisdn and w.user_grade=g.grade_code and a.status != 'N' and w.status != 'N' and w.payment_type_id=12
    and a.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
    and g.grade_code not in('ZRT','BRAM') and a.created_on  < to_date('17/08/2021','dd/mm/yyyy') + 1
) tmp
left outer join
(
    select u.created_on,u.MSISDN,
    (
        select uu.msisdn from ecokash.users uu where uu.user_id=u.created_by and uu.category_code in(
        select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
    ) reg_agent
    from ecokash.MTX_PARTY_ACCESS p,
    ecokash.MTX_PARTY u
    where u.USER_ID = p.USER_ID
    and length(p.MSISDN) <= 8
    and p.STATUS != 'N'
    and u.created_on>=to_date('01/08/2021','dd/mm/yyyy') and u.created_on<to_date('16/08/2021','dd/mm/yyyy')+1
) subs
on tmp.msisdn=subs.reg_agent and subs.msisdn is not null
group by trunc(subs.created_on),tmp.msisdn having count(subs.msisdn)>0 order by trunc(subs.created_on);