select '24/03/2022' trx_date,tmp.msisdn,  
                             case when cashout.revenue is null then 0 else cashout.revenue end as cashout_revenue,  
                             case when paybill.revenue is null then 0 else paybill.revenue end as paybill_revenue,  
                             case when paymerch.revenue is null then 0 else paymerch.revenue end as paymerch_revenue,  
                             case when p2p.revenue is null then 0 else p2p.revenue end as p2p_revenue,  
                             case when cashin.revenue is null then 0 else cashin.revenue end as cashin_revenue,  
                             case when recharge.revenue is null then 0 else recharge.revenue end as buyairtime_revenue,  
                             case when w2b.revenue is null then 0 else w2b.revenue end as w2b_revenue,  
                             case when b2w.revenue is null then 0 else b2w.revenue end as b2w_revenue  
                             from (  
                                '72222986',
								'72222135'
                             ) tmp left outer join  
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md  
                             ,ecokash.MTX_TRANSACTION_ITEMS md2,ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type='CASHOUT'  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) cashout  
                             on tmp.msisdn=cashout.msisdn and cashout.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md  
                             ,ecokash.MTX_TRANSACTION_ITEMS md2,ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type='BILLPAY'  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) paybill  
                             on tmp.msisdn=paybill.msisdn and paybill.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,ecokash.MTX_TRANSACTION_ITEMS md2,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('MERCHPAY','SUBMPREQ')  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) paymerch  
                             on tmp.msisdn=paymerch.msisdn and paymerch.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,ecokash.MTX_TRANSACTION_ITEMS md2,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('P2P')  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) p2p  
                             on tmp.msisdn=p2p.msisdn and p2p.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,ecokash.MTX_TRANSACTION_ITEMS md2,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('CASHIN')  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) cashin  
                             on tmp.msisdn=cashin.msisdn and cashin.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,(sum(md.transfer_value/100)*4)/100 revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('RC')  
                             and md.transaction_type in ('MR','MP')  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) recharge  
                             on tmp.msisdn=recharge.msisdn and recharge.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,ecokash.MTX_TRANSACTION_ITEMS md2,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('CWBREQ','RWBREQ')  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) w2b  
                             on tmp.msisdn=w2b.msisdn and w2b.trx_date>=tmp.trx_date  
                               
                             left outer join  
                               
                             (select trunc(md.transfer_date) trx_date,p.MSISDN,sum(md2.transfer_value/100) revenue  
                             from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md,ecokash.MTX_TRANSACTION_ITEMS md2,  
                             ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p  
                             where mh.TRANSFER_ID = md.TRANSFER_ID  
                             and md.transfer_id=md2.transfer_id  
                             and md.TRANSFER_STATUS = 'TS'  
                             and md.SERVICE_TYPE = s.SERVICE_TYPE  
                             and md.PARTY_ID = p.USER_ID  
                             and md.PAYMENT_TYPE_ID != 0  
                             and p.MSISDN in(
								'72222986',
								'72222135'
							 )  
                             and s.service_type in('CBWREQ','RBWREQ')  
                             and md.transaction_type in ('MR','MP')  
                             and md2.wallet_number='101IND03'  
                             and md.transfer_date >= to_date('24/03/2022','dd/mm/yyyy') and md.transfer_date < to_date('24/03/2022','dd/mm/yyyy') + 1  
                             group by trunc(md.transfer_date),p.MSISDN) b2w  
                             on tmp.msisdn=b2w.msisdn and b2w.trx_date>= tmp.trx_date