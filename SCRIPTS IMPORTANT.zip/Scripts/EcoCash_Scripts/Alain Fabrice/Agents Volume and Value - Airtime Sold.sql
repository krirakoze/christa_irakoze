select tmp.msisdn,
case when recharge.trxs is null then 0 else recharge.trxs end as volume,
case when recharge.val is null then 0 else recharge.val end as value
from temp_nbrs tmp left outer join
(SELECT mti.second_party_account_id msisdn,
count(distinct mti.transfer_id) trxs , SUM (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) val
  FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
 WHERE mti.transfer_status = 'TS'
   AND mth.transfer_status = 'TS'
   AND mti.transfer_id LIKE 'RC%'
   AND mti.service_type = sst.service_type
   AND mti.wallet_number = '100000000000001'
   AND MTI.SECOND_PARTY_CATEGORY_CODE IN(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
   and mti.transfer_id = mth.transfer_id
    AND mti.transfer_date >= to_date('01/07/2021','dd/mm/yyyy') and mti.transfer_date < to_date('31/07/2021','dd/mm/yyyy') + 1
    GROUP BY mti.second_party_account_id) recharge
   on tmp.msisdn=recharge.msisdn;