select tmp.msisdn,
case when cashout.trxs is null then 0 else cashout.trxs end as cashout,
case when paybill.trxs is null then 0 else paybill.trxs end as paybill,
case when paymerch.trxs is null then 0 else paymerch.trxs end as paymerch,
case when p2p.trxs is null then 0 else p2p.trxs end as p2p,
case when cashin.trxs is null then 0 else cashin.trxs end as cashin,
case when recharge.trxs is null then 0 else recharge.trxs end as buyairtime,
case when w2b.trxs is null then 0 else w2b.trxs end as w2b,
case when b2w.trxs is null then 0 else b2w.trxs end as b2w
from temp_nbrs tmp left outer join
(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type='CASHOUT'
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) cashout
on tmp.msisdn=cashout.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type='BILLPAY'
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) paybill
on tmp.msisdn=paybill.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('MERCHPAY','SUBMPREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) paymerch
on tmp.msisdn=paymerch.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('P2P')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) p2p
on tmp.msisdn=p2p.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('CASHIN')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) cashin
on tmp.msisdn=cashin.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('RC')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) recharge
on tmp.msisdn=recharge.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('CWBREQ','RWBREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) w2b
on tmp.msisdn=w2b.msisdn

left outer join

(select p.MSISDN,count(distinct md.TRANSFER_ID) trxs
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) and p.STATUS != 'N'
and s.service_type in('CBWREQ','RBWREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('18/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('28/06/2021','dd/mm/yyyy')+1
group by p.MSISDN) b2w
on tmp.msisdn=b2w.msisdn;