select last_borrowed_date,msisdn,principal_amount,interest_amount,outstanding_balance from umukopo_91_defaulters
where extract_date>=to_date('18/06/2021','DD/MM/YYYY') and  extract_date<to_date('18/06/2021','DD/MM/YYYY')+1
--and last_borrowed_date >= to_date('01/05/2020','DD/MM/YYYY')
--and last_borrowed_date < to_date('31/05/2020','DD/MM/YYYY')+1
--and days_overdue >= 656
and outstanding_balance>0
order by last_borrowed_date;