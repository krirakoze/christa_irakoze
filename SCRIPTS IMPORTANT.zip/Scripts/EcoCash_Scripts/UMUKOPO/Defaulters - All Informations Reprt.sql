select count(msisdn) "Volume",sum(total_borrowed) "Value",sum(interest_amount) "Interest Revenue",
sum(capital_repayments) "Capital Repayments",sum(interest_repayments) "Interest Repayments",sum(total_repayments) "Total Repayments" from(
select msisdn,principal_amount+interest_amount total_borrowed,principal_amount,interest_amount,outstanding_balance,
case when principal_amount+interest_amount-outstanding_balance > interest_amount
then principal_amount-outstanding_balance else 0 end capital_repayments,
case when principal_amount+interest_amount-outstanding_balance <= interest_amount
then principal_amount+interest_amount-outstanding_balance else interest_amount end interest_repayments,
principal_amount+interest_amount-outstanding_balance total_repayments
from umukopo_91_defaulters
where extract_date>=to_date('05/03/2021','DD/MM/YYYY')
and last_borrowed_date>=to_date('01/05/2020','DD/MM/YYYY')
and last_borrowed_date<to_date('31/05/2020','DD/MM/YYYY')+1
and outstanding_balance>0
);