With day AS
	(SELECT
  ( to_date('01/10/2020','dd/mm/yyyy') + level - 1) AS end_day
FROM
  dual
CONNECT BY LEVEL <= ( to_date('31/10/2020','dd/mm/yyyy') - to_date('01/10/2020','dd/mm/yyyy') + 1)
    ) 
select day.end_day trx_date, txr.cnt_rep_subs, txr.amt_rep_princ, txi.amt_rep_inter from day
left outer join
(
select trunc(mtr.transfer_date) trx_date, coalesce(count(distinct mtr.SECOND_PARTY_ACCOUNT_ID),0) cnt_rep_subs,
coalesce(sum(mtr.transfer_value/100),0) amt_rep_princ from ecokash.mtx_transaction_items mtr
where mtr.party_id = (select user_id from ecokash.users where msisdn = '76006659'and category_code = 'MER')
and mtr.SERVICE_TYPE IN ('SUBMPREQ')
group by trunc(mtr.transfer_date)
) txr on day.end_day = txr.trx_date
left outer join
(
select trunc(mtr.transfer_date) trx_date, coalesce(sum(mtr.transfer_value/100),0) amt_rep_inter from ecokash.mtx_transaction_items mtr
where mtr.party_id = (select user_id from ecokash.users where msisdn = '76501791' and category_code = 'MER')
and mtr.SERVICE_TYPE IN ('SUBMPREQ')
group by trunc(mtr.transfer_date)
) txi on day.end_day = txi.trx_date
order by 1;