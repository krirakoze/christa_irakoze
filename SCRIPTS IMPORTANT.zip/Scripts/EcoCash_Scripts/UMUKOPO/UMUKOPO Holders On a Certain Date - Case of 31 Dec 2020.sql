SELECT NOW() extract_date, current_day, sub.msisdn,
(outstanding_balance_as_on) outstanding_balance_as_on,
datediff(current_day,repayment_date) days_overdue,
(
select max(date_created) from
(
select subscriber_id, date_created, ecocash_reference, 
request_amount amount, status from credit_request c
where c.date_created>='2019-03-22' and c.date_created<'2022-03-01'
union all
select subscriber_id, date_created, ecocash_reference, 
request_amount amount, status from credit_request_archive c
where c.date_created>='2019-03-22' and c.date_created<'2022-03-01'
) tt where tt.subscriber_id = ttout.subscriber_id
) last_borrowed_on, 
requested_credit_as_on, 
requested_interest_as_on from
(select toutst.current_day, toutst.repayment_date,
toutst.subscriber_id, toutst.request_amount requested_credit_as_on, toutst.interest requested_interest_as_on,
(toutst.request_amount + toutst.interest) - (sum(toutst.principal_paid) + sum(toutst.interest_paid)) outstanding_balance_as_on
from(
select tt.* ,
if(recharge_type = 'INTEREST', recharged_amount,0) interest_paid,
if(recharge_type = 'PRINCIPAL', recharged_amount,0) principal_paid,
datediff(current_day,repayment_date) days_overdue
from(
select tresult.current_day, tresult.credit_id, tresult.subscriber_id, tresult.request_date, tresult.repayment_date,
tresult.request_amount, tresult.interest, recharge_type, sum(ifnull(rc.amount,0)) recharged_amount
from
(
select tdates.current_day, tcredit.credit_id, tcredit.subscriber_id, tcredit.request_date, tcredit.repayment_date, tcredit.request_amount, tcredit.interest
from 
(select adddate('1970-01-01',t4*10000 + t3*1000 + t2*100 + t1*10 + t0) current_day from
 (select 0 t0 union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0,
 (select 0 t1 union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1,
 (select 0 t2 union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2,
 (select 0 t3 union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3,
 (select 0 t4 union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4)
 tdates
 left outer join
(
select credit_id, subscriber_id, request_date, repayment_date, request_amount, interest  from (
select id credit_id, subscriber_id, convert(date_created,date) request_date, convert(repayment_date,date) repayment_date, request_amount request_amount, interest interest from credit_request
where status <> 'REJECTED'
union all
select id credit_id, subscriber_id, convert(date_created,date) request_date, convert(repayment_date,date) repayment_date, 
request_amount request_amount, interest interest from credit_request_archive
where status <> 'REJECTED'
)tt
) tcredit on convert(tcredit.request_date,date) >= '2019-03-22'

and (datediff(current_day,repayment_date) >= -14 )

where  convert(tdates.current_day,date) = '2022-02-28'
)tresult left outer join
(
select tca.credit_request_id credit_id, tca.recharge_date, tca.recharge_type, tca.amount from recharge_log_archive tca 
union all
select tca.credit_request_id credit_id, tca.recharge_date, tca.recharge_type, tca.amount from recharge_log tca
) rc on tresult.credit_id = rc.credit_id
and convert(rc.recharge_date,date) <= tresult.current_day
group by tresult.current_day,tresult.current_day, tresult.credit_id,
tresult.subscriber_id, tresult.request_date, tresult.repayment_date,
tresult.request_amount, tresult.interest, recharge_type
) tt 
group by tt.current_day, tt.credit_id, tt.request_date, tt.repayment_date,
tt.request_amount, tt.interest, recharge_type
)toutst 
group by toutst.current_day, toutst.repayment_date,
toutst.subscriber_id, toutst.request_amount, toutst.interest
) ttout left outer join subscriber sub
on ttout.subscriber_id = sub.id
where outstanding_balance_as_on > 0
/*and sub.msisdn='71021943'*/
group by current_day, sub.msisdn order by last_borrowed_on desc