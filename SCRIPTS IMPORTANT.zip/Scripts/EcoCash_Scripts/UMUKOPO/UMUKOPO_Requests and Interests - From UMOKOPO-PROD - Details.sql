select convert(cra.date_created,date) request_date,s.msisdn,cra.id, cra.request_amount, cra.interest expected_interest,cra.subscriber_id
from credit_request_archive cra,subscriber s
where cra.subscriber_id=s.id and convert(cra.date_created, date) between '2022-02-01' and '2022-02-28' and cra.ecocash_reference is not null
and cra.status <> 'REJECTED'
union all
select convert(cr.date_created,date) request_date,s.msisdn,cr.id,cr.request_amount,cr.interest expected_interest,cr.subscriber_id
from credit_request cr,subscriber s
where cr.subscriber_id=s.id and convert(cr.date_created, date) between '2022-02-01' and '2022-02-28' and cr.ecocash_reference is not null
and cr.status <> 'REJECTED';