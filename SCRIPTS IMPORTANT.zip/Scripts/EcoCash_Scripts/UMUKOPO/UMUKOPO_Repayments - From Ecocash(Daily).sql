select rep_princ.trx_date,rep_princ.cnt_rep_subs,rep_princ.amt_rep_princ,rep_int.amt_rep_inter from
(
select trunc(mtr.transfer_date) trx_date, coalesce(count(distinct mtr.SECOND_PARTY_ACCOUNT_ID),0) cnt_rep_subs,
coalesce(sum(mtr.transfer_value/100),0) amt_rep_princ from ecokash.mtx_transaction_items mtr
where mtr.party_id = (select user_id from ecokash.users where msisdn = '76006659' and category_code = 'MER')
and mtr.SERVICE_TYPE IN ('SUBMPREQ') and mtr.transfer_date >= to_date('17/05/2021','dd/mm/yyyy')
and  mtr.transfer_date < to_date('17/05/2021','dd/mm/yyyy')+1
group by trunc(mtr.transfer_date)
) rep_princ,
(select trunc(mtr.transfer_date) trx_date, coalesce(sum(mtr.transfer_value/100),0) amt_rep_inter from ecokash.mtx_transaction_items mtr
where mtr.party_id = (select user_id from ecokash.users where msisdn = '76501791' and category_code = 'MER')
and mtr.SERVICE_TYPE IN ('SUBMPREQ') and mtr.transfer_date >= to_date('17/05/2021','dd/mm/yyyy')
and  mtr.transfer_date < to_date('17/05/2021','dd/mm/yyyy')+1
group by trunc(mtr.transfer_date)
) rep_int where rep_princ.trx_date=rep_int.trx_date;