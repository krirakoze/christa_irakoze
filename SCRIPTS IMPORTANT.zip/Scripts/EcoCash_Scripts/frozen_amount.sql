select mti.transfer_id,mti.TRANSFER_VALUE/100 frozen_amount,bnk.BANK_NAME bank,mti.TRANSFER_STATUS,mti.TRANSFER_DATE
from ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_header mth,
ecokash.mtx_wallet_balances wb,ecokash.mtx_wallet w,ecokash.mbk_bank_details bnk,ecokash.users u
where mth.TRANSFER_ID=mti.TRANSFER_ID
and mth.BANK_ID=bnk.BANK_ID
and mti.WALLET_NUMBER=w.WALLET_NUMBER
and wb.WALLET_NUMBER=w.WALLET_NUMBER
and w.MSISDN=u.MSISDN
and u.MSISDN='76284427'
and mti.PAYMENT_TYPE_ID = 12;

--select frozen_amount/100 frozen_amount from ecokash.mtx_wallet_balances where wallet_number='101121002668237';
--select * from ecokash.mtx_wallet where msisdn='79563036' and PAYMENT_TYPE_ID=12 and status='Y';