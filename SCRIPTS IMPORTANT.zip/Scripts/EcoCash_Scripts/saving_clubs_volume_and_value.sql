select trunc(mti.transfer_date) transf_date,sum(decode(mti.entry_type,'CR',1,'DR',-1,0)) cnt,
sum(decode(mti.entry_type,'CR',mti.transfer_value,-mti.transfer_value)/100) amount
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s 
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 13
and mti.service_type = s.service_type
--and mti.category_code = 'SUBS'
and mti.transfer_status = 'TS'
AND (
     mth.SERVICE_TYPE IN  ('DEPOCLUB')
     AND mti.TRANSACTION_TYPE = 'MR'
     OR (
     mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
     and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
     where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN  ('DEPOCLUB')
     AND mti.TRANSACTION_TYPE = 'MP')
     )) 
    AND mti.transfer_date >= to_date('18/11/2019','dd/mm/yyyy') and mti.transfer_date < to_date('22/11/2019','dd/mm/yyyy') + 1
group by trunc(mti.transfer_date)
order by 1;