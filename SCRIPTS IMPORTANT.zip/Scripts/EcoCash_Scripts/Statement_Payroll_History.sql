SELECT mti.transfer_date, mti.TRANSFER_ID, mti.ENTRY_TYPE, (DECODE (mti.entry_type,
                    'DR', -mti.transfer_value / 100,
                    mti.transfer_value / 100
                   )
           ) amount,
 mti.POST_BALANCE/100 post_balance, second_party_account_id customer_number,(select m.user_name||'-'||m.last_name from ecokash.mtx_party m where m.user_id = mti.second_party) customer_name,  (select u.agent_code from ecokash.users u where u.user_id = mti.party_id) payroll_code, 
           (select u.msisdn from ecokash.users u where u.user_id = mti.party_id) payroll_number, 
           (select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) payroll_name,sst.SERVICE_NAME, mth.REMARKS
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     --and mti.transfer_id like 'MP%'
     and mti.party_id = (select user_id from ecokash.users where msisdn = '76751346'
     and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'EMPLOYER'))
AND mti.transfer_date >= to_date('27/06/2019','dd/mm/yyyy') and mti.transfer_date < to_date('27/06/2019','dd/mm/yyyy') + 1 
 order by mti.transfer_date;
