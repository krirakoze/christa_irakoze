select sum(cnt) volume, sum(amount) value ,count(distinct second_party) unique_subs from (
SELECT   mti.account_id account_id, mti.party_id party_id, mti.second_party,(select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) channel_name, COUNT (DISTINCT mti.transfer_id) cnt,
         SUM (DECODE (mti.entry_type,
                      'DR', mti.transfer_value / 100,
                      -mti.transfer_value / 100
                     )
             ) amount
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mth.transfer_status = 'TS'
     AND mti.transfer_id = mth.transfer_id
     AND mth.service_type in ('CASHIN')
     AND mti.transaction_type = 'MP'
     AND mti.category_code in (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
     --AND mti.party_id in (select user_id  from ecokash.users u where u.parent_id = 'PT150311.1334.040444')
     AND mti.transfer_date >= to_date('01/02/2020','dd/mm/yyyy') and mti.transfer_date < to_date('29/02/2020','dd/mm/yyyy')+1
GROUP BY mti.account_id, mti.party_id,mti.second_party
union
select account_id, party_id, second_party,channel_name, sum(cnt) cnt, sum(amount) amount from (
     SELECT mti.account_id account_id, mti.party_id party_id, mti.second_party,(select u.user_name||' - '||last_name from ecokash.users u where u.user_id = mti.party_id) channel_name, (select th.service_type from ecokash.mtx_transaction_header th where th.transfer_id = mth.attr_2_value) service_type, -COUNT (DISTINCT mti.transfer_id) cnt, SUM (DECODE (mti.entry_type,
                      'DR', mti.transfer_value/100,
                      -mti.transfer_value/100
                     )
             ) amount 
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.service_type = 'TXNCORRECT'
     AND mti.transfer_id = mth.transfer_id
    AND mti.transaction_type = 'MR'
    --AND mti.party_id in (select user_id from ecokash.users u where u.parent_id = 'PT150311.1334.040444')
     AND mti.transfer_date >= to_date('01/02/2020','dd/mm/yyyy') and mti.transfer_date < to_date('29/02/2020','dd/mm/yyyy')+1
     GROUP BY mti.account_id, mti.party_id, mth.attr_2_value,mti.second_party
     )
     where service_type = 'CASHIN'
     group by account_id, party_id, channel_name,second_party
     );