SELECT sst.service_name description,TRUNC (mti.transfer_date), COUNT (DISTINCT mti.transfer_id) cnt, SUM (DECODE (mti.entry_type,
                      'DR', mti.transfer_value/100,
                      -mti.transfer_value/100
                     )
             ) amount 
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
    AND mti.transfer_date >= to_date('01/09/2019','dd/mm/yyyy') and mti.transfer_date < to_date('30/09/2019','dd/mm/yyyy') + 1
    AND mti.transfer_id like 'CI%'
     AND mti.transaction_type = 'MP'
     and ABS(mti.transfer_value/100) between 30391 and 30390
     AND mti.account_id not in (select a.msisdn 
                                 from ecokash.users a, ecokash.mtx_categories cat, ecokash.mtx_wallet w
                                 where cat.domain_code = 'DISTWS'
                                 and a.msisdn = w.msisdn
                                 and cat.category_code = a.category_code
                                 and w.user_grade  in ('REMAGENT','REMAGENT0','REMAGENT1','REMAGENT2','Airt2money')
                                 and w.payment_type_id = 12)
GROUP BY sst.service_name , TRUNC (mti.transfer_date)  
 order by TRUNC (mti.transfer_date);