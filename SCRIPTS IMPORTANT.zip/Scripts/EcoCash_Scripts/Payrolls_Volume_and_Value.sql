select Transactor_Name Payroll_Name,Transactor Payroll_Number,count(distinct TransferId) volume,sum(TransactionValue) value from(
SELECT mti.TRANSFER_ID TransferId, mti.transfer_date TransferOn,sst.service_type ServiceType,sst.service_name ServiceName,
    mti.transaction_type TransactionType,mti.entry_type CR_DR,
    (DECODE(mti.second_party_account_id,
                        'IND01',
                        'Mirror Trust Account',
                        'IND03',
                        'Fee Income Account',
                        mti.second_party_account_id
                        )
            ) MobileNumber
,mti.transfer_value/100 TransactionValue ,mti.post_balance/100 "Post Balance" ,
             (select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') Transactor,
             (select u.user_name||' '||u.last_name from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') Transactor_Name
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND Sst.Service_Type='PAYROLL'
     AND mti.transfer_date >= to_date('01/03/2019','dd/mm/yyyy') AND mti.transfer_date < to_date('01/01/2020','dd/mm/yyyy')
     AND mti.transfer_id = mth.transfer_id
     AND mti.party_id in (select user_id from ecokash.users where msisdn in(
        '72286730',
        '72286722',
        '72286731',
        '72286736',
        '72286729',
        '76104118',
        '76285370',
        '71018071',
        '76481348',
        '72418571',
        '72286724',
        '76481355'
     )
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'EMPLOYER'))
order by 1) group by Transactor_Name,Transactor;
