select to_char(f_d,'MM/YYYY') mon,count(ACCOUNT_ID) agents from(
select u.MSISDN ACCOUNT_ID, F.FIRST_DATE f_d, u.USER_NAME || ' ' || u.LAST_NAME "NAME",
cat.CATEGORY_NAME, u.DESIGNATION "RELATIONSHIP OFFICE", u.CITY, u.ADDRESS1, u.ADDRESS2,
u.CREATED_ON, md.TRANSFER_ID, s.SERVICE_NAME,  md.TRANSFER_VALUE/100 "AMOUNT" from
(
select min(d.TRANSFER_DATE) "FIRST_DATE", d.PARTY_ID, d.ACCOUNT_ID from ecokash.MTX_TRANSACTION_ITEMS d
 where d.TRANSFER_STATUS = 'TS'
  and d.CATEGORY_CODE in (select c.CATEGORY_CODE from ecokash.MTX_CATEGORIES c where c.DOMAIN_CODE = 'DISTWS')
 and not exists (select h.TRANSFER_ID from ecokash.MTX_TRANSACTION_HEADER h where h.SERVICE_TYPE = 'ROLLBACK' and h.ATTR_3_VALUE = d.TRANSFER_ID
 and h.TRANSFER_STATUS = 'TS')
 group by d.PARTY_ID, d.ACCOUNT_ID
 ) F, ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_CATEGORIES cat, 
 ecokash.SYS_SERVICE_TYPES s, ecokash.users u
 where md.ACCOUNT_ID = F.ACCOUNT_ID
 and F.FIRST_DATE = md.TRANSFER_DATE
 and md.CATEGORY_CODE = cat.CATEGORY_CODE
 and md.CATEGORY_CODE in (select c.CATEGORY_CODE from ecokash.MTX_CATEGORIES c where c.DOMAIN_CODE = 'DISTWS')
 and md.SERVICE_TYPE = s.SERVICE_TYPE
 and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID = 12
 and F.FIRST_DATE >= to_date('01/03/2019','dd/mm/yyyy') and F.FIRST_DATE < to_date('31/07/2019','dd/mm/yyyy') + 1
 order by 2
 ) group by to_char(f_d,'MM/YYYY');