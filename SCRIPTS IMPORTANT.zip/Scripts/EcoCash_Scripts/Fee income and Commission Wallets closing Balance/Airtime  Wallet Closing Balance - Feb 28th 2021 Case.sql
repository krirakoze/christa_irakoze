select 'Ecocash airtime receivable' "DESCRIPTION",'28/02/2021' "DAY",transfer_id,post_balance/100 balance,wallet_number
from ECOKASH.mtx_transaction_items where transfer_date>=to_date('01/03/2021','dd/mm/yyyy')
and transfer_date<to_date('01/03/2021','dd/mm/yyyy') + 1 and transfer_id like'WS%'
and wallet_number='100000000000001' and entry_type='CR' order by txn_sequence_number;