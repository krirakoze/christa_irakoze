select p.MSISDN,p.USER_NAME|| ' ' || p.last_name SUBS_NAME,wb.balance/100 BALANCE,to_char(wb.last_transfer_on,'dd-mm-yyyy hh:mm:ss') last_trx_date,
(case when exists(select b.account_number from ecokash.MTX_PARTY_BLACK_LIST b where b.account_number=p.msisdn) then 'barred' else 'unbarred' end) "STATUS"
from ecokash.mtx_party p,ecokash.MTX_WALLET w,ecokash.MTX_WALLET_BALANCES wb
where p.USER_ID = w.USER_ID
and w.WALLET_NUMBER=wb.WALLET_NUMBER
and p.status='Y'
and p.user_id IN (select user_id from ecokash.mtx_party p where p.msisdn
in (select msisdn from gsingaya.numbers));