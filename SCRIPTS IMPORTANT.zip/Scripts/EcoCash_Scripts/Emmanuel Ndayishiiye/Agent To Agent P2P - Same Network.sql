select to_char(md.transfer_date,'MON-YY') trx_month,u.agent_code,count(distinct md.TRANSFER_ID) trxs,
count(distinct md.second_party_account_id) unik_agents,sum(md.TRANSFER_VALUE/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.users u
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID != 0
and u.agent_code in(
'70914'
) --and p.STATUS != 'N'
and md.second_party_account_id in(select msisdn from ecokash.users where category_code in
(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS' )
and parent_id = (select parent_id from ecokash.users where agent_code='70914'))
and s.service_type in('P2P')
and md.transaction_type in ('MP')
and md.transfer_date >= to_date('01/06/2021','dd/mm/yyyy') and md.transfer_date < to_date('31/08/2021','dd/mm/yyyy')+1
group by u.agent_code,to_char(md.transfer_date,'MON-YY') order by 1;