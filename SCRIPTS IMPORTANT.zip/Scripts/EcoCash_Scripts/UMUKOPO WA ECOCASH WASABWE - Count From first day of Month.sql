--Loans Borrowed details per Band
select last_day(trx_date) ,count(distinct customer) customers, ranges,num from(
select trunc(mti.transfer_date) trx_date, mti.second_party_account_id customer, '300-10,000' ranges,'1' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date(to_char(trunc(add_months(last_day(sysdate)+1,-1)),'dd/mm/yyyy'),'dd/mm/yyyy') and to_date('24/04/2019','dd/mm/yyyy')
and mti.transfer_value/100 between 300 and 10000

union

select trunc(mti.transfer_date) trx_date,mti.second_party_account_id customer, '10,001-20,000' ranges,'2' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date(to_char(trunc(add_months(last_day(sysdate)+1,-1)),'dd/mm/yyyy'),'dd/mm/yyyy') and to_date('24/04/2019','dd/mm/yyyy')
and mti.transfer_value/100 between 10001 and 20000

union

select trunc(mti.transfer_date) trx_date,mti.second_party_account_id customer, '20,000-30,000' ranges,'3' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date(to_char(trunc(add_months(last_day(sysdate)+1,-1)),'dd/mm/yyyy'),'dd/mm/yyyy') and to_date('24/04/2019','dd/mm/yyyy')
and mti.transfer_value/100 >= 20001
)
group by last_day(trx_date), ranges,num
order by last_day(trx_date), num;