select count(subs_msisdn) cnt
from SUBS_FIRST_TRX_DETAIL det
WHERE det.service_type = 'CASHIN'
and det.second_party_category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and det.subs_msisdn not in (select msisdn from request_info)
and first_trx_date>=to_date('01/09/2020','dd/mm/yyyy') and first_trx_date<to_date('27/09/2020','dd/mm/yyyy')+1;