select service_name "SERVICE",count(distinct msisdn) unik_subs from(
select md.TRANSFER_ID, md.TRANSFER_DATE, p.MSISDN,
s.SERVICE_NAME, DECODE(md.PAYMENT_TYPE_ID,12,'Principal','Commission') "ACCOUNT",
DECODE(md.ENTRY_TYPE,'DR', - md.TRANSFER_VALUE / 100, 
md.TRANSFER_VALUE / 100) "AMOUNT TRANSFERED",
s.SERVICE_NAME || ' ' || DECODE(md.SECOND_PARTY_ACCOUNT_ID, 'IND03', 'Commission', SECOND_PARTY_ACCOUNT_ID) "DESCRIPTION",
md.SECOND_PARTY_ACCOUNT_ID from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and md.service_type in ('CASHIN')
--and p.MSISDN = '79402501' and p.STATUS != 'N'
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and p.msisdn not in
(
    select distinct md.ACCOUNT_ID account_ids
    from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
    where md.PARTY_ID = p.USER_ID
    and length(md.ACCOUNT_ID) <= 8
    and md.TRANSFER_STATUS = 'TS'
    AND ( 
    (md.second_party_account_id,md.second_party_category_code) not in (select msisdn,category_code from mmukila.excl_agent)
    )
    AND md.transfer_date >= to_date('01/06/2020','dd/mm/yyyy') and md.transfer_date < to_date('31/08/2020','dd/mm/yyyy') + 1
)
and p.created_on<to_date('01/06/2020','dd/mm/yyyy')
and md.transfer_date >= to_date('01/09/2020','dd/mm/yyyy') and md.transfer_date < to_date('17/09/2020','dd/mm/yyyy')+1
order by md.TRANSFER_DATE
)
group by service_name;