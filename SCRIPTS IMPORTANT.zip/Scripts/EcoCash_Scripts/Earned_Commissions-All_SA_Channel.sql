select trunc(last_day(Res.TRANSFER_DATE)) "DATE", Res.AGENT_CODE, Res.ACCOUNT_ID, Res.AGENT_NAME, Res.GRADE_NAME, SUM(Res.Agent_Commission) "AG COM", SUM(Res.SA_Commission) "SA COM"
from(
select u.AGENT_CODE, d.TRANSFER_DATE, d.TRANSFER_ID, d.PARTY_ID, d.ACCOUNT_ID, u.USER_NAME || ' ' || u.LAST_NAME "AGENT_NAME",
g.GRADE_NAME, s.SERVICE_NAME, d.ENTRY_TYPE, 
DECODE(d.ENTRY_TYPE,'CR', d.TRANSFER_VALUE/100,
- d.TRANSFER_VALUE/100) as Agent_Commission, 0 as SA_Commission
from ecokash.MTX_TRANSACTION_ITEMS d, ecokash.MTX_TRANSACTION_HEADER h,ecokash.users u, 
ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g, ecokash.SYS_SERVICE_TYPES s
where d.TRANSFER_ID = h.TRANSFER_ID
and u.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.USER_GRADE = g.GRADE_CODE
and u.user_id IN (select user_id from ecokash.users u where u.parent_id='PT160503.1505.769320')
and d.PARTY_ID = u.USER_ID
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE = s.SERVICE_TYPE
and d.SERVICE_TYPE not in ('RCOMRIMB','OPTSTKDIS')
and d.TRANSFER_DATE >= to_date('01/07/2021','dd/mm/yyyy') and d.TRANSFER_DATE < to_date('16/07/2021','dd/mm/yyyy')+1
UNION
select u.AGENT_CODE, d.TRANSFER_DATE, d.TRANSFER_ID, d.PARTY_ID, d.ACCOUNT_ID, u.USER_NAME || ' ' || u.LAST_NAME "AGENT_NAME",
g.GRADE_NAME, s.SERVICE_NAME, d.ENTRY_TYPE, 0 as Agent_Commission,
coalesce((select coalesce(DECODE(md.ENTRY_TYPE,'CR',
md.TRANSFER_VALUE/100,
-md.TRANSFER_VALUE/100),0) from ecokash.MTX_TRANSACTION_ITEMS md
where md.PARTY_ID = u.PARENT_ID
and u.USER_ID != u.PARENT_ID
and md.TRANSFER_ID = d.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.PAYMENT_TYPE_ID = 11),0) as SA_Commission
from ecokash.MTX_TRANSACTION_ITEMS d, ecokash.MTX_TRANSACTION_HEADER h,ecokash.users u, 
ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g, ecokash.SYS_SERVICE_TYPES s
where d.TRANSFER_ID = h.TRANSFER_ID
and u.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.USER_GRADE = g.GRADE_CODE
and d.party_id IN (select user_id from ecokash.users u where u.parent_id='PT160503.1505.769320')
and d.PARTY_ID = u.USER_ID
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 12
and d.SERVICE_TYPE = s.SERVICE_TYPE
and d.SERVICE_TYPE not in  ('RCOMRIMB','OPTSTKDIS')
and d.TRANSFER_DATE >= to_date('01/07/2021','dd/mm/yyyy') and d.TRANSFER_DATE < to_date('16/07/2021','dd/mm/yyyy')+1
UNION
select u.AGENT_CODE, d.TRANSFER_DATE, d.TRANSFER_ID, u.USER_ID "PARTY_ID", u.MSISDN "ACCOUNT_ID", u.USER_NAME || ' ' || u.LAST_NAME "AGENT_NAME",
g.GRADE_NAME, s.SERVICE_NAME, d.ENTRY_TYPE, 
DECODE(d.ENTRY_TYPE,'CR', d.TRANSFER_VALUE/100,
- d.TRANSFER_VALUE/100) as Agent_Commission, 0 as SA_Commission
from ecokash.MTX_TRANSACTION_ITEMS d, ecokash.MTX_TRANSACTION_HEADER h,ecokash.users u, 
ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g, ecokash.SYS_SERVICE_TYPES s,
ecokash.MTX_PARTY p
where d.TRANSFER_ID = h.TRANSFER_ID
and u.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.USER_GRADE = g.GRADE_CODE
and p.CREATED_BY = u.USER_ID
and d.PARTY_ID = u.USER_ID
--and u.PARENT_ID = u.USER_ID
and h.ATTR_3_VALUE = p.MSISDN
and u.user_id IN (select user_id from ecokash.users u where u.parent_id='PT160503.1505.769320')
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE = s.SERVICE_TYPE
and d.SERVICE_TYPE in ('COMTR')
and d.TRANSFER_DATE >= to_date('01/07/2021','dd/mm/yyyy') and d.TRANSFER_DATE < to_date('16/07/2021','dd/mm/yyyy')+1
) Res --where Res.Agent_Commission <> 0 or Res.SA_Commission <> 0
group by Res.AGENT_CODE, Res.ACCOUNT_ID, Res.AGENT_NAME, Res.GRADE_NAME, trunc(last_day(Res.TRANSFER_DATE))
order by 1, 2;