SELECT to_char(mti.transfer_date,'MON-YYYY') month,
COUNT (DISTINCT mti.transfer_id) volume,SUM(mti.transfer_value/100) value,SUM(mti2.transfer_value/100) revenue
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_items mti2
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_id=mti2.transfer_id
    AND mti.transfer_date >= to_date('01/01/2020','dd/mm/yyyy') and mti.transfer_date < to_date('30/06/2020','dd/mm/yyyy') + 1
    AND sst.service_type='CASHIN'
     AND mti.transaction_type = 'MP'
     AND mti2.wallet_number='101IND03'
     AND mti.account_id not in (select a.msisdn 
                                 from ecokash.users a, ecokash.mtx_categories cat, ecokash.mtx_wallet w
                                 where cat.domain_code = 'DISTWS'
                                 and a.msisdn = w.msisdn
                                 and cat.category_code = a.category_code
                                 and w.user_grade  in ('REMAGENT','REMAGENT0','REMAGENT1','REMAGENT2','Airt2money')
                                 and w.payment_type_id = 12)
 AND mti.transfer_value/100 between 500001 and 1000000
GROUP BY to_char(mti.transfer_date,'MON-YYYY');