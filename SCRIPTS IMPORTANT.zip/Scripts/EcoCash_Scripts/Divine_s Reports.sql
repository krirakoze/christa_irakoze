select count(*),sum(commissions) from(
select u.msisdn,coalesce(SUM(DECODE(d.ENTRY_TYPE,'CR', 
d.TRANSFER_VALUE/100, 
- d.TRANSFER_VALUE/100)),0) commissions
from ecokash.MTX_TRANSACTION_ITEMS d,ecokash.users u,ecokash.USERS sa
where d.PARTY_ID = u.USER_ID
and u.PARENT_ID = sa.USER_ID
and sa.STATUS != 'N'
and u.STATUS != 'N' 
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE not in  ('RCOMRIMB','OPTSTKDIS')
and d.Category_Code in(select category_code from ecokash.mtx_categories where domain_code='DISTWS')
--and u.Msisdn=a.Agent_Msisdn
and d.TRANSFER_DATE >= to_date('01/07/2019','dd/mm/yyyy') and d.TRANSFER_DATE < (LAST_DAY( to_date('01/08/2019','dd/mm/yyyy') )+1)
group by u.msisdn order by 1);

/*select a.Agent_Msisdn,sum(a.volume) volume,sum(a.value) value,(select b.commissions from AUG_2019 b where a.Agent_Msisdn=b.msisdn) commissions
from MMUKILA.Agent_Daily_Activity a
where a.Txn_Date>=to_date('01/08/2019','dd/mm/yyyy') and a.Txn_Date<to_date('31/08/2019','dd/mm/yyyy')+1
group by a.Agent_Msisdn;*/