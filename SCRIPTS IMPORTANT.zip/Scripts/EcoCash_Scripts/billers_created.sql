select u.user_id,u.created_on,u.msisdn,u.user_name ||' '|| u.last_name biller_name from ecokash.users u, ecokash.mtx_wallet w
where u.msisdn=w.msisdn and W.Payment_Type_Id=12
and w.Created_On >=to_date('01/09/2018','dd/mm/yyyy') and w.Created_On <to_date('27/08/2019','dd/mm/yyyy')
and u.status='Y' and u.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT');