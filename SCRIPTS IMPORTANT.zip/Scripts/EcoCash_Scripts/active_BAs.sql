select distinct u.msisdn,
--to_char(mti.transfer_date,'MON-YYYY') MONTH,
u.agent_code,u.user_name||' '||u.last_name agent_name,u.address1,u.address2,u.city province
from ecokash.mtx_transaction_items mti,ecokash.users u,ecokash.mtx_wallet mw,ecokash.channel_grades cg
where mti.party_id=u.user_id
and u.msisdn=mw.msisdn
and mw.user_grade = cg.grade_code
and mti.transfer_status = 'TS'
and mti.payment_type_id = 12
and mw.payment_type_id = 12
--and u.status='Y'
and u.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and cg.GRADE_CODE in ('ZRT','BRAM') 
AND (mti.account_id,mti.category_code) not in (select msisdn,category_code from mmukila.excl_agent)
and mti.TRANSFER_DATE >=( to_date('21/09/2020','dd/mm/yyyy') - 90)+1 and mti.TRANSFER_DATE < to_date('21/09/2020','dd/mm/yyyy')+1;