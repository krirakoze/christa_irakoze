SELECT mti.TRANSFER_ID "Transfer Id", to_char(mti.transfer_on,'YYYY-MM-DD HH24:MI:SS') "Transfer On",sst.service_name "Service Name",
    mti.transaction_type "Transaction Type",mti.entry_type "CR/DR",
    (DECODE(mti.second_party_account_id,
                        'IND01',
                        'Mirror Trust Account',
                        'IND03',
                        'Fee Income Account',
                        mti.second_party_account_id
                        )
            ) "Mobile Number"
,mti.transfer_value/100 "Transaction Value" ,mti.post_balance/100 "Post Balance" ,
             (select u.msisdn from ecokash.users u where u.user_id = mti.party_id and u.status = 'Y') "Transactor"
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
   --AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('24/06/2022','dd/mm/yyyy')  and  mti.transfer_date < to_date('24/06/2022','dd/mm/yyyy')+1 
     AND mti.transfer_id = mth.transfer_id
     AND mti.party_id in (select user_id from ecokash.users where msisdn ='76994327'
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'EMPLOYER'))
ORDER BY mti.transfer_date,mti.post_balance/100 desc;
