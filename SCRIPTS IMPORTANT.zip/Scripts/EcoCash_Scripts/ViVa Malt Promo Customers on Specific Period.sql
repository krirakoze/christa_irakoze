SELECT distinct second_party_account_id msisdn
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     --and mti.transfer_id like 'MP%'
     and mti.party_id = (select user_id from ecokash.users where msisdn = '72129874'
     and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER'))
AND mti.transfer_date >= to_date('04/09/2020','dd/mm/yyyy') and mti.transfer_date < to_date('10/09/2020','dd/mm/yyyy')+1;
