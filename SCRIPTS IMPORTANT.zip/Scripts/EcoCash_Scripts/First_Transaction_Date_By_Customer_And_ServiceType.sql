select distinct p.MSISDN,p.created_on,min(md.transfer_date) first_trx_date,s.service_name from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and s.service_type in('BILLPAY','MERCHPAY')
--and p.MSISDN = '76108109' and p.STATUS != 'N'
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and p.created_on >= to_date('01/11/2019','dd/mm/yyyy') and p.created_on < to_date('30/11/2019','dd/mm/yyyy')+1
and md.transfer_date=(select min(transfer_date) from ecokash.mtx_transaction_items where account_id=md.account_id)
group by p.MSISDN,p.created_on,s.service_name;