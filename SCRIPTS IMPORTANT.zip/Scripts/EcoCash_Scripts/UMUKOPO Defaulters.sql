--from mmukila
select trunc(extract_date) current_date,msisdn,outstanding_balance outstanding_balance_as_on,
days_overdue,last_borrowed_date last_borrowed_on
from umukopo_91_defaulters
where extract_date>=to_date('11/01/2021','DD/MM/YYYY')
and extract_date<to_date('11/01/2021','DD/MM/YYYY')+1