select count(distinct trx_id) volume,sum(trx_amount) amount,count(distinct customer_number) subscribers from(
SELECT mti.transfer_date trx_date,mti.transfer_id trx_id,
(DECODE (mti.entry_type,'DR', -mti.transfer_value/100, mti.transfer_value/100)) trx_amount,mti.second_party_account_id customer_number
   FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
   WHERE mti.transfer_status = 'TS'
     AND mth.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     AND mti.transfer_date >= to_date('01/05/2021','dd/mm/yyyy') AND mti.transfer_date < to_date('10/05/2021','dd/mm/yyyy')+1 
     AND mti.transfer_id = mth.transfer_id
     AND mti.second_party<>'IND03'
     AND sst.service_type not IN ('ROLLBACK','TXNCORRECT')
     and not exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d
     where d.TRANSFER_ID = mth.reconciliation_by and d.SERVICE_TYPE IN  ('ROLLBACK','TXNCORRECT'))
     AND mti.party_id in (select user_id from ecokash.users where msisdn in ('72263001')
    and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT'))
order by 1);