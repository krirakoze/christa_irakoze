/*update contents of the 2 tables first*/
select msisdn from MNO_NOT_IN_ECOCASH_SUBS/*contains mno subs that are not in ecocash subs*/ where msisdn not in
(
    select msisdn from NOT_IN_ECOCASH_SUBS_IN_USERS/*contains MNO_NOT_IN_ECOCASH_SUBS that are in users*/
);