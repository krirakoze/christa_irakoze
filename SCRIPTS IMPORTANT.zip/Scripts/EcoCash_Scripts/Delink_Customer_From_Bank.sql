update ecokash.MBK_CUST_ACCOUNTS 
set status_id = 'N'
where (user_id, bank_id) in 
(select cb.user_id, bk.BANK_ID
from ecokash.MBK_CUST_ACCOUNTS cb, ecokash.MBK_BANK_DETAILS bk, ecokash.MTX_PARTY p
where cb.BANK_ID = bk.BANK_ID
and cb.USER_ID = p.USER_ID
and cb.STATUS_ID = 'Y'
and p.STATUS = 'Y'
and bk.BANK_ID = 'IND0410193' -- This is KCB Bank
and p.msisdn = '76222551'
);
commit;