--select msisdn from ecokash.users where login_id='oneacrefund';
--select * from ECOKASH.MBK_BANK_DETAILS;

select count(msisdn) from ecokash.users where created_on >= to_date('01/12/2019','dd/mm/yyyy')
and created_on < to_date('31/12/2019','dd/mm/yyyy')+1 and status<>'N'
 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS');