SELECT to_char(mti.transfer_date,'MON-YYYY') Month, count(distinct mti.party_id) unique_subs, count(distinct mti.TRANSFER_ID) volume,SUM (DECODE (mti.entry_type,
                    'DR', mti.transfer_value / 100,
                    -mti.transfer_value / 100
                   )
           ) value,sum(mti2.transfer_value/100) revenue
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,ecokash.mtx_transaction_items mti2,
    ecokash.mtx_transaction_header mth,
    ecokash.users u
   WHERE
   mti.transfer_id=mti2.transfer_id
   and mti2.wallet_number='101IND03'
   and  mti.transfer_status = 'TS'
     AND mti.service_type = sst.service_type
     and mth.transfer_id=mti.transfer_id 
     and mti.second_party_category_code = 'WBILLMER'
     and mti.category_code = 'SUBS'
     and mti.second_party = u.user_id
     and u.agent_code = '00555'
    and mti.service_type = 'BILLPAY'
    and mti.service_type not in ('TXNCORRECT')
    AND mti.transfer_date >= to_date('01/09/2019','dd/mm/yyyy') and mti.transfer_date < to_date('11/05/2020','dd/mm/yyyy') + 1
GROUP BY  to_char(mti.transfer_date,'MON-YYYY') 
 order by to_char(mti.transfer_date,'MON-YYYY');