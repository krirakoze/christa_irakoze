select MONTH,agent_msisdn, AGENT_CODE, agent_name, agent_last_name,
CITY, STATE agent_state, ADDRESS1 agent_address1, ADDRESS2 agent_address2, contact_no, sup_agent_name, 
count_customer activated_customers,first_incentive, second_incentive, first_incentive + second_incentive Total
from
(
select to_char(first_cashin_date,'MON-YYYY') "MONTH",agent_msisdn, u.AGENT_CODE, u.user_name agent_name,
u.last_name agent_last_name, u.CITY, u.STATE, u.ADDRESS1, u.ADDRESS2,
count(customer_msisdn) count_customer, u.contact_no,
(select sup.user_name || ' ' || sup.last_name from ecokash.users sup where u.PARENT_ID = sup.user_id) sup_agent_name,
sum(case when second_trx_date is not null and second_trx_date >= to_date('01/05/2022','dd/mm/yyyy') and second_trx_date < to_date('31/05/2022','dd/mm/yyyy')+1 then 0
else 0 end) first_incentive,
sum(case when fourth_trx_date is not null and fourth_trx_date >= to_date('01/05/2022','dd/mm/yyyy') and fourth_trx_date < to_date('31/05/2022','dd/mm/yyyy')+90 then 100
else 0 end) second_incentive
from gsingaya.AGENTS_INCENTIVES,
ecokash.USERS u, 
ecokash.mtx_wallet mw, 
ecokash.channel_grades cg 
where AGENT_MSISDN = u.MSISDN
and u.USER_ID = mw.USER_ID
and mw.PAYMENT_TYPE_ID = 11
and mw.status = 'Y'
and mw.user_grade = cg.grade_code
and cg.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and cg.GRADE_CODE not in ('ZRT','BRAM')
and customer_msisdn not in(select distinct customer_msisdn from gsingaya.AGENTS_INCENTIVES where first_cashin_date < to_date('01/05/2022','dd/mm/yyyy'))
--and agent_msisdn in('76148270')
--and third_trx_date is not null
and first_cashin_date >= to_date('01/05/2022','dd/mm/yyyy') and first_cashin_date < to_date('31/05/2022','dd/mm/yyyy')+1
group by to_char(first_cashin_date,'MON-YYYY'), AGENT_MSISDN, u.agent_code, u.user_name, u.last_name, u.parent_id,u.CITY, u.STATE, u.ADDRESS1, u.ADDRESS2,u.contact_no
) Res where (Res.first_incentive != 0 or Res.second_incentive != 0)
order by 2 asc;