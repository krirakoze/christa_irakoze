select to_char(first_cashin_date,'MON-YYYY') "MONTH",agent_msisdn,customer_msisdn,
case when second_trx_date is not null and second_trx_date >= to_date('01/07/2021','dd/mm/yyyy') and second_trx_date < to_date('31/07/2021','dd/mm/yyyy')+1
then 'Y' else 'N' end first_incentive,
case when fourth_trx_date is not null and fourth_trx_date >= to_date('01/07/2021','dd/mm/yyyy') and fourth_trx_date < to_date('31/07/2021','dd/mm/yyyy')+90
then 'Y' else 'N' end second_incentive
from gsingaya.AGENTS_INCENTIVES,
ecokash.USERS u,
ecokash.mtx_wallet mw,
ecokash.channel_grades cg
where AGENT_MSISDN = u.MSISDN
and u.USER_ID = mw.USER_ID
and mw.PAYMENT_TYPE_ID = 11
and mw.status = 'Y'
and mw.user_grade = cg.grade_code
and cg.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and cg.GRADE_CODE not in ('ZRT','BRAM')
and customer_msisdn not in(select distinct customer_msisdn from gsingaya.AGENTS_INCENTIVES where first_cashin_date < to_date('01/07/2021','dd/mm/yyyy'))
--and third_trx_date is not null
--and agent_msisdn in('76148270')
and first_cashin_date >= to_date('01/07/2021','dd/mm/yyyy') and first_cashin_date < to_date('31/07/2021','dd/mm/yyyy')+1;