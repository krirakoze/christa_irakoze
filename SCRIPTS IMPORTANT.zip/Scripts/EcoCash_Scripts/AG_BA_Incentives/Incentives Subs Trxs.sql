create table BA_INCETIVES_SUBS_TRX_SEP20 as
select msisdn,count(distinct transfer_id) trxs from(
select md.TRANSFER_ID, md.TRANSFER_DATE, p.MSISDN, 
s.SERVICE_NAME, DECODE(md.PAYMENT_TYPE_ID,12,'Principal','Commission') "ACCOUNT",
DECODE(md.ENTRY_TYPE,'DR', - md.TRANSFER_VALUE / 100, 
md.TRANSFER_VALUE / 100) "AMOUNT TRANSFERED",
s.SERVICE_NAME || ' ' || DECODE(md.SECOND_PARTY_ACCOUNT_ID, 'IND03', 'Commission', SECOND_PARTY_ACCOUNT_ID) "DESCRIPTION",
md.SECOND_PARTY_ACCOUNT_ID from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(
select customer_msisdn from AGENTS_INCENTIVES where first_cashin_date >= to_date('01/10/2020','dd/mm/yyyy')
and first_cashin_date < to_date('31/10/2020','dd/mm/yyyy')+1
) and p.STATUS != 'N'
and s.SERVICE_TYPE not in ('CASHIN','BALENQ','SMSTXNHIS','TXNCORRECT','ROLLBACK','CMINIREQ','TAXDDXN','RCOMRIMB','REQOPTPW','STKTR2OCA','CBWREQ','CBALREQ')
AND md.second_party_account_id not in ('IND03','COMMISSION')
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and md.transfer_date >= to_date('01/09/2020','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2020','dd/mm/yyyy')+1
order by md.TRANSFER_DATE
) group by msisdn
;
