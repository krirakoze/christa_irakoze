select b.account_number,h.user_barred_on Barred_On,case when b.reason ='PIN_INVL' then 'Invalid PIN/Password Attempt' else b.reason end Bar_Reason
from ecokash.MTX_PARTY_BLACK_LIST b,ecokash.MTX_PARTY_BARRED_HIST h
where b.account_number=h.msisdn
and b.account_number in
(
select a.msisdn from ecokash.users a, ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where a.status != 'N'
and  a.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.status != 'N'
and w.USER_GRADE = g.GRADE_CODE
and parent_id='PT160503.1505.769320'
and a.created_on < to_date('02/07/2021','dd/mm/yyyy') + 1
AND a.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
and a.AGENT_CODE is not null
)
and h.unbarred_on is null and h.unbarred_by is null and h.unbarring_type is null
and h.user_barred_on=(select max(ht.user_barred_on) from ecokash.MTX_PARTY_BARRED_HIST ht where ht.msisdn=b.account_number)
order by b.created_on
;