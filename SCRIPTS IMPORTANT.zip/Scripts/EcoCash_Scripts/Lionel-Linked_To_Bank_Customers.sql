select trunc(CREATED_ON) LINKED_ON,count(MSISDN) CUSTOMERS,BANK_NAME
from(
    select cb.CREATED_ON CREATED_ON, p.MSISDN MSISDN, (p.USER_NAME || ' ' || p.LAST_NAME) "CUST NAME",bk.BANK_ID, bk.BANK_NAME BANK_NAME
    from ecokash.MBK_CUST_ACCOUNTS cb, ecokash.MBK_BANK_DETAILS bk, ecokash.MTX_PARTY p
    where cb.BANK_ID = bk.BANK_ID
    and cb.USER_ID = p.USER_ID
    and cb.STATUS_ID = 'Y'
    and p.STATUS = 'Y'
    --and bk.BANK_ID = 'IND0410193' -- this is KCB Bank
    and cb.CREATED_ON >= to_date('01/12/2019','dd/mm/yyyy') and cb.CREATED_ON < to_date('31/12/2019','dd/mm/yyyy') + 1
) group by trunc(CREATED_ON),BANK_NAME 
order by 1;
