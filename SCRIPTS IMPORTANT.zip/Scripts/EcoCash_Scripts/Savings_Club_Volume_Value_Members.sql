select /*to_char(Res.transf_date,'MON-YYYY') Mois,*/Res.club_name,count(distinct Res.transfer_id) VOLUME,sum(Res.amount) VALUE ,
/*count(distinct Res.second_party) unique_subs,Res.club_id,*/
(select count(svcm_tmp.member_id) from ecokash.svc_members svcm_tmp where svcm_tmp.svc_id=Res.club_id
    and svcm_tmp.created_on<to_date('31/12/2019','dd/mm/yyyy')+1 and svcm_tmp.status<>'N') club_members
from
(
select trunc(mti.transfer_date) transf_date, mti.transfer_id,mti.party_id, mti.second_party, s.SERVICE_NAME,
mti.transfer_value/100 amount,c.club_name,c.club_id
	from ecokash.mtx_transaction_items mti,
	ecokash.mtx_transaction_header mth,
	ecokash.SYS_SERVICE_TYPES s,
    ecokash.SVC_SAVING_CLUB c
	where mti.transfer_id = mth.transfer_id
	and mti.payment_type_id = 13
    and mti.party_id=c.ADMIN_ID
	and mti.service_type = s.service_type
	and mti.transfer_status = 'TS'
	and mti.TRANSACTION_TYPE = 'MR'
	AND (
	mth.SERVICE_TYPE IN ('DEPOCLUB')
	AND mti.TRANSACTION_TYPE = 'MR'
	OR (
	mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
	and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
	where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('DEPOCLUB')
	AND mti.TRANSACTION_TYPE = 'MP')
	)) 
    and mti.transfer_date >= to_date('01/12/2019','dd/mm/yyyy')  and mti.transfer_date < to_date('31/12/2019','dd/mm/yyyy')+1
   
    UNION
    
    select trunc(mti.transfer_date) transf_date, mti.transfer_id,mti.party_id, mti.second_party, s.SERVICE_NAME,
    mti.transfer_value/100 amount,c.club_name,c.club_id
    from ecokash.mtx_transaction_items mti,
    ecokash.mtx_transaction_header mth,
    ecokash.SYS_SERVICE_TYPES s,
    ecokash.SVC_SAVING_CLUB c
    where mti.transfer_id = mth.transfer_id
    and mti.payment_type_id = 13
    and mti.party_id=c.ADMIN_ID
    and mti.service_type = s.service_type
    and mti.transfer_status = 'TS'
    
    AND (
    mth.SERVICE_TYPE IN ('WITHCLUB')
    AND mti.TRANSACTION_TYPE = 'MP'
    OR (
    mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
    and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
    where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN ('WITHCLUB')
    AND mti.TRANSACTION_TYPE = 'MR')
    )) 
    and mti.transfer_date >= to_date('01/12/2019','dd/mm/yyyy')  and mti.transfer_date < to_date('31/12/2019','dd/mm/yyyy')+1
)Res,ecokash.mtx_party subs
Where Res.second_party = subs.user_id group by to_char(Res.transf_date,'MON-YYYY'),Res.club_name,Res.club_id;