create table daily_agents_commissions as
select to_date(d.TRANSFER_DATE,'dd/mm/yyyy') "DATE",
coalesce(SUM(DECODE(d.ENTRY_TYPE,'CR', 
d.TRANSFER_VALUE/100, 
- d.TRANSFER_VALUE/100)),0) "COMMISSIONS"
from ecokash.MTX_TRANSACTION_ITEMS d,ecokash.users u,ecokash.USERS sa
where d.PARTY_ID = u.USER_ID
and u.PARENT_ID = sa.USER_ID
and sa.STATUS != 'N'
and u.STATUS != 'N' 
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE not in  ('RCOMRIMB')
and d.TRANSFER_DATE >= to_date('01/01/2019','dd/mm/yyyy') and d.TRANSFER_DATE < to_date('08/12/2020','dd/mm/yyyy')+1
group by to_date(d.TRANSFER_DATE,'dd/mm/yyyy')
order by to_date(d.TRANSFER_DATE,'dd/mm/yyyy');