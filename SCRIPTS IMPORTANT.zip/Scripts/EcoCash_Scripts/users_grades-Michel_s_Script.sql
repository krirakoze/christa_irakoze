select p.msisdn, p.user_name || ' ' || p.last_name "user name",
w.user_grade from ecokash.mtx_wallet w
inner join ecokash.mtx_party p
on w.user_id = p.user_id
and w.payment_type_id = 12
where p.msisdn in
(
'71006165',
'71122244',
'71241961',
'71287690',
'71376207'
) and p.status <> 'N';
