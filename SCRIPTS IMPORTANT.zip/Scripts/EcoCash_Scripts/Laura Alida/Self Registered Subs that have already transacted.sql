select distinct p.msisdn msisdn
from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
where md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS'
and md.service_type not in('PAYROLL','MTREQ')
--and md.transfer_value/100 <> 200
and md.transaction_type='MP'
and exists(select sr.msisdn from temp_nbrs sr where sr.msisdn=p.msisdn)
and md.transfer_date >= to_date('13/12/2021','dd/mm/yyyy')
and md.transfer_date < to_date('15/04/2022','dd/mm/yyyy') + 1;