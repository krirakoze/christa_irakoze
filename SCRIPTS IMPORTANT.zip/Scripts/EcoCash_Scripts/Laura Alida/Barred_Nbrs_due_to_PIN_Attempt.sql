select b.account_number msisdn,h.user_barred_on Barred_On,
case when b.reason ='PIN_INVL' then 'Invalid PIN/Password Attempt' else b.reason end Reason
from ecokash.MTX_PARTY_BLACK_LIST b,ecokash.MTX_PARTY_BARRED_HIST h,ecokash.mtx_party p
where b.account_number=h.msisdn and b.account_number=p.msisdn
and b.account_number in
(
select msisdn from temp_nbrs
)
and h.unbarred_on is null and h.unbarred_by is null and h.unbarring_type is null
and h.user_barred_on=(select max(ht.user_barred_on) from ecokash.MTX_PARTY_BARRED_HIST ht where ht.msisdn=b.account_number)
and b.reason='PIN_INVL' and p.status!='N' and trunc(h.user_barred_on)>trunc(p.created_on)
order by b.created_on
;