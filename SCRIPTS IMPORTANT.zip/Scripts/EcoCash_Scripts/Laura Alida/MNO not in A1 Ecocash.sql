select a.msisdn from temp_nbrs a where not exists
(
    select distinct md.ACCOUNT_ID account_ids
    from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
    where md.PARTY_ID = p.USER_ID
    and length(md.ACCOUNT_ID) <= 8
    and md.TRANSFER_STATUS = 'TS'
    and a.msisdn=md.account_id
    AND md.transfer_date >= (to_date('28/02/2022','dd/mm/yyyy') - 30) + 1
    and md.transfer_date < last_day(to_date('28/02/2022','dd/mm/yyyy')) + 1
);