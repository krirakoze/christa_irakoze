select p.MSISDN
from ecokash.MTX_PARTY_ACCESS p,
ecokash.MTX_PARTY u
where u.USER_ID = p.USER_ID
and length(p.MSISDN) <= 8
and p.STATUS != 'N'
and u.STATUS != 'N'
and u.msisdn in(select msisdn from temp_nbrs)
and p.pin_modified_on is not null;