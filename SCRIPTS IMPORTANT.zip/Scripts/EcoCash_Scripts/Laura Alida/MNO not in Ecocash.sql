select a.msisdn from temp_nbrs a where not exists
(
    select u.MSISDN from ecokash.MTX_PARTY_ACCESS p,
        ecokash.MTX_PARTY u
        where u.USER_ID = p.USER_ID
        and length(p.MSISDN) <= 8
        and p.STATUS != 'N'
        and u.STATUS != 'N'
        and u.msisdn=a.msisdn
);