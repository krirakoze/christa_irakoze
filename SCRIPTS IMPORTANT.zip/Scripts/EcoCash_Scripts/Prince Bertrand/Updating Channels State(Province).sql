select user_name,last_name,msisdn,address1,address2,city,state from gs_users where category_code
IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
and state not in(
'BUBANZA',
'BUJUMBURAMAIRIE',
'BUJUMBURARURAL',
'BURURI',
'CANKUZO','CIBITOKE','GITEGA','KARUSI','KAYANZA','KIRUNDO','MAKAMBA','MURAMVYA','MUYINGA','MWARO','NGOZI','RUMONGE','RUTANA','RUYIGI'
);

select user_name,last_name,msisdn,address1,address2,city,state from gs_users where category_code
IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
and CITY='MUTAMBU' AND STATE in('BUJUMBURA');

update gs_users set state='BUJUMBURAMAIRIE' where msisdn in('79356336',
'71912835',
'71943722',
'79122931') and state is null;
--commit;

--select  state from gs_users;