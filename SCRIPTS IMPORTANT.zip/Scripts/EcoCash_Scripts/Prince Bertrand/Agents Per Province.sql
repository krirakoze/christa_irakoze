select a.state,count(a.msisdn)
from gs_users a,ecokash.mtx_wallet mw, 
ecokash.channel_grades cg 
where a.USER_ID = mw.USER_ID
and mw.user_grade = cg.grade_code
and cg.GRADE_CODE not in ('ZRT','BRAM')
and a.status != 'N'
and mw.PAYMENT_TYPE_ID = 12
and mw.status !='N'
and a.created_on  < last_day(to_date('01/08/2020','dd/mm/yyyy')) + 1 
AND a.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS')
and a.category_code<>'WHS' and state not in('Kampala','KIGOMA')
group by a.state order by state;