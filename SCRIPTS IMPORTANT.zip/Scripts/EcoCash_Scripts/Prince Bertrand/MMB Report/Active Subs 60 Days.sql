select count(distinct md.ACCOUNT_ID) account_ids
from ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_PARTY p
where md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS'
AND ( 
(md.second_party_account_id,md.second_party_category_code) not in (select msisdn,category_code from mmukila.excl_agent)
)
AND md.transfer_date >= ( last_day(to_date('01/10/2021','dd/mm/yyyy')) - 60) + 1 and md.transfer_date < last_day(to_date('01/10/2021','dd/mm/yyyy')) + 1;