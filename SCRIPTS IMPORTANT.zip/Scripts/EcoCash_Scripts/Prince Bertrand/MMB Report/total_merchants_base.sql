select count(distinct msisdn) merchants_closing_base from(
select a.CREATED_ON, a.AGENT_CODE, a.msisdn, a.user_name || ' ' || a.last_name "CHANNEL NAME",g.GRADE_NAME,a.DESIGNATION,
(select u.user_name || ' ' || u.last_name from ecokash.USERS u where u.user_id = a.PARENT_ID and u.STATUS != 'N') "PARENT NAME", 
a.CITY,a.CONTACT_NO,a.ADDRESS1, a.ADDRESS2 
from ecokash.users a, ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where a.status != 'N'
and  a.USER_ID = w.USER_ID
and w.PAYMENT_TYPE_ID = 12
and w.status != 'N'
and w.USER_GRADE = g.GRADE_CODE
and a.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code in ('MER')) 
and a.created_on < to_date('31/10/2021','dd/mm/yyyy') + 1
and a.AGENT_CODE is not null
order by a.AGENT_CODE);