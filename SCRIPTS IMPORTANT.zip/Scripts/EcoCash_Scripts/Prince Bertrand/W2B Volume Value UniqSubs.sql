select description,trx_date,count(distinct transfer_id) cnt,SUM(amount) amount,count(distinct party_id) uniq_subs FROM(
    SELECT 'Wallet To Bank Transfer' description,TRUNC(mti.transfer_date) trx_date,mti.transfer_id ,mti.party_id,
    DECODE(mti.entry_type,'DR', -nvl(mti.transfer_value,0) / 100,nvl(mti.transfer_value,0) / 100) amount
    FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
    WHERE mti.transfer_status = 'TS' AND mth.transfer_status = 'TS' AND mti.service_type in ('CWBREQ','RWBREQ')
    and mti.transaction_type = 'MR' AND mth.service_type = sst.service_type and mti.transfer_id = mth.transfer_id
    and mti.category_code = 'SUBS' AND mti.transfer_date >= to_date('01/10/2021','dd/mm/yyyy')
    and mti.transfer_date < to_date('31/10/2021','dd/mm/yyyy') + 1
    UNION ALL
    SELECT 'Wallet To Bank Transfer' description,TRUNC(mti.transfer_date) trx_date,mti.transfer_id,mti.second_party party_id,
    nvl(mti.transfer_value,0) / 100 amount FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti,
    ecokash.mtx_transaction_header mth  WHERE mti.transfer_status = 'TS' AND mth.transfer_status = 'TS'
    AND mti.service_type = sst.service_type AND mti.transfer_date >= to_date('01/10/2021','dd/mm/yyyy')
    AND mti.transfer_date < to_date('31/10/2021','dd/mm/yyyy')+1 AND mti.transfer_id = mth.transfer_id
    AND mti.second_party<>'IND03' AND sst.service_type not IN ('ROLLBACK','TXNCORRECT')
    and not exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d
    where d.TRANSFER_ID = mth.reconciliation_by and d.SERVICE_TYPE IN  ('ROLLBACK','TXNCORRECT'))
    AND mti.party_id in (select user_id from ecokash.users where msisdn in ('79100312')
    AND category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MERCHANT'))
) GROUP BY description,trx_date;