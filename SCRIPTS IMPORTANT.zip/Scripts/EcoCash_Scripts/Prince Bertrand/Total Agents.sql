select count(p.msisdn)
from ecokash.users p,
           ecokash.user_phones u,
           ecokash.mtx_categories cat
           WHERE p.user_type = 'CHANNEL'
             AND cat.domain_code = 'DISTWS'
             AND p.status != 'N'
             AND p.category_code = cat.category_code
             AND p.user_id = u.user_id
             and cat.category_code != 'WHS'
and p.created_on < to_date('30/06/2021','dd/mm/yyyy') + 1;