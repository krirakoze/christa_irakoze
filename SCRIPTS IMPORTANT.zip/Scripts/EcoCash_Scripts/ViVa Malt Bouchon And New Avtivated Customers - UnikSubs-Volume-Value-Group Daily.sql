select trunc(F.FIRST_DATE) FIRST_DATE, count(distinct u.MSISDN) "UNIQUE_SUBS",count(md.TRANSFER_ID) "VOLUME",sum(md.TRANSFER_VALUE/100) "VALUE" from
(
select min(d.TRANSFER_DATE) "FIRST_DATE", d.PARTY_ID, d.ACCOUNT_ID from ecokash.MTX_TRANSACTION_ITEMS d
where d.TRANSFER_STATUS = 'TS'
and d.CATEGORY_CODE = 'SUBS'
and not exists (select h.TRANSFER_ID from ecokash.MTX_TRANSACTION_HEADER h where h.SERVICE_TYPE = 'ROLLBACK' and h.ATTR_3_VALUE = d.TRANSFER_ID
and h.TRANSFER_STATUS = 'TS')
group by d.PARTY_ID, d.ACCOUNT_ID 
) F, ecokash.MTX_TRANSACTION_ITEMS md, ecokash.MTX_CATEGORIES cat, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY u,
ecokash.mtx_transaction_header mh
where md.ACCOUNT_ID = F.ACCOUNT_ID
and F.FIRST_DATE = md.TRANSFER_DATE
and md.CATEGORY_CODE = cat.CATEGORY_CODE
and cat.DOMAIN_CODE = 'SUBS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID = 12
and mh.transfer_id = md.transfer_id
and u.MSISDN IN
(
select MSISDN FROM ACCOUNTS_BALANCES
)
and second_party_account_id='72129874'
and F.FIRST_DATE >= to_date('04/08/2020','dd/mm/yyyy') and F.FIRST_DATE < to_date('19/08/2020','dd/mm/yyyy') + 1
group by trunc(F.FIRST_DATE);