With day AS
 (SELECT
  ( to_date('05/08/2018','dd/mm/yyyy') + level - 1) AS end_day
FROM
  DUAL
CONNECT BY LEVEL <= ( to_date('12/08/2018','dd/mm/yyyy') - to_date('05/08/2018','dd/mm/yyyy') + 1)
)
select day.end_day, agents.msisdn, agents.agent_code, agents.agent_name,super_agent_name,
ADDRESS1, coalesce(cbm.amount,0) money_balance, coalesce(cbc.amount,0) commission_balance from day
left outer join
(
select distinct dc.msisdn, dc.category_code, dc.agent_code,
ag.user_name || ' ' || ag.last_name agent_name,
sa.user_name || ' ' || sa.last_name super_agent_name, ag.ADDRESS1
from DAILY_CHANNEL_CLOSING_BALANCE dc
left outer join ecokash.users ag
on dc.msisdn = ag.msisdn
and dc.category_code = ag.category_code
and dc.agent_code = ag.agent_code
left outer join ecokash.users sa
on ag.parent_id = sa.user_id
where ag.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
--and dc.CLOSING_DATE between to_date('01/05/2018','dd/mm/yyyy') and to_date('01/05/2018','dd/mm/yyyy')
) agents
on 1=1
left outer join DAILY_CHANNEL_CLOSING_BALANCE cbm
on cbm.closing_date = day.end_day
and cbm.payment_type_id = 12
and cbm.msisdn = agents.msisdn
and cbm.category_code = agents.category_code
and cbm.agent_code = agents.agent_code
left outer join DAILY_CHANNEL_CLOSING_BALANCE cbc
on cbc.closing_date = day.end_day
and cbc.payment_type_id = 11
and cbc.msisdn = agents.msisdn
and cbc.category_code = agents.category_code
and cbc.agent_code = agents.agent_code
order by 1,2;