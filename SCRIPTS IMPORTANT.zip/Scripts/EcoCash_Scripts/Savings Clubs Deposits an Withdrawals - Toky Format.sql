select md.TRANSFER_ID NUM_REFERENCE,
s.SERVICE_NAME SERVICE,
md.TRANSFER_DATE DATE_TRANSACTION,
DECODE(md.ENTRY_TYPE,'DR', - md.TRANSFER_VALUE / 100, md.TRANSFER_VALUE / 100) MONTANT,
p.MSISDN CUSTOMER_ACCOUNT,
p.USER_NAME,p.LAST_NAME
from ecokash.MTX_TRANSACTION_HEADER mh,
ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s,
ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID = 12 --values for PAYMENT_TYPE_ID are 11 for commission account,12 for main account and 13 for savings club
and md.SECOND_PARTY_ACCOUNT_ID != 'IND03' --remove gererated commissions
--and p.MSISDN in ('79903882') and p.STATUS != 'N'
and s.service_type in('DEPOCLUB','WITHCLUB') --service types for savings club
and md.transfer_date >= to_date('01/08/2021','dd/mm/yyyy')
and md.transfer_date < to_date('31/08/2021','dd/mm/yyyy')+1
order by md.TRANSFER_DATE;