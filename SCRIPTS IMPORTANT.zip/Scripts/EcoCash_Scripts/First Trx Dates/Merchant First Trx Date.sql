select u.MSISDN, u.USER_NAME || ' ' || u.LAST_NAME MERCHANT_NAME , F.FIRST_DATE, SYSDATE
from
(
select min(d.TRANSFER_DATE) "FIRST_DATE", d.ACCOUNT_ID from ecokash.MTX_TRANSACTION_ITEMS d
 where d.TRANSFER_STATUS = 'TS'
  and d.CATEGORY_CODE = 'MER'
 and not exists (select h.TRANSFER_ID from ecokash.MTX_TRANSACTION_HEADER h where h.SERVICE_TYPE in ('ROLLBACK','TXNCORRECT') and h.ATTR_3_VALUE = d.TRANSFER_ID
 and h.TRANSFER_STATUS = 'TS')
 group by d.ACCOUNT_ID
 ) F, ecokash.MTX_TRANSACTION_ITEMS md, ecokash.USERS u
 where md.ACCOUNT_ID = F.ACCOUNT_ID
 and F.FIRST_DATE = md.TRANSFER_DATE
 and md.PARTY_ID = u.USER_ID
and md.PAYMENT_TYPE_ID = 12
 and F.FIRST_DATE >= trunc(sysdate-1) and F.FIRST_DATE < trunc(sysdate-1) + 1;