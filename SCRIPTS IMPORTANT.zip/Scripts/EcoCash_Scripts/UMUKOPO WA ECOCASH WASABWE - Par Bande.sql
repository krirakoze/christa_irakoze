--Loans Borrowed details per Band
select trx_date, count(distinct transfer_id) volume, round(sum(requested_amount)) paid_amount, round(sum(revenue)) revenue, ranges,num from(
select trunc(mti.transfer_date) trx_date, mti.transfer_id transfer_id, mti.second_party_account_id msisdn,
decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100) requested_amount
,((decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100))*20)/100 revenue, '300-10,000' ranges,'1' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date('01/03/2018','dd/mm/yyyy') and to_date('31/03/2018','dd/mm/yyyy') 
and mti.transfer_value/100 between 300 and 10000

union

select trunc(mti.transfer_date) trx_date, mti.transfer_id transfer_id, mti.second_party_account_id msisdn,
decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100) requested_amount
,((decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100))*15)/100 revenue, '10,001-20,000' ranges,'2' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date('01/03/2018','dd/mm/yyyy') and to_date('31/03/2018','dd/mm/yyyy') 
and mti.transfer_value/100 between 10001 and 20000

union

select trunc(mti.transfer_date) trx_date, mti.transfer_id transfer_id, mti.second_party_account_id msisdn,
decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100) requested_amount
,((decode (mti.entry_type, 'DR', mti.transfer_value / 100, -mti.transfer_value / 100))*12)/100 revenue, '20,000-30,000' ranges,'3' num
from ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
where mth.transfer_id=mti.transfer_id
and mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
and mth.service_type in ('MPSUBREQ')
and substr(mti.transfer_id,1,2) in ('MX')
AND mti.transaction_type in ('MP')
AND mti.PARTY_ID = 'PT180404.1046.579832'
AND trunc(mti.transfer_date) between to_date('01/03/2018','dd/mm/yyyy') and to_date('31/03/2018','dd/mm/yyyy') 
and mti.transfer_value/100 >= 20001
)
group by trx_date, ranges,num
order by trx_date,num desc;