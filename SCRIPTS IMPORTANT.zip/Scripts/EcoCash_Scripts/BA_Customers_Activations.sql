select first_cashin_date activation_date, agent_msisdn, u.AGENT_CODE, u.user_name agent_name,
u.last_name agent_last_name, u.CITY, u.STATE, u.ADDRESS1, u.ADDRESS2,
customer_msisdn customer, u.contact_no,
(select sup.user_name || ' ' || sup.last_name from ecokash.users sup where u.PARENT_ID = sup.user_id) sup_agent_name
from ihakizimana.AGENTS_INCENTIVES,
ecokash.USERS u, 
ecokash.mtx_wallet mw, 
ecokash.channel_grades cg 
where AGENT_MSISDN = u.MSISDN
and u.USER_ID = mw.USER_ID
and mw.PAYMENT_TYPE_ID = 11
and mw.status = 'Y'
and mw.user_grade = cg.grade_code
and cg.GRADE_CODE in ('ZRT','BRAM')
and agent_msisdn in(
'76508956'
)
and trunc(first_cashin_date) between to_date('01/03/2019','dd/mm/yyyy') and to_date('31/03/2019','dd/mm/yyyy')
/*and second_trx_date is not null*/ order by first_cashin_date,agent_msisdn;