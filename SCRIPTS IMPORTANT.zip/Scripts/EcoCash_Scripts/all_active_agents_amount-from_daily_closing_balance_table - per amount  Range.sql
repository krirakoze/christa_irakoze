select '08/10/2019' "DAY",'0-100k' "RANGE",count(msisdn) agents_count, sum(amount) agents_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(select distinct agent_msisdn from mmukila.AGENT_DAILY_ACTIVITY where TXN_DATE >=TO_DATE('09/09/2019','DD/MM/YYYY') and TXN_DATE<TO_DATE('08/10/2019','DD/MM/YYYY')+1)
and amount between 0 and 100000 and closing_date >= to_date('08/10/2019','dd/mm/yyyy') and closing_date < to_date('08/10/2019','dd/mm/yyyy')+1
group by '08/10/2019','0-100k'

union

select '08/10/2019' "DAY",'101k-300k' "RANGE",count(msisdn) agents_count, sum(amount) agents_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(select distinct agent_msisdn from mmukila.AGENT_DAILY_ACTIVITY where TXN_DATE >=TO_DATE('09/09/2019','DD/MM/YYYY') and TXN_DATE<TO_DATE('08/10/2019','DD/MM/YYYY')+1)
and amount between 100001 and 300000 and closing_date >= to_date('08/10/2019','dd/mm/yyyy') and closing_date < to_date('08/10/2019','dd/mm/yyyy')+1
group by '08/10/2019','101k-300k'
 
union
 
select '08/10/2019' "DAY",'301k-500k' "RANGE",count(msisdn) agents_count, sum(amount) agents_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(select distinct agent_msisdn from mmukila.AGENT_DAILY_ACTIVITY where TXN_DATE >=TO_DATE('09/09/2019','DD/MM/YYYY') and TXN_DATE<TO_DATE('08/10/2019','DD/MM/YYYY')+1)
and amount between 300001 and 500000 and closing_date >= to_date('08/10/2019','dd/mm/yyyy') and closing_date < to_date('08/10/2019','dd/mm/yyyy')+1
group by '08/10/2019','301k-500k'

union 

select '08/10/2019' "DAY",'501k-1M' "RANGE",count(msisdn) agents_count, sum(amount) agents_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(select distinct agent_msisdn from mmukila.AGENT_DAILY_ACTIVITY where TXN_DATE >=TO_DATE('09/09/2019','DD/MM/YYYY') and TXN_DATE<TO_DATE('08/10/2019','DD/MM/YYYY')+1)
and amount between 500001 and 1000000 and closing_date >= to_date('08/10/2019','dd/mm/yyyy') and closing_date < to_date('08/10/2019','dd/mm/yyyy')+1
group by '08/10/2019','501k-1M'

union

select '08/10/2019' "DAY",'more 1M' "RANGE",count(msisdn) agents_count, sum(amount) agents_amount from mmukila.DAILY_CHANNEL_CLOSING_BALANCE
where payment_type_id=12 and category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and msisdn in(select distinct agent_msisdn from mmukila.AGENT_DAILY_ACTIVITY where TXN_DATE >=TO_DATE('09/09/2019','DD/MM/YYYY') and TXN_DATE<TO_DATE('08/10/2019','DD/MM/YYYY')+1)
and amount > 1000000 and closing_date >= to_date('08/10/2019','dd/mm/yyyy') and closing_date < to_date('08/10/2019','dd/mm/yyyy')+1
group by '08/10/2019','more 1M';