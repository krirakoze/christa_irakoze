select * from ecokash.mtx_transaction_header where TRANSFER_ID in('OW180126.1720.A00007',
'OW180126.1721.A00008',
'OW180126.1715.A00005',
'OW180126.1718.A00006',
'OW180126.1722.A00009',
'OW180725.1432.A00059'
);

select * from ecokash.users where agent_code in('02439',
'02911',
'02915',
'02919',
'02917',
'02913');