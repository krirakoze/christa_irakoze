select agent_code ,msisdn, user_name ||' '||last_name merchant_name from ecokash.users
where status<>'N' and msisdn in(
select distinct u.msisdn
from ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_header mth,
ecokash.SYS_SERVICE_TYPES s,
ecokash.mtx_wallet w,
ecokash.users u
where mti.transfer_id = mth.transfer_id
and mti.payment_type_id = 12
and mti.service_type = s.service_type
and mti.transfer_status = 'TS'
and mti.wallet_number = w.wallet_number
AND mti.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER')
AND mti.party_id IN (select user_id from ecokash.USERS u where u.AGENT_CODE NOT IN ((select u.BILLER_CODE from REMITT_BILLERS_CODE u)))
AND mti.party_id = u.user_id
AND (
     mth.SERVICE_TYPE IN  ('MERCHPAY')
     AND mti.TRANSACTION_TYPE = 'MR'
     OR (
     mth.SERVICE_TYPE IN ('ROLLBACK','TXNCORRECT')
     and exists (select d.TRANSFER_ID from ecokash.MTX_TRANSACTION_ITEMS d 
     where d.TRANSFER_ID = mth.ATTR_2_VALUE and d.SERVICE_TYPE IN  ('MERCHPAY')
     AND mti.TRANSACTION_TYPE = 'MP')
     )) 
and mti.transfer_date >= to_date('01/03/2022','dd/mm/yyyy')
and mti.transfer_date < to_date('31/03/2022','dd/mm/yyyy') + 1
)
and category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER');
