select count(distinct md.ACCOUNT_ID) account_ids
from ecokash.MTX_TRANSACTION_ITEMS md,
ecokash.mtx_transaction_header mh,
ecokash.MTX_PARTY p
where md.transfer_id = mh.transfer_id
AND md.PARTY_ID = p.USER_ID
and length(md.ACCOUNT_ID) <= 8
and md.TRANSFER_STATUS = 'TS'
AND md.transfer_date >= ( to_date('01/03/2019','dd/mm/yyyy') - 90) + 1
and md.transfer_date < to_date('31/08/2019','dd/mm/yyyy') + 1;