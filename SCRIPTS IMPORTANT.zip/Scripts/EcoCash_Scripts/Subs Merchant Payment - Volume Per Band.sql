select to_char(TRANSFER_DATE,'MON-YYYY') month,count(distinct TRANSFER_ID) volume,sum(AMOUNT) value from(
select md.TRANSFER_ID, md.TRANSFER_DATE, p.MSISDN, 
s.SERVICE_NAME, DECODE(md.PAYMENT_TYPE_ID,12,'Principal','Commission') "ACCOUNT",
md.TRANSFER_VALUE / 100 AMOUNT,
s.SERVICE_NAME || ' ' || DECODE(md.SECOND_PARTY_ACCOUNT_ID, 'IND03', 'Commission', SECOND_PARTY_ACCOUNT_ID) "DESCRIPTION",
md.SECOND_PARTY_ACCOUNT_ID b_number from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
--and p.MSISDN = '79669076' and p.STATUS != 'N'
--and md.SECOND_PARTY_ACCOUNT_ID='76795668'
and s.service_type='MERCHPAY'
and md.SECOND_PARTY_ACCOUNT_ID != 'IND03'
and md.TRANSFER_VALUE/100 between 100 and 30000
and md.transfer_date >= to_date('01/09/2020','dd/mm/yyyy') and md.transfer_date < to_date('31/10/2020','dd/mm/yyyy')+1
order by md.TRANSFER_DATE)
group by to_char(TRANSFER_DATE,'MON-YYYY');