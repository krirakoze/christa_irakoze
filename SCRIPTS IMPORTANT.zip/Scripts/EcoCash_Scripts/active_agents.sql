select count(distinct mti.party_id) ACTIVE_AGENTS
from ecokash.mtx_transaction_items mti,ecokash.users u
where mti.party_id=u.user_id
and mti.transfer_status = 'TS'
and mti.payment_type_id = 12
and u.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'MER')
AND (mti.account_id,mti.category_code) not in (select msisdn,category_code from mmukila.excl_agent)
and mti.TRANSFER_DATE > to_date('31/10/2019','dd/mm/yyyy') and mti.TRANSFER_DATE < to_date('31/10/2019','dd/mm/yyyy')+1;