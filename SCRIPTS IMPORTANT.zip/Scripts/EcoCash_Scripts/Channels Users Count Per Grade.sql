select count(a.msisdn)
from ecokash.users a,
ecokash.mtx_wallet mw, 
ecokash.channel_grades cg
where a.USER_ID = mw.USER_ID
and mw.user_grade = cg.grade_code
and cg.GRADE_CODE in ('ZRT','BRAM')
and a.status != 'N'
and mw.status != 'N'
and Mw.Payment_Type_Id = '12'
and a.created_on  >= to_date('01/10/2019','dd/mm/yyyy') and a.created_on  < to_date('31/10/2019','dd/mm/yyyy') +1
AND a.category_code IN (select cat.category_code from ecokash.mtx_categories cat where cat.domain_code = 'DISTWS');