select from_ddate,to_ddate,msisdn,province,cust_name,category_code,GRADE_NAME,times_tracked,rn from(
select ccl.from_ddate,ccl.to_ddate,u.msisdn,ccl.province,ccl.cust_name,u.category_code,g.GRADE_NAME,ccl.times_tracked,row_number()
over(partition by u.msisdn order by ccl.province) as rn
from CELLID_SUBS_LOCATIONS ccl,ecokash.mtx_party u,ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where ccl.msisdn=u.msisdn and u.USER_ID = w.USER_ID and w.USER_GRADE = g.GRADE_CODE
and ccl.times_tracked=(select max(l.times_tracked) from CELLID_SUBS_LOCATIONS l
where u.msisdn=l.msisdn ) and province is not null
and u.USER_ID = w.USER_ID and w.PAYMENT_TYPE_ID = 12 and w.USER_GRADE = g.GRADE_CODE
) a where a.rn = 1 --order by a.province

union all

select trunc(sysdate-90) from_ddate,trunc(sysdate-1) to_ddate,u.msisdn,u.state province,
u.user_name||' '||u.last_name cust_name,u.category_code,g.GRADE_NAME,0 as times_tracked,0 as rn
from ecokash.mtx_party u,ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where u.USER_ID = w.USER_ID and w.USER_GRADE = g.GRADE_CODE
and u.USER_ID = w.USER_ID and w.PAYMENT_TYPE_ID = 12 and w.USER_GRADE = g.GRADE_CODE --order by u.state