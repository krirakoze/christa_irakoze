SELECT trunc(mti.transfer_date) Transfer_Date,mti.account_id msisdn,count(distinct mti.TRANSFER_ID) vol, 
sum(mti.transfer_value / 100) val
FROM ecokash.sys_service_types sst, ecokash.mtx_transaction_items mti, ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
AND mti.service_type = sst.service_type
AND mth.transfer_id=mti.transfer_id
and sst.service_type='CASHOUT'
AND mti.party_id in (select user_id from ecokash.users where category_code in
(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS'))
and mti.SECOND_PARTY_CATEGORY_CODE='SUBS'
AND mti.transfer_date >= to_date('20/09/2021','dd/mm/yyyy')-30+1
AND mti.transfer_date < to_date('20/09/2021','dd/mm/yyyy')+1
group by trunc(mti.transfer_date),mti.account_id having count(distinct mti.TRANSFER_ID)>=10 order by 1,2;