select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'CASHOUT' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type='CASHOUT'
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'CASHOUT'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'BILLPAY' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type='BILLPAY'
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'BILLPAY'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'MERCHPAY' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('MERCHPAY','SUBMPREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'MERCHPAY'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'P2P' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('P2P')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'P2P'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'CASHIN' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CASHIN')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'CASHIN'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'RECHARGE' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('RC')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'RECHARGE'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'W2B' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CWBREQ','RWBREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'W2B'

UNION ALL

select p.MSISDN,to_char(md.transfer_date,'MON-YYYY') TMONTH,'B2W' service,count(distinct md.transfer_id) vol,sum(md.transfer_value/100) val
from ecokash.MTX_TRANSACTION_HEADER mh, ecokash.MTX_TRANSACTION_ITEMS md, 
ecokash.SYS_SERVICE_TYPES s, ecokash.MTX_PARTY p
where mh.TRANSFER_ID = md.TRANSFER_ID
and md.TRANSFER_STATUS = 'TS'
and md.SERVICE_TYPE = s.SERVICE_TYPE
and md.PARTY_ID = p.USER_ID
and md.PAYMENT_TYPE_ID != 0
and p.MSISDN in(select msisdn from temp_nbrs) --and p.STATUS != 'N'
and s.service_type in('CBWREQ','RBWREQ')
and md.transaction_type in ('MR','MP')
and md.transfer_date >= to_date('01/03/2021','dd/mm/yyyy') and md.transfer_date < to_date('30/09/2021','dd/mm/yyyy')+1
group by p.MSISDN,to_char(md.transfer_date,'MON-YYYY'),'B2W';