--select from_ddate,to_ddate,msisdn,agent_code,province,channel_name,category_code,GRADE_NAME from(
select from_ddate,to_ddate,msisdn,agent_code,province,channel_name,category_code,GRADE_NAME,times_tracked,rn from(
select ccl.from_ddate,ccl.to_ddate,u.msisdn,u.agent_code,ccl.province,ccl.channel_name,u.category_code,g.GRADE_NAME,ccl.times_tracked,row_number()
over(partition by u.msisdn order by ccl.province) as rn
from CELLID_CHANNEL_LOCATIONS ccl,ecokash.users u,ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where ccl.msisdn=u.msisdn and u.USER_ID = w.USER_ID and w.PAYMENT_TYPE_ID = 12 and w.USER_GRADE = g.GRADE_CODE
and ccl.category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and ccl.times_tracked=(select max(l.times_tracked) from CELLID_CHANNEL_LOCATIONS l
where u.msisdn=l.msisdn ) and province is not null
and u.USER_ID = w.USER_ID and w.PAYMENT_TYPE_ID = 12 and w.USER_GRADE = g.GRADE_CODE and g.GRADE_CODE not in ('ZRT','BRAM') 
) a where a.rn = 1 and category_code<>'WHS' --order by a.province

/*union all

select trunc(sysdate-90) from_ddate,trunc(sysdate-1) to_ddate,u.msisdn,u.agent_code,u.state province,
u.user_name||' '||u.last_name channel_name,u.category_code,g.GRADE_NAME,0 as times_tracked,0 as rn
from ecokash.users u,ecokash.MTX_WALLET w,ecokash.CHANNEL_GRADES g
where u.USER_ID = w.USER_ID and w.USER_GRADE = g.GRADE_CODE
and u.category_code in(select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
and u.USER_ID = w.USER_ID and w.PAYMENT_TYPE_ID = 12 and w.USER_GRADE = g.GRADE_CODE and g.GRADE_CODE not in ('ZRT','BRAM')
and u.category_code<>'WHS' --order by u.state
) order by province;*/