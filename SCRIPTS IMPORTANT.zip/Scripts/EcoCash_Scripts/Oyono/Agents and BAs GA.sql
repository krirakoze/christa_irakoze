select subs.msisdn,to_char(subs.created_on,'MON-YYYY') "MONTH",subs.city province,subs.reg_agent agent_msisdn,
case when tmp.user_grade in('ZRT','BRAM') then 'BA' else 'Agent' end as Agent_Type
from (
      select a.msisdn,w.user_grade
      from ecokash.users a,ecokash.mtx_wallet w,ecokash.channel_grades g
      where a.msisdn=w.msisdn and w.user_grade=g.grade_code and a.status != 'N' and w.status != 'N' and w.payment_type_id=12
      and a.category_code in (select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
     ) tmp
     left outer join
     (
            select u.created_on,u.MSISDN,u.city,
            (
                select uu.msisdn from ecokash.users uu where uu.user_id=u.created_by and uu.category_code in(
                select category_code from ecokash.mtx_categories where domain_code = 'DISTWS')
            ) reg_agent
                from ecokash.MTX_PARTY_ACCESS p,
                ecokash.MTX_PARTY u
                where u.USER_ID = p.USER_ID
                and length(p.MSISDN) <= 8
                and p.STATUS != 'N'
                and u.created_on>=to_date('01/03/2021','dd/mm/yyyy') and u.created_on<to_date('30/09/2021','dd/mm/yyyy')+1
     ) subs
     on tmp.msisdn=subs.reg_agent and subs.msisdn is not null;