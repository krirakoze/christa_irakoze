select SA_MSISDN "SA NUMBER",SA_CHANNEL_NAME,count(agent_code) Active_Agents,sum(amount) Commissions_Amount from(
select LAST_DAY( to_date('01/07/2019','dd/mm/yyyy') ) "Date",
to_char( to_date('01/07/2019','dd/mm/yyyy') ,'YYYYMM') "Periode",
u.AGENT_CODE, (u.USER_NAME || ' ' || u.LAST_NAME) "CHANNEL_NAME",
coalesce(SUM(DECODE(d.ENTRY_TYPE,'CR', 
d.TRANSFER_VALUE/100, 
- d.TRANSFER_VALUE/100)),0) "AMOUNT",
sa.AGENT_CODE "SA AGENT CODE",sa.MSISDN SA_MSISDN,
sa.USER_NAME || ' ' || sa.LAST_NAME "SA_CHANNEL_NAME" 
from ecokash.MTX_TRANSACTION_ITEMS d,ecokash.users u,ecokash.USERS sa
where d.PARTY_ID = u.USER_ID
and u.PARENT_ID = sa.USER_ID
and sa.STATUS != 'N'
and u.STATUS != 'N' 
and d.TRANSFER_STATUS = 'TS'
and d.PAYMENT_TYPE_ID = 11
and d.SERVICE_TYPE not in  ('RCOMRIMB')
and d.TRANSFER_DATE >= to_date('01/09/2019','dd/mm/yyyy') and d.TRANSFER_DATE < (LAST_DAY( to_date('01/09/2019','dd/mm/yyyy') )+1)
group by u.AGENT_CODE, u.USER_NAME, u.LAST_NAME, sa.AGENT_CODE, sa.USER_NAME, sa.LAST_NAME,sa.MSISDN
order by 3)
group by SA_MSISDN,SA_CHANNEL_NAME order by 4 desc
;