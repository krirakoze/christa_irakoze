SELECT to_char(mti.transfer_date,'MON-YYYY') "MONTH",
count(distinct mti.TRANSFER_ID) volume,
SUM (mti2.transfer_value / 100) commission
FROM ecokash.sys_service_types sst,
ecokash.mtx_transaction_items mti,
ecokash.mtx_transaction_items mti2,
ecokash.mtx_transaction_header mth
WHERE mti.transfer_status = 'TS'
AND mti.transfer_id=mti2.transfer_id
AND mti.service_type = sst.service_type
and mth.transfer_id=mti.transfer_id and mti2.wallet_number = '101COMMISSION'
and mth.service_type = 'CASHIN' and mti.user_type='PAYEE'
and mti.category_code='SUBS' and mti.transaction_type = 'MR'
AND mti.transfer_date >= to_date('01/01/2022','dd/mm/yyyy')
and mti.transfer_date <(to_date('15/01/2022','dd/mm/yyyy')) + 1
and mti.SECOND_PARTY_CATEGORY_CODE IN ('WHS')

--AND mti.transfer_value/100 between 500001 and 1000000
--AND mti.transfer_value/100 between 400001 and 499999
--AND mti.transfer_value/100 between 300001 and 399999
--AND mti.transfer_value/100 between 200001 and 299999
--AND mti.transfer_value/100 between 100001 and 199999
--AND mti.transfer_value/100 between 90000 and 99999
--AND mti.transfer_value/100 between 80000 and 89999
--AND mti.transfer_value/100 between 70000 and 79999
--AND mti.transfer_value/100 between 60000 and 69999
--AND mti.transfer_value/100 between 50000 and 59999
--AND mti.transfer_value/100 between 40000 and 49999
--AND mti.transfer_value/100 between 30000 and 39999
--AND mti.transfer_value/100 between 20000 and 29999
--AND mti.transfer_value/100 between 10000 and 19999
--AND mti.transfer_value/100 between 5001 and 9999
--AND mti.transfer_value/100 between 1001 and 4999
--AND mti.transfer_value/100 between 101 and 999

GROUP BY to_char(mti.transfer_date,'MON-YYYY')
order by to_char(mti.transfer_date,'MON-YYYY');