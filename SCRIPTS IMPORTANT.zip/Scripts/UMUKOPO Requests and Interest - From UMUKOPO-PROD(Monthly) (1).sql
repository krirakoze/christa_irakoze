select date_format(crr.request_date,'%Y-%m') month,
format(sum(cra.approved_amount),0) requested_amount,format(sum(cra.approved_interest),0) expected_interest from
(
    select request_date, count(id) cnt_request,count(distinct subscriber_id) requestors from
    (   
        select convert(date_created,date) request_date, id,subscriber_id
        from credit_request_archive
        where convert(date_created, date) between '2021-10-01' and '2021-11-30' and ecocash_reference is not null
        union all
        select convert(date_created,date) request_date,id,subscriber_id
        from credit_request
        where convert(date_created, date) between '2021-10-01' and '2021-11-30' and ecocash_reference is not null
    ) tt group by request_date
) crr left outer join 
(
    select request_date, count(id) cnt_approved, 
    sum(request_amount) approved_amount, sum(interest) approved_interest,count(distinct subscriber_id) approved_requestors
    from
    (
        select convert(date_created,date) request_date, id, request_amount, interest,subscriber_id
        from credit_request_archive
        where convert(date_created, date) between '2021-10-01' and '2021-11-30'
        and status <> 'REJECTED'  and ecocash_reference is not null
        union all
        select convert(date_created,date) request_date, id, request_amount, interest,subscriber_id
        from credit_request
        where convert(date_created, date) between '2021-10-01' and '2021-11-30'
        and status <> 'REJECTED'  and ecocash_reference is not null
    ) tt group by request_date
) cra on crr.request_date = cra.request_date group by date_format(crr.request_date,'%Y-%m');